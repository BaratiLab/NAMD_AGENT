"""Swiss-Param REST client for CHARMM-CGenFF ligand parametrization.

Endpoints (all on https://www.swissparam.ch:8443):
    GET  /                              health check, returns "Hello World!"
    POST /startparam?approach=both      multipart -F myMol2=@<file.mol2>
                                        returns "Session number: <id> ..."
    GET  /checksession?sessionNumber=N  status text
    GET  /retrievesession?sessionNumber=N  results.tar.gz

Result archive layout (we use ``MATCH/`` for CHARMM CGenFF parameters):
    MATCH/BEN.rtf   CHARMM topology (RESI BEN1 by default — we rewrite to user's resname)
    MATCH/BEN.prm   CHARMM parameters (BONDS/ANGLES/DIHEDRALS/IMPROPER/NONBONDED)
    MATCH/BEN.pdb   parameterized PDB (resname LIG — we rewrite)
    MATCH/BEN.mol2  mol2 with assigned atom types
    MATCH/MATCH.log
    MMFF/...        MMFF-based outputs (ignored for CHARMM workflow)

Results are content-cached so resubmitting the same mol2 returns instantly.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import shutil
import tarfile
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

SWISSPARAM_BASE = os.environ.get("SWISSPARAM_BASE", "https://www.swissparam.ch:8443")
DEFAULT_CACHE = Path(os.environ.get(
    "HTMD_MCP_SWISSPARAM_CACHE",
    str(Path.home() / ".cache" / "htmd_mcp" / "swissparam"),
))


def _http_get(url: str, timeout: int = 60) -> str:
    with urllib.request.urlopen(url, timeout=timeout) as resp:
        return resp.read().decode("utf-8", errors="replace")


def _http_get_bytes(url: str, dst: Path, timeout: int = 120) -> None:
    with urllib.request.urlopen(url, timeout=timeout) as resp, open(dst, "wb") as fh:
        shutil.copyfileobj(resp, fh)


def _http_post_multipart(url: str, files: Dict[str, Path],
                         timeout: int = 120) -> str:
    """Plain-stdlib multipart upload (no requests dependency)."""
    boundary = "----htmdMCP" + hashlib.sha1(os.urandom(8)).hexdigest()
    body = bytearray()
    for field, path in files.items():
        body += f"--{boundary}\r\n".encode()
        body += (
            f'Content-Disposition: form-data; name="{field}"; '
            f'filename="{path.name}"\r\n'
            f"Content-Type: application/octet-stream\r\n\r\n"
        ).encode()
        body += path.read_bytes()
        body += b"\r\n"
    body += f"--{boundary}--\r\n".encode()

    req = urllib.request.Request(url, data=bytes(body), method="POST")
    req.add_header("Content-Type", f"multipart/form-data; boundary={boundary}")
    req.add_header("Content-Length", str(len(body)))
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read().decode("utf-8", errors="replace")


# --- Cache helpers ----------------------------------------------------------

def _cache_key(mol2_path: Path, ligand_resname: str) -> str:
    h = hashlib.sha256()
    h.update(mol2_path.read_bytes())
    h.update(b"|")
    h.update(ligand_resname.upper().encode())
    return h.hexdigest()[:16]


def _cache_dir_for(key: str, cache_root: Path) -> Path:
    return cache_root / key


# --- File rewrites ----------------------------------------------------------

def _rewrite_rtf_resname(rtf_in: Path, rtf_out: Path,
                        new_resname: str) -> str:
    """Rewrite the first RESI line so the topology uses ``new_resname`` and
    return the original resname (for downstream rewriting of the PDB)."""
    text = rtf_in.read_text()
    m = re.search(r"^RESI\s+(\S+)", text, re.MULTILINE)
    if not m:
        raise RuntimeError(f"no RESI line in {rtf_in}")
    original = m.group(1)
    text = re.sub(
        r"^(RESI\s+)\S+",
        rf"\g<1>{new_resname.upper()}",
        text,
        count=1,
        flags=re.MULTILINE,
    )
    rtf_out.write_text(text)
    return original


def _rewrite_pdb_resname(pdb_in: Path, pdb_out: Path,
                       new_resname: str) -> int:
    """Rewrite the resname column (cols 18-20) on every ATOM/HETATM record.
    Returns the count of records rewritten."""
    new = new_resname.upper().ljust(3)[:3]
    n = 0
    with open(pdb_in) as fin, open(pdb_out, "w") as fout:
        for line in fin:
            if line.startswith(("ATOM  ", "HETATM")):
                # cols 18-20 (1-indexed) -> 17:20 (0-indexed)
                line = line[:17] + new + line[20:]
                n += 1
            fout.write(line)
    return n


def _ensure_prm_terminator(prm_in: Path, prm_out: Path) -> None:
    """Ensure the .prm file ends with an ``END`` line (NAMD3 prefers it)."""
    text = prm_in.read_text().rstrip()
    if not re.search(r"\bEND\b\s*$", text):
        text = text + "\n\nEND\n"
    prm_out.write_text(text + "\n")


def _uniqueify_match_output(rtf_path: Path, pdb_path: Path,
                            mol2_path: Path, ligand_resname: str) -> None:
    """Rebuild the MATCH RTF and PDB so atom names are unique within the
    residue and BOND/IMPR sections explicitly reference those names.

    SwissParam's MATCH backend writes every atom name as just the element
    symbol ("C", "C", ..., "N", ...). Since CHARMM requires unique names
    inside a residue, the result breaks every psfgen-based builder
    (htmd.builder.charmm, parmed, etc.). The matching ``MATCH/<name>.mol2``
    holds explicit connectivity and hybridization, so we use it to:

    * assign unique names by element + per-element index (C, C2, C3, ...)
    * regenerate the BOND list from mol2 bonds
    * generate IMPR entries for every sp2 atom with three neighbors,
      preserving the planarity restraints CGenFF expects.

    Atom types and partial charges are taken straight from the original
    RTF (in mol2 atom order), so the CGenFF parameter set is unchanged.
    """
    from collections import defaultdict
    try:
        from rdkit import Chem
    except ImportError as e:  # pragma: no cover
        raise RuntimeError("RDKit required for SwissParam name rewrite") from e

    mol = Chem.MolFromMol2File(str(mol2_path), removeHs=False, sanitize=False)
    if mol is None:
        raise RuntimeError(f"RDKit could not parse {mol2_path}")
    n_atoms = mol.GetNumAtoms()

    # Per-element counters → C, C2, C3, ..., N, N2, ..., H, H2, ...
    counters: Dict[str, int] = defaultdict(int)
    new_names: list[str] = []
    for atom in mol.GetAtoms():
        sym = atom.GetSymbol().upper()
        counters[sym] += 1
        idx = counters[sym]
        new_names.append(sym if idx == 1 else f"{sym}{idx}")
    # CHARMM atom names are limited to 4 chars; rare for small molecules
    # but enforce it explicitly.
    for nm in new_names:
        if len(nm) > 4:
            raise RuntimeError(
                f"generated atom name {nm!r} exceeds CHARMM 4-char limit; "
                f"molecule has too many atoms of one element"
            )

    rtf_lines = rtf_path.read_text().splitlines()
    mass_lines = [ln for ln in rtf_lines if ln.startswith("MASS")]
    resi_line = next((ln for ln in rtf_lines if ln.startswith("RESI")), None)
    atom_lines = [ln for ln in rtf_lines if ln.startswith("ATOM ")]
    if len(atom_lines) != n_atoms:
        raise RuntimeError(
            f"RTF has {len(atom_lines)} ATOM records but mol2 has {n_atoms}"
        )

    # Validate RTF and mol2 atoms are in the same order by element.
    for i, line in enumerate(atom_lines):
        parts = line.split()
        rtf_old_name = parts[1]
        elem_in_rtf = re.match(r"[A-Za-z]+", rtf_old_name).group(0).upper()
        elem_in_mol = mol.GetAtomWithIdx(i).GetSymbol().upper()
        if elem_in_rtf != elem_in_mol:
            raise RuntimeError(
                f"atom {i}: RTF has element {elem_in_rtf} but mol2 has "
                f"{elem_in_mol}; cannot align unique-naming pass"
            )

    typed_atoms: list[tuple[str, str]] = []
    for line in atom_lines:
        parts = line.split()
        # ATOM <name> <type> <charge>
        typed_atoms.append((parts[2], parts[3]))

    bonds = [(b.GetBeginAtomIdx(), b.GetEndAtomIdx()) for b in mol.GetBonds()]

    impr_entries: list[tuple[int, int, int, int]] = []
    sp2 = Chem.HybridizationType.SP2
    for atom in mol.GetAtoms():
        if atom.GetHybridization() != sp2:
            continue
        nbrs = [n.GetIdx() for n in atom.GetNeighbors()]
        if len(nbrs) == 3:
            # CHARMM IMPR: central atom first, then its three neighbors
            impr_entries.append((atom.GetIdx(), nbrs[0], nbrs[1], nbrs[2]))

    out_lines: list[str] = []
    out_lines.append(
        "* CGenFF parameters from SwissParam/MATCH; atom names made unique"
    )
    out_lines.append("*")
    out_lines.append(f"  {len(mass_lines)}     0")
    out_lines.append("")
    out_lines.extend(mass_lines)
    out_lines.append("")
    out_lines.append("AUTO ANGLES DIHE")
    out_lines.append("")
    if resi_line:
        out_lines.append(resi_line)
    else:
        out_lines.append(f"RESI  {ligand_resname}  0.000")
    out_lines.append("GROUP")
    for new_n, (atyp, q) in zip(new_names, typed_atoms):
        out_lines.append(f"ATOM {new_n:<6s} {atyp:<6s} {q}")
    for a, b in bonds:
        out_lines.append(f"BOND {new_names[a]:<6s} {new_names[b]}")
    for c, n1, n2, n3 in impr_entries:
        out_lines.append(
            f"IMPR {new_names[c]:<6s} {new_names[n1]:<6s} "
            f"{new_names[n2]:<6s} {new_names[n3]}"
        )
    out_lines.append("END")
    rtf_path.write_text("\n".join(out_lines) + "\n")

    # Rewrite the PDB atom-name column (cols 13-16, 0-indexed 12:16).
    pdb_lines = pdb_path.read_text().splitlines()
    out_pdb: list[str] = []
    atom_idx = 0
    for line in pdb_lines:
        if line.startswith(("ATOM  ", "HETATM")) and atom_idx < len(new_names):
            new_n = new_names[atom_idx].ljust(4)[:4]
            line = line[:12] + new_n + line[16:]
            atom_idx += 1
        out_pdb.append(line)
    pdb_path.write_text("\n".join(out_pdb) + "\n")


# --- Bond-parameter sanity correction ---------------------------------------

# Plausible CHARMM-style (Kb, b0) for a bond of a given element pair + order.
# Used only to repair parameters MATCH assigned an implausibly short b0.
_SANE_BOND: Dict[tuple, Dict[int, tuple]] = {
    ("C", "C"): {1: (300.0, 1.500), 2: (500.0, 1.340)},
    ("C", "N"): {1: (320.0, 1.470), 2: (500.0, 1.300)},
    ("C", "O"): {1: (340.0, 1.430), 2: (540.0, 1.230)},
    ("C", "S"): {1: (240.0, 1.810), 2: (300.0, 1.600)},
    ("N", "N"): {1: (300.0, 1.400), 2: (420.0, 1.250)},
    ("N", "O"): {1: (300.0, 1.400), 2: (420.0, 1.230)},
}
# No genuine single bond between two heavy (non-H) atoms is anywhere near
# this short — even strongly conjugated single bonds bottom out around
# 1.33-1.36 Å. MATCH sometimes copies a *triple*-bond entry onto a single
# bond that merely flanks a triple bond (alkynes, nitriles), because it keys
# purely on atom types — producing a ~1.22 Å, Kb~960 catastrophically stiff
# bond. A heavy-heavy single bond below this length is unambiguously that
# artifact. H-X bonds (~1.0-1.1 Å), genuine double/triple/aromatic bonds, and
# normal conjugated single bonds (>=1.33 Å) are all left untouched.
_SINGLE_BOND_MIN_B0 = 1.30


def _fix_match_triple_bond_artifacts(
    rtf_path: Path, prm_path: Path, mol2_path: Path
) -> list:
    """Repair MATCH bond parameters that gave a heavy-atom single bond a
    multiple-bond length. Cross-references every BONDS entry in the .prm
    against the actual bond orders in the MATCH mol2: a type pair that is a
    pure single bond (RDKit order 1) between two non-hydrogen atoms, yet was
    given a .prm ``b0`` below the single-bond minimum, is rewritten with
    plausible single-bond parameters for its element pair.

    Returns a list of human-readable correction records (empty if nothing was
    wrong, or if the mol2 could not be parsed — in which case the .prm is left
    untouched).
    """
    from collections import defaultdict
    try:
        from rdkit import Chem
    except ImportError:
        return []

    mol = Chem.MolFromMol2File(str(mol2_path), removeHs=False, sanitize=False)
    if mol is None:
        return []

    rtf_lines = rtf_path.read_text().splitlines()
    # type -> element, from the MASS records (element is the trailing token).
    type_elem: Dict[str, str] = {}
    for ln in rtf_lines:
        if ln.startswith("MASS"):
            p = ln.split()
            if len(p) >= 5:
                type_elem[p[2]] = p[4].upper()
    # atom types in mol2 order (uniqueify guarantees rtf ATOM order == mol2).
    atom_types = [ln.split()[2] for ln in rtf_lines if ln.startswith("ATOM ")]
    if len(atom_types) != mol.GetNumAtoms():
        return []

    # Per unordered type-pair: the set of bond orders that actually occur.
    pair_orders: Dict[tuple, set] = defaultdict(set)
    for b in mol.GetBonds():
        i, j = b.GetBeginAtomIdx(), b.GetEndAtomIdx()
        key = tuple(sorted((atom_types[i], atom_types[j])))
        pair_orders[key].add(b.GetBondTypeAsDouble())

    prm_lines = prm_path.read_text().splitlines()
    _SECTIONS = ("BONDS", "ANGLES", "DIHEDRALS", "IMPROPER", "IMPROPERS",
                 "NONBONDED", "CMAP", "END")

    # First pass: collect angle type-triples whose equilibrium angle is
    # near-linear (i.e. an sp / linear centre — alkyne, nitrile, allene).
    # A proper dihedral routed through such a centre is geometrically
    # undefined and produces erratic, near-singular forces as the centre
    # approaches collinearity — a classic MD blow-up. Real CGenFF gives such
    # dihedrals a zero force constant; MATCH leaves them nonzero.
    _LINEAR_DEG = 170.0
    linear_angles: set = set()   # (centre_type, frozenset({end1, end2}))
    section = None
    for line in prm_lines:
        head = line.strip().split()
        if head and head[0] in _SECTIONS:
            section = head[0]
            continue
        if section != "ANGLES" or not line.strip() \
                or line.lstrip().startswith("!"):
            continue
        t = line.split()
        if len(t) >= 5:
            try:
                theta0 = float(t[4])
            except ValueError:
                continue
            if theta0 >= _LINEAR_DEG:
                linear_angles.add((t[1], frozenset((t[0], t[2]))))

    # Second pass: rewrite BONDS (multiple-bond-length artifacts) and
    # DIHEDRALS (terms routed through a linear centre).
    out: list = []
    corrections: list = []
    section = None
    for line in prm_lines:
        head = line.strip().split()
        if head and head[0] in _SECTIONS:
            section = head[0]
            out.append(line)
            continue
        is_data = bool(line.strip()) and not line.lstrip().startswith("!")

        if section == "BONDS" and is_data:
            toks = line.split()
            if len(toks) < 4:
                out.append(line)
                continue
            tA, tB, kb, b0 = toks[0], toks[1], toks[2], toks[3]
            try:
                b0f = float(b0)
            except ValueError:
                out.append(line)
                continue
            elemA, elemB = type_elem.get(tA, "C"), type_elem.get(tB, "C")
            orders = pair_orders.get(tuple(sorted((tA, tB))), set())
            # Only heavy-atom *pure single* bonds can be diagnosed: a real
            # one is never shorter than ~1.40 Å. H-X bonds and genuine
            # double/triple/aromatic bonds may legitimately be short.
            is_heavy = elemA != "H" and elemB != "H"
            is_pure_single = bool(orders) and max(orders) == 1.0
            if is_heavy and is_pure_single and b0f < _SINGLE_BOND_MIN_B0:
                epair = tuple(sorted((elemA, elemB)))
                kb_new, b0_new = _SANE_BOND.get(epair, {}).get(
                    1, (300.0, 1.500))
                out.append(f"{tA:<6s} {tB:<6s} {kb_new:8.2f}   {b0_new:8.4f}")
                corrections.append(
                    f"{tA}-{tB}: single bond b0 {b0f:.3f}->{b0_new:.3f} Kb "
                    f"{kb}->{kb_new:.1f}"
                )
            else:
                out.append(line)

        elif section == "DIHEDRALS" and is_data:
            t = line.split()
            if len(t) >= 5:
                tA, tB, tC, tD = t[0], t[1], t[2], t[3]
                routed_linear = (
                    (tB, frozenset((tA, tC))) in linear_angles
                    or (tC, frozenset((tB, tD))) in linear_angles
                )
                try:
                    k_old = float(t[4])
                except ValueError:
                    k_old = 0.0
                if routed_linear and abs(k_old) > 1e-9:
                    mult = t[5] if len(t) > 5 else "2"
                    phase = t[6] if len(t) > 6 else "0.00"
                    out.append(
                        f"{tA:<6s} {tB:<6s} {tC:<6s} {tD:<6s} "
                        f"{0.0:9.4f} {mult:>3s} {phase:>10s}"
                    )
                    corrections.append(
                        f"{tA}-{tB}-{tC}-{tD}: dihedral k {t[4]}->0.0 "
                        f"(routed through linear sp centre)"
                    )
                    continue
            out.append(line)

        else:
            out.append(line)

    if corrections:
        prm_path.write_text("\n".join(out) + "\n")
        logger.warning(
            "Corrected %d MATCH parameter artifact(s) in %s: %s",
            len(corrections), prm_path.name, "; ".join(corrections),
        )
    return corrections


# --- Public API -------------------------------------------------------------

def health_check(timeout: int = 30) -> Dict[str, Any]:
    try:
        body = _http_get(f"{SWISSPARAM_BASE}/", timeout=timeout)
        ok = "Hello" in body
        return {"ok": ok, "body": body.strip()}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def parametrize_ligand_swissparam(
    mol2_path: str,
    ligand_resname: str = "LIG",
    *,
    outdir: str = "lig_params",
    cache_dir: Optional[str] = None,
    poll_interval_s: float = 5.0,
    max_wait_s: int = 1200,
    refresh: bool = False,
) -> Dict[str, Any]:
    """Submit a mol2 to Swiss-Param and stage CHARMM (.rtf, .prm, .pdb) files
    into ``outdir``. Returns absolute paths and the original session number.
    """
    src = Path(mol2_path).resolve()
    if not src.is_file():
        raise FileNotFoundError(f"ligand mol2 not found: {src}")
    if src.suffix.lower() != ".mol2":
        raise ValueError(
            f"Swiss-Param requires mol2 input (got {src.suffix}). "
            "Convert with antechamber or open babel first."
        )

    cache_root = Path(cache_dir) if cache_dir else DEFAULT_CACHE
    cache_root.mkdir(parents=True, exist_ok=True)
    key = _cache_key(src, ligand_resname)
    cdir = _cache_dir_for(key, cache_root)

    outdir_p = Path(outdir).resolve()
    outdir_p.mkdir(parents=True, exist_ok=True)

    # A cache dir only counts as a hit if it actually holds the MATCH/ result.
    # Requiring MATCH/ (not just the dir) prevents an empty/partial dir left by
    # a previous failed fetch — e.g. a network drop between mkdir and result
    # retrieval — from poisoning every subsequent run as a phantom cache hit.
    if (cdir / "MATCH").is_dir() and not refresh:
        logger.info("Swiss-Param cache hit at %s", cdir)
    else:
        # Rebuild cleanly so no stale/partial files from a prior failed run linger.
        if cdir.exists():
            shutil.rmtree(cdir)
        cdir.mkdir(parents=True, exist_ok=True)
        # Submit
        url = f"{SWISSPARAM_BASE}/startparam?approach=both"
        body = _http_post_multipart(url, {"myMol2": src})
        m = re.search(r"Session number:\s*(\d+)", body)
        if not m:
            raise RuntimeError(
                f"Swiss-Param did not return a session number; got:\n{body[:500]}"
            )
        session = m.group(1)
        (cdir / "session.txt").write_text(session)
        logger.info("Swiss-Param session %s started for %s", session, src.name)

        # Poll. Status responses always echo the input ("Your parameters:")
        # so we look for the explicit "Calculation is finished" line.
        check_url = f"{SWISSPARAM_BASE}/checksession?sessionNumber={session}"
        deadline = time.time() + max_wait_s
        last_status = ""
        while time.time() < deadline:
            try:
                last_status = _http_get(check_url, timeout=30)
            except Exception as e:
                last_status = f"poll error: {e}"
            if "Calculation is finished" in last_status:
                # MATCH may succeed even when MMFF fails. We verify by checking
                # for MATCH/ output after extraction.
                break
            if "cancelled" in last_status.lower() \
                    or "session not found" in last_status.lower():
                raise RuntimeError(
                    f"Swiss-Param session {session} aborted:\n{last_status}"
                )
            time.sleep(poll_interval_s)
        else:
            raise TimeoutError(
                f"Swiss-Param job {session} did not finish within {max_wait_s}s. "
                f"Last status:\n{last_status}"
            )

        # Retrieve
        tgz = cdir / "results.tgz"
        _http_get_bytes(
            f"{SWISSPARAM_BASE}/retrievesession?sessionNumber={session}",
            tgz,
        )
        with tarfile.open(tgz, "r:gz") as tar:
            tar.extractall(cdir)

    # Locate MATCH outputs
    match_dir = cdir / "MATCH"
    if not match_dir.is_dir():
        raise RuntimeError(
            f"MATCH/ folder missing in Swiss-Param result at {cdir}. "
            f"Files: {list(cdir.glob('*'))}"
        )
    rtf_src = next(match_dir.glob("*.rtf"), None)
    prm_src = next(match_dir.glob("*.prm"), None)
    pdb_src = next(match_dir.glob("*.pdb"), None)
    if not (rtf_src and prm_src and pdb_src):
        raise RuntimeError(
            f"Swiss-Param MATCH output incomplete: {list(match_dir.iterdir())}"
        )

    # Rewrite resname in topology and PDB to user-chosen value
    final_resname = ligand_resname.upper()[:4]
    rtf_dst = outdir_p / f"{final_resname}.rtf"
    prm_dst = outdir_p / f"{final_resname}.prm"
    pdb_dst = outdir_p / f"{final_resname}.pdb"

    original_resname = _rewrite_rtf_resname(rtf_src, rtf_dst, final_resname)
    n_atoms = _rewrite_pdb_resname(pdb_src, pdb_dst, final_resname)
    _ensure_prm_terminator(prm_src, prm_dst)

    # MATCH writes element-only atom names (all "C", "N", ...). Make them
    # unique and rebuild the BOND/IMPR sections from the matching mol2 so
    # the RTF/PDB pair is psfgen-compatible.
    mol2_src = next(match_dir.glob("*.mol2"), None)
    if mol2_src is None:
        raise RuntimeError(
            f"MATCH/ has no .mol2 file at {match_dir}; "
            "cannot uniqueify atom names"
        )
    _uniqueify_match_output(rtf_dst, pdb_dst, mol2_src, final_resname)

    # MATCH keys bond parameters purely on atom types, so it can copy a
    # triple-bond entry onto the single bonds that merely flank a triple bond
    # (alkynes, nitriles) — a catastrophically stiff, too-short bond. Repair
    # any such artifact against the real mol2 bond orders.
    bond_corrections = _fix_match_triple_bond_artifacts(
        rtf_dst, prm_dst, mol2_src)

    return {
        "status": "ok",
        "ligand_resname": final_resname,
        "original_swissparam_resname": original_resname,
        "n_pdb_atoms": n_atoms,
        "bond_corrections": bond_corrections,
        "rtf": str(rtf_dst),
        "prm": str(prm_dst),
        "pdb": str(pdb_dst),
        "cache_dir": str(cdir),
        "session_file": str(cdir / "session.txt") if (cdir / "session.txt").is_file() else None,
    }
