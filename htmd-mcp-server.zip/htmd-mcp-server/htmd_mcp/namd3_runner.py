"""Run NAMD3 and parse its log."""

from __future__ import annotations

import os
import re
import shlex
import subprocess
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

NAMD3_BIN_DEFAULT = os.environ.get("NAMD3_BIN", "/usr/local/bin/namd3")


def _is_pid_alive(pid: int) -> bool:
    """Best-effort: return True if a process with this PID exists."""
    try:
        os.kill(int(pid), 0)
        return True
    except (OSError, ValueError, TypeError):
        return False


def _grep_numsteps(namd_input: Path) -> Optional[int]:
    """Pull ``numsteps N`` (or ``run N`` blocks summed) from a NAMD config."""
    if not namd_input.is_file():
        return None
    try:
        text = namd_input.read_text(errors="replace")
    except Exception:
        return None
    m = re.search(r"^\s*numsteps\s+(\d+)", text, re.MULTILINE | re.IGNORECASE)
    if m:
        return int(m.group(1))
    # Fall back to summing all "run N" blocks (equilibration uses this)
    runs = [int(x) for x in re.findall(r"^\s*run\s+(\d+)", text,
                                       re.MULTILINE | re.IGNORECASE)]
    return sum(runs) if runs else None


def _grep_timestep(namd_input: Path) -> Optional[float]:
    """Pull ``timestep`` (fs) from a NAMD config; defaults to 1.0 if absent."""
    if not namd_input.is_file():
        return None
    text = namd_input.read_text(errors="replace")
    m = re.search(r"^\s*timestep\s+([\d.]+)", text, re.MULTILINE | re.IGNORECASE)
    return float(m.group(1)) if m else 1.0


def _grep_firsttimestep(namd_input: Path) -> int:
    """Pull ``firsttimestep N`` from a NAMD config; 0 if absent. Used to
    convert the absolute TS counter that NAMD prints into a delta against
    the start of this run, so percent_complete behaves sanely when chaining
    or resuming runs."""
    if not namd_input.is_file():
        return 0
    try:
        text = namd_input.read_text(errors="replace")
    except Exception:
        return 0
    m = re.search(r"^\s*firsttimestep\s+(\d+)", text, re.MULTILINE | re.IGNORECASE)
    return int(m.group(1)) if m else 0


def _format_loop_suggestion(
    *, log: str, run_dir: str, total_steps: Optional[int],
    timestep_fs: Optional[float], ns_per_day: Optional[float] = None,
    pid: Optional[int] = None, namd_input_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Compose a human-pasteable ``/loop`` command + a default interval that
    matches the expected job duration."""
    # Estimate run duration in hours assuming 100 ns/day (typical NAMD3 speed)
    # if we don't have a measured value yet.
    speed = ns_per_day or 100.0
    eta_hours = None
    interval = "10m"  # sensible default
    if total_steps and timestep_fs:
        sim_ns = total_steps * timestep_fs * 1e-6
        eta_hours = sim_ns / speed * 24.0
        # Pick interval ~5% of expected runtime, clamped 60s..3600s
        interval_s = max(60, min(3600, int(eta_hours * 3600 * 0.05)))
        # Snap to nice values
        if interval_s <= 60:
            interval = "1m"
        elif interval_s <= 120:
            interval = "2m"
        elif interval_s <= 300:
            interval = "5m"
        elif interval_s <= 600:
            interval = "10m"
        elif interval_s <= 1200:
            interval = "20m"
        elif interval_s <= 1800:
            interval = "30m"
        else:
            interval = "1h"

    # NB: include pid + namd_input in the prompt so percent_complete,
    # eta_hours and is_running come back populated.
    pid_clause = f", pid={pid}" if pid is not None else ""
    namd_input_clause = (f", namd_input='{namd_input_path}'"
                         if namd_input_path else "")
    prompt = (
        f"Use the htmd-md MCP `monitor_namd_run` tool with "
        f"log='{log}'{pid_clause}{namd_input_clause}. "
        f"Summarize: status_message, current_step / total_steps "
        f"(percent_complete), ns_per_day, eta_hours, last temperature, "
        f"pressure, and total energy, plus any fatal_errors. If the run is "
        f"finished (`completed=true`) or `is_running=false`, say so and "
        f"stop the loop."
    )
    cmd = f"/loop {interval} {prompt}"

    return {
        "loop_suggestion": cmd,
        "loop_interval": interval,
        "expected_runtime_hours": eta_hours,
        "expected_runtime_speed_ns_per_day": speed,
    }


def parse_namd_log(
    log_path: str,
    *,
    pid: Optional[int] = None,
    namd_input: Optional[str] = None,
) -> Dict[str, Any]:
    """Pull the useful bits out of a NAMD3 log.

    Returns completion flag, latest energy line, ns/day, fatal/warning lines,
    and (when ``pid`` and/or ``namd_input`` are supplied) progress estimates:
    current step, percent complete, ETA in hours, and whether the process is
    still running.
    """
    if not os.path.isfile(log_path):
        return {"exists": False}

    energies: List[Dict[str, float]] = []
    fatals: List[str] = []
    warnings: List[str] = []
    last_ns_per_day: Optional[float] = None
    last_timing_step: Optional[int] = None
    last_timing_ns_per_day: Optional[float] = None
    end_of_program = False

    with open(log_path, "r", errors="replace") as fh:
        header: List[str] = []
        for line in fh:
            if line.startswith("ETITLE:"):
                header = line.split()[1:]
            elif line.startswith("ENERGY:") and header:
                parts = line.split()[1:]
                if len(parts) == len(header):
                    try:
                        energies.append({k: float(v) for k, v in zip(header, parts)})
                    except ValueError:
                        pass
            elif "FATAL ERROR" in line:
                fatals.append(line.rstrip())
            elif line.startswith("Warning:"):
                warnings.append(line.rstrip())
            elif line.startswith("TIMING:"):
                # "TIMING: 5000  CPU: 1.2, 0.001/step  Wall: ... 105.5 ns/days, ..."
                m_step = re.match(r"TIMING:\s+(\d+)", line)
                if m_step:
                    last_timing_step = int(m_step.group(1))
                m_speed = re.search(r"([\d.]+)\s*ns/days?", line)
                if m_speed:
                    last_timing_ns_per_day = float(m_speed.group(1))
                    last_ns_per_day = last_timing_ns_per_day
            elif "Benchmark time:" in line and "ns/day" in line:
                m = re.search(r"([\d.]+)\s*ns/day", line)
                if m:
                    last_ns_per_day = float(m.group(1))
            elif "End of program" in line:
                end_of_program = True

    # Current step: prefer TIMING line, fall back to last ENERGY TS field
    current_step: Optional[int] = last_timing_step
    if current_step is None and energies:
        ts = energies[-1].get("TS")
        if ts is not None:
            current_step = int(ts)

    out: Dict[str, Any] = {
        "exists": True,
        "completed": end_of_program,
        "n_energy_records": len(energies),
        "last_energy": energies[-1] if energies else None,
        "ns_per_day": last_ns_per_day,
        "current_step": current_step,
        "fatal_errors": fatals,
        "warnings": warnings[-20:],  # tail only
    }

    # Progress estimation when we have job context
    if namd_input:
        total_steps = _grep_numsteps(Path(namd_input))
        timestep_fs = _grep_timestep(Path(namd_input)) or 1.0
        firsttimestep = _grep_firsttimestep(Path(namd_input))
        out["total_steps"] = total_steps
        out["timestep_fs"] = timestep_fs
        out["firsttimestep"] = firsttimestep
        if total_steps and current_step is not None:
            # NAMD's TS counter is absolute (firsttimestep + steps_run_so_far),
            # while total_steps is a delta (sum of `run N` blocks or numsteps).
            # Compute progress against the delta so percents stay in [0, 100].
            steps_done = max(0, current_step - firsttimestep)
            pct = 100.0 * steps_done / total_steps
            out["percent_complete"] = float(pct)
            if last_ns_per_day and last_ns_per_day > 0:
                remaining_steps = max(0, total_steps - steps_done)
                remaining_ns = remaining_steps * timestep_fs * 1e-6
                out["eta_hours"] = float(remaining_ns / last_ns_per_day * 24.0)

    if pid is not None:
        out["is_running"] = _is_pid_alive(int(pid))
        out["pid"] = int(pid)

    # Concise human-readable status message
    if end_of_program:
        out["status_message"] = "completed"
    elif fatals:
        out["status_message"] = "FATAL ERROR — see fatal_errors"
    elif out.get("is_running") is False:
        out["status_message"] = "process exited but no End-of-program line — likely crashed"
    elif "percent_complete" in out:
        out["status_message"] = (
            f"running, {out['percent_complete']:.1f}% complete"
            + (f", {last_ns_per_day:.1f} ns/day" if last_ns_per_day else "")
            + (f", ETA {out['eta_hours']:.1f} h" if "eta_hours" in out else "")
        )
    else:
        out["status_message"] = "running" if out.get("is_running", False) else "no progress info"

    return out


def run_namd3(
    run_dir: str,
    namd_input: str = "min.namd",
    *,
    num_threads: int = 1,
    gpu_devices: str = "0",
    log_name: str = "log.txt",
    namd3_bin: Optional[str] = None,
    wait: bool = True,
    timeout_s: Optional[int] = None,
) -> Dict[str, Any]:
    """Launch NAMD3 in ``run_dir``.

    If ``wait`` is True the call blocks until completion (or ``timeout_s``)
    and returns parsed log info. If False, returns the PID and log path so
    the caller can poll later.
    """
    run_dir = os.path.abspath(run_dir)
    bin_path = namd3_bin or NAMD3_BIN_DEFAULT
    if not os.path.isfile(bin_path) or not os.access(bin_path, os.X_OK):
        return {"status": "error", "error": f"NAMD3 binary not executable: {bin_path}"}
    if not os.path.isfile(os.path.join(run_dir, namd_input)):
        return {
            "status": "error",
            "error": f"{namd_input} not found in {run_dir}",
        }

    cmd = [bin_path, "+p", str(int(num_threads))]
    if gpu_devices:
        cmd += ["+devices", str(gpu_devices)]
    cmd += [namd_input]

    log_path = os.path.join(run_dir, log_name)
    log_fh = open(log_path, "w")
    started = time.time()
    proc = subprocess.Popen(
        cmd,
        cwd=run_dir,
        stdout=log_fh,
        stderr=subprocess.STDOUT,
    )

    if not wait:
        namd_input_path = Path(run_dir) / namd_input
        total_steps = _grep_numsteps(namd_input_path)
        timestep_fs = _grep_timestep(namd_input_path)
        loop = _format_loop_suggestion(
            log=log_path, run_dir=run_dir,
            total_steps=total_steps, timestep_fs=timestep_fs,
            pid=proc.pid, namd_input_path=str(namd_input_path),
        )
        return {
            "status": "started",
            "pid": proc.pid,
            "run_dir": run_dir,
            "log": log_path,
            "namd_input": str(namd_input_path),
            "total_steps": total_steps,
            "timestep_fs": timestep_fs,
            "cmd": " ".join(cmd),
            "human_message": (
                f"NAMD3 running in background (PID {proc.pid}). "
                f"Estimated runtime: "
                + (f"{loop['expected_runtime_hours']:.1f} h"
                   if loop.get("expected_runtime_hours") else "unknown")
                + ". To monitor, paste the loop_suggestion below into Claude "
                "Code; it will tail the log every "
                + loop["loop_interval"] + " until the run finishes."
            ),
            **loop,
        }

    try:
        proc.wait(timeout=timeout_s)
    except subprocess.TimeoutExpired:
        proc.kill()
        log_fh.close()
        info = parse_namd_log(log_path)
        return {
            "status": "timeout",
            "elapsed_s": time.time() - started,
            "log": log_path,
            "cmd": " ".join(cmd),
            "log_summary": info,
        }
    log_fh.close()

    info = parse_namd_log(log_path)
    return {
        "status": "ok" if proc.returncode == 0 else "error",
        "returncode": proc.returncode,
        "elapsed_s": time.time() - started,
        "log": log_path,
        "cmd": " ".join(cmd),
        "log_summary": info,
    }
