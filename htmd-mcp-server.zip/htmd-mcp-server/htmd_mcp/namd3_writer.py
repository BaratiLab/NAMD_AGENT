"""Generate NAMD3 input files from Jinja-style templates.

We avoid an extra dependency (Jinja2) by implementing the small subset of
template syntax we actually use: ``{{ var }}`` substitution, ``{% if %}``,
``{% for %}`` blocks. Templates live next to this file under ``templates/``.
"""

from __future__ import annotations

import os
import re
import shutil
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np

TEMPLATE_DIR = Path(__file__).resolve().parent / "templates"


def _render(template: str, ctx: Dict[str, Any]) -> str:
    """Tiny renderer: ``{{ var }}``, ``{% if x %}...{% endif %}``,
    ``{% for x in xs %}...{% endfor %}``. No filters, no nesting beyond one level.
    """
    # for-loops
    def for_sub(m: re.Match) -> str:
        var = m.group(1).strip()
        coll = m.group(2).strip()
        body = m.group(3)
        items = ctx.get(coll, [])
        out = []
        for item in items:
            local_ctx = dict(ctx)
            local_ctx[var] = item
            out.append(_render(body, local_ctx))
        return "".join(out)

    template = re.sub(
        r"{%\s*for\s+(\w+)\s+in\s+(\w+)\s*%}(.*?){%\s*endfor\s*%}",
        for_sub,
        template,
        flags=re.DOTALL,
    )

    # if-blocks (no else)
    def if_sub(m: re.Match) -> str:
        cond = m.group(1).strip()
        body = m.group(2)
        return body if ctx.get(cond) else ""

    template = re.sub(
        r"{%\s*if\s+(\w+)\s*%}(.*?){%\s*endif\s*%}",
        if_sub,
        template,
        flags=re.DOTALL,
    )

    # variable substitution: supports dotted access like 'stage.scale'
    def var_sub(m: re.Match) -> str:
        key = m.group(1).strip()
        parts = key.split(".")
        if parts[0] not in ctx:
            raise KeyError(f"Template variable '{parts[0]}' not provided")
        val: Any = ctx[parts[0]]
        for p in parts[1:]:
            if isinstance(val, dict) and p in val:
                val = val[p]
            else:
                val = getattr(val, p)
        return str(val)

    return re.sub(r"{{\s*([\w_.]+)\s*}}", var_sub, template)


def _read_template(name: str) -> str:
    return (TEMPLATE_DIR / name).read_text()


def stage_charmm_parameters(build_dir: str, run_dir: str) -> List[str]:
    """Copy CHARMM parameter files from build_dir into run_dir/parameters/.

    Always stages the default set used by ``charmm.defaultTopo``. If the build
    step persisted a list of additional CHARMM stream files (cholesterol etc.)
    in ``build_dir/extra_streams.json``, their parameter sections are extracted
    into clean .prm files and added too.

    Returns the list of basename-relative parameter paths for the NAMD3
    ``parameters`` directive.
    """
    from htmd.builder.charmm import htmdCharmmHome
    import json as _json

    par_dir = Path(run_dir) / "parameters"
    par_dir.mkdir(parents=True, exist_ok=True)

    charmm_share = Path(htmdCharmmHome())
    defaults = [
        "par/par_all36m_prot.prm",
        "par/par_all36_lipid.prm",
        "par/par_all36_carb.prm",
        "par/par_all36_na.prm",
        "par/par_all36_cgenff.prm",
        "par/par_water_ions.prm",
    ]
    staged: List[str] = []
    for rel in defaults:
        src = charmm_share / rel
        if src.is_file():
            dst = par_dir / src.name
            _copy_truncated_at_end(src, dst)
            staged.append(f"parameters/{src.name}")

    # Extra CHARMM stream files (cholesterol etc.) — extract their parameter
    # section into a clean .prm.
    streams_meta = Path(build_dir) / "extra_streams.json"
    if streams_meta.is_file():
        rel_paths = _json.loads(streams_meta.read_text())
        for rel in rel_paths:
            src = charmm_share / rel
            if not src.is_file():
                continue
            dst_basename = Path(rel).name.replace(".str", "_param.prm")
            dst = par_dir / dst_basename
            _extract_charmm_params_from_str(src, dst)
            staged.append(f"parameters/{dst_basename}")

    # Extra plain .prm files (e.g. Swiss-Param ligand parameters) — copy as-is.
    params_meta = Path(build_dir) / "extra_params.json"
    if params_meta.is_file():
        for abs_path in _json.loads(params_meta.read_text()):
            src = Path(abs_path)
            if not src.is_file():
                continue
            dst = par_dir / src.name
            _copy_truncated_at_end(src, dst)
            staged.append(f"parameters/{src.name}")

    return staged


def _copy_truncated_at_end(src: Path, dst: Path) -> None:
    """Copy a CHARMM .prm to dst, dropping anything after the first standalone
    ``END`` line. Several CHARMM-distributed parameter files (e.g.
    par_water_ions.prm) include CHARMM control script after the END marker,
    which NAMD's parser misreads as more vdW pairs."""
    with open(src, "r", errors="replace") as fin:
        lines: List[str] = []
        for line in fin:
            stripped = line.strip()
            lines.append(line)
            if stripped == "END":
                break
    with open(dst, "w") as fout:
        fout.writelines(lines)


def _extract_charmm_params_from_str(src: Path, dst: Path) -> None:
    """Extract a clean parameter file out of a CHARMM stream (.str) file.

    Stream files contain ``read rtf`` and ``read param`` blocks separated by
    ``end`` lines, and may use CHARMM ``if``/``else``/``endif`` to switch
    between alternative force-field models. NAMD's parser doesn't speak CHARMM
    script, so we keep only the FIRST parameter block.

    Output is a self-contained .prm file: header comments + the parameter
    sections (BONDS / ANGLES / DIHEDRALS / IMPROPERS / NONBONDED / NBFIX /
    HBOND / CMAP / END) up to the first ``end`` after ``read param``.
    """
    keep_lines: List[str] = []
    in_param = False

    with open(src, "r", errors="replace") as fin:
        for line in fin:
            stripped = line.strip().lower()
            if not in_param:
                if stripped.startswith("read para"):
                    in_param = True
                continue
            # End of this parameter block — stop here. We deliberately DO NOT
            # follow ``if``/``elseif`` branches into a second model.
            if stripped == "end":
                keep_lines.append("END\n")
                break
            # Drop CHARMM control directives that NAMD can't parse.
            if stripped.startswith(("if ", "if(", "else", "endif", "set ",
                                    "return", "stop", "@", "bomlev", "wrnlev",
                                    "calc ")):
                continue
            keep_lines.append(line)

    if not keep_lines:
        raise RuntimeError(f"no parameter section found in {src}")

    with open(dst, "w") as fout:
        fout.write(f"* Extracted parameters from {src.name}\n*\n\n")
        fout.writelines(keep_lines)


def write_restraint_pdb(
    pdb_path: str,
    out_path: str,
    selection: str,
    k_kcal_per_mol_A2: float,
) -> int:
    """Write a copy of ``pdb_path`` whose B-factor column equals
    ``k_kcal_per_mol_A2`` for atoms matching ``selection`` and 0 elsewhere.
    NAMD reads this column when ``constraints on`` + ``consKCol B`` is set.
    Returns the number of atoms restrained.
    """
    from moleculekit.molecule import Molecule

    mol = Molecule(pdb_path)
    sel = mol.atomselect(selection)
    mol.beta = np.zeros(mol.numAtoms, dtype=np.float32)
    mol.beta[sel] = float(k_kcal_per_mol_A2)
    mol.write(out_path)
    return int(np.sum(sel))


def _read_xsc_step(xsc_path: Path) -> int:
    """Return the step counter from a NAMD ``.xsc`` file (0 if missing or
    unparseable). The first column of every non-comment line is the
    timestep; we keep the last one. Used to set ``firsttimestep`` so the
    DCD time axis stays continuous when chaining or resuming runs."""
    if not xsc_path.is_file():
        return 0
    last = 0
    try:
        for line in xsc_path.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            try:
                last = int(line.split()[0])
            except (ValueError, IndexError):
                continue
    except OSError:
        return 0
    return int(last)


def pbc_block_from_pdb(pdb_path: str) -> str:
    """Build the NAMD ``cellBasisVector*`` + ``cellOrigin`` block from the
    coordinate range of the input PDB (the system has been solvated, so
    coordinate min/max already define the periodic cell).
    """
    from moleculekit.molecule import Molecule

    mol = Molecule(pdb_path)
    coords = mol.coords[:, :, 0]
    mn = coords.min(axis=0)
    mx = coords.max(axis=0)
    box = mx - mn
    center = (mx + mn) / 2
    return (
        f"cellBasisVector1   {box[0]:.4f} 0.0000 0.0000\n"
        f"cellBasisVector2   0.0000 {box[1]:.4f} 0.0000\n"
        f"cellBasisVector3   0.0000 0.0000 {box[2]:.4f}\n"
        f"cellOrigin         {center[0]:.4f} {center[1]:.4f} {center[2]:.4f}"
    )


def write_minimization(
    build_dir: str,
    run_dir: str,
    *,
    steps: int = 5000,
    temperature: float = 300.0,
    timestep_fs: float = 1.0,
    output_freq: int = 100,
    restraint_selection: Optional[str] = "protein and noh and not name CA",
    restraint_k: float = 1.0,
    cuda_soa: bool = True,
    seed: Optional[int] = None,
    forcefield: str = "charmm",
) -> Dict[str, Any]:
    """Write min.namd + restraint PDB into run_dir. Returns input metadata."""
    if forcefield != "charmm":
        raise NotImplementedError("only CHARMM is wired in this build")

    build_dir = os.path.abspath(build_dir)
    run_dir = os.path.abspath(run_dir)
    os.makedirs(run_dir, exist_ok=True)

    # Stage structure files
    psf_src = os.path.join(build_dir, "structure.psf")
    pdb_src = os.path.join(build_dir, "structure.pdb")
    if not (os.path.isfile(psf_src) and os.path.isfile(pdb_src)):
        raise FileNotFoundError(
            f"Expected structure.psf and structure.pdb in {build_dir}"
        )
    shutil.copy(psf_src, os.path.join(run_dir, "structure.psf"))
    shutil.copy(pdb_src, os.path.join(run_dir, "structure.pdb"))

    parameters = stage_charmm_parameters(build_dir, run_dir)

    # Restraint PDB
    use_restraints = restraint_selection is not None and restraint_k > 0
    restraint_pdb = "restraint.pdb"
    n_restrained = 0
    if use_restraints:
        n_restrained = write_restraint_pdb(
            os.path.join(run_dir, "structure.pdb"),
            os.path.join(run_dir, restraint_pdb),
            restraint_selection,
            restraint_k,
        )

    pbc_block = pbc_block_from_pdb(os.path.join(run_dir, "structure.pdb"))

    ctx = {
        "psf": "structure.psf",
        "pdb": "structure.pdb",
        "parameters": parameters,
        "temperature": f"{temperature:g}",
        "pbc_block": pbc_block,
        "timestep": f"{timestep_fs:g}",
        "outname": "min",
        "output_freq": int(output_freq),
        "use_restraints": use_restraints,
        "restraint_pdb": restraint_pdb,
        "cuda_soa": bool(cuda_soa),
        "seed": int(seed) if seed is not None else 0,
        "steps": int(steps),
    }
    rendered = _render(_read_template("minimize_charmm.namd.tmpl"), ctx)
    namd_path = os.path.join(run_dir, "min.namd")
    with open(namd_path, "w") as fh:
        fh.write(rendered)

    return {
        "namd_input": namd_path,
        "run_dir": run_dir,
        "n_restrained_atoms": n_restrained,
        "parameters": parameters,
    }


# --- Helpers shared by equil/prod -------------------------------------------

def _stage_run_inputs(prev_dir: str, run_dir: str, prev_outname: str) -> Dict[str, bool]:
    """Stage structure.psf, parameters/, and the prev run's coor/vel/xsc into
    ``run_dir`` as ``input.coor`` / ``input.vel`` / ``input.xsc``.

    Looks for ``{prev_outname}.coor`` first, then ``{prev_outname}.restart.coor``.
    Returns a flag dict telling the caller whether vel/xsc are present so the
    template can omit references to missing files.
    """
    prev_dir = os.path.abspath(prev_dir)
    run_dir = os.path.abspath(run_dir)
    os.makedirs(run_dir, exist_ok=True)

    # PSF + PDB (need PDB for atom labels in restraint creation)
    for fname in ("structure.psf", "structure.pdb"):
        src = os.path.join(prev_dir, fname)
        if os.path.isfile(src):
            shutil.copy(src, os.path.join(run_dir, fname))
        else:
            raise FileNotFoundError(f"missing {fname} in {prev_dir}")

    # Parameters dir
    src_par = os.path.join(prev_dir, "parameters")
    dst_par = os.path.join(run_dir, "parameters")
    if os.path.isdir(src_par):
        if os.path.isdir(dst_par):
            shutil.rmtree(dst_par)
        shutil.copytree(src_par, dst_par)
    else:
        # Fall back to fresh staging from htmd share
        stage_charmm_parameters(prev_dir, run_dir)

    flags = {"has_input": False, "has_velocities": False, "has_xsc": False}

    def _try_copy(suffixes, dst_basename, flag):
        for suffix in suffixes:
            cand = os.path.join(prev_dir, f"{prev_outname}{suffix}")
            if os.path.isfile(cand):
                shutil.copy(cand, os.path.join(run_dir, dst_basename))
                flags[flag] = True
                return
            cand = os.path.join(prev_dir, f"{prev_outname}.restart{suffix}")
            if os.path.isfile(cand):
                shutil.copy(cand, os.path.join(run_dir, dst_basename))
                flags[flag] = True
                return

    _try_copy([".coor"], "input.coor", "has_input")
    _try_copy([".vel"], "input.vel", "has_velocities")
    _try_copy([".xsc"], "input.xsc", "has_xsc")

    return flags


def _list_param_basenames(run_dir: str) -> List[str]:
    par_dir = os.path.join(run_dir, "parameters")
    if not os.path.isdir(par_dir):
        return []
    return [f"parameters/{n}" for n in sorted(os.listdir(par_dir))
            if n.endswith(".prm") or n.endswith(".str")]


# --- Equilibration ----------------------------------------------------------

def write_equilibration(
    prev_dir: str,
    run_dir: str,
    *,
    run_ns: float = 1.0,
    temperature: float = 300.0,
    pressure: float = 1.01325,
    timestep_fs: float = 2.0,
    minimize_first: bool = True,
    minimize_steps: int = 1000,
    restraint_selection: str = "protein and name CA",
    restraint_k: float = 1.0,
    restraint_schedule: Optional[List[List[float]]] = None,
    membrane: bool = False,
    margin: float = 2.0,
    output_freq: int = 5000,
    dcd_freq: int = 5000,
    restart_freq: int = 50000,
    cuda_soa: bool = True,
    ensemble: str = "NPT",
    thermostat: str = "langevin",
    barostat: str = "langevin",
    thermostat_period_ps: float = 1.0,
    seed: Optional[int] = None,
    forcefield: str = "charmm",
    resume: bool = False,
    resume_outname: str = "equil",
) -> Dict[str, Any]:
    """Write equil.namd + restraint PDB into run_dir.

    Parameters
    ----------
    prev_dir
        Directory of the previous step. Normally the minimization run dir
        (we look for ``min.coor/.vel/.xsc``). When ``resume=True`` this should
        be the equilibration run dir itself (we look for
        ``equil.restart.{coor,vel,xsc}`` first, then ``equil.{coor,vel,xsc}``).
    run_ns
        Total equilibration time in nanoseconds, summed across stages. In
        resume mode this is the *remaining* time, i.e. how much equilibration
        is left after the crash; pair it with a ``restraint_schedule`` that
        also describes only the remaining stages.
    restraint_schedule
        List of [scale_factor, fraction_of_total_time] pairs that scale the
        ``restraint_k`` of ``restraint_selection``. Default is a 4-stage ramp
        1.0 → 0.5 → 0.1 → 0.0 over 25/25/25/25% of total time.
    membrane
        If True, sets ``useFlexibleCell`` + ``useConstantRatio`` on so the
        bilayer can equilibrate area-per-lipid while keeping x/y locked.
    margin
        NAMD ``margin`` setting (Å). Bumping this above the default 2.0 (e.g.
        to 4–5) gives the patch grid headroom against further box shrinkage.
        Recommended for membrane equilibrations where the bilayer packs and
        a too-small margin can trigger ``Periodic cell has become too small
        for original patch grid``.
    resume
        If True, treat ``prev_dir`` as the equilibration directory itself and
        stage from ``equil.restart.*`` so the run continues from where it
        crashed. Forces ``minimize_first=False`` (the system has already been
        minimized) and writes to ``equil_resume.namd`` to preserve the
        original ``equil.namd``.
    resume_outname
        Basename to look for in ``prev_dir`` when ``resume=True``. Defaults
        to ``"equil"``; rarely needs overriding.
    """
    if forcefield != "charmm":
        raise NotImplementedError("only CHARMM is wired in this build")
    ensemble = ensemble.upper()
    if ensemble not in ("NPT", "NVT"):
        raise ValueError(f"ensemble must be 'NPT' or 'NVT', got {ensemble!r}")
    thermostat = thermostat.lower()
    if thermostat not in ("langevin", "bussi"):
        raise ValueError(
            f"thermostat must be 'langevin' or 'bussi' (NAMD stochastic "
            f"velocity rescaling), got {thermostat!r}")
    barostat = barostat.lower()
    if barostat not in ("langevin", "berendsen"):
        raise ValueError(
            f"barostat must be 'langevin' (Langevin piston, NHL/MTK) or "
            f"'berendsen', got {barostat!r}. NAMD has no Parrinello-Rahman "
            f"barostat; 'langevin' is the closest equivalent.")

    if resume:
        # Resume mode: stage from prev_dir's equil.restart.* (or equil.*).
        # The system has been minimized + heated already, so don't redo that.
        minimize_first = False
        prev_outname_for_staging = resume_outname
    else:
        prev_outname_for_staging = "min"
    flags = _stage_run_inputs(prev_dir, run_dir, prev_outname=prev_outname_for_staging)

    if resume and not (flags["has_input"] and flags["has_velocities"] and flags["has_xsc"]):
        raise RuntimeError(
            f"resume=True requires {resume_outname}.{{coor,vel,xsc}} (or "
            f"{resume_outname}.restart.{{coor,vel,xsc}}) in {prev_dir}; got {flags}"
        )
    parameters = _list_param_basenames(run_dir)

    # Carry the timestep counter forward so DCD frame indices stay
    # continuous across stages (and across resumes within a stage).
    firsttimestep_value = _read_xsc_step(Path(run_dir) / "input.xsc")

    # Restraint PDB
    use_restraints = restraint_selection is not None and restraint_k > 0
    restraint_pdb = "restraint.pdb"
    n_restrained = 0
    if use_restraints:
        n_restrained = write_restraint_pdb(
            os.path.join(run_dir, "structure.pdb"),
            os.path.join(run_dir, restraint_pdb),
            restraint_selection,
            float(restraint_k),
        )

    # Build stages
    if restraint_schedule is None:
        restraint_schedule = [[1.0, 0.25], [0.5, 0.25], [0.1, 0.25], [0.0, 0.25]]
    total_steps = int(round(run_ns * 1e6 / timestep_fs))
    stages = []
    accounted = 0
    for i, (scale, frac) in enumerate(restraint_schedule):
        if i == len(restraint_schedule) - 1:
            steps_i = total_steps - accounted
        else:
            steps_i = max(1, int(round(total_steps * float(frac))))
            accounted += steps_i
        stages.append({"scale": f"{float(scale):g}", "steps": int(steps_i)})

    # PBC: if no input.xsc, fall back to PDB-derived box
    needs_pbc = not flags["has_xsc"]
    pbc_block = pbc_block_from_pdb(os.path.join(run_dir, "structure.pdb")) \
        if needs_pbc else ""

    ctx = {
        "psf": "structure.psf",
        "pdb": "structure.pdb",
        "parameters": parameters,
        "temperature": f"{temperature:g}",
        "pressure": f"{pressure:g}",
        "timestep": f"{timestep_fs:g}",
        "outname": "equil",
        "output_freq": int(output_freq),
        "dcd_freq": int(dcd_freq),
        "restart_freq": int(restart_freq),
        "use_restraints": use_restraints,
        "restraint_pdb": restraint_pdb,
        "flex_cell": "yes" if membrane else "no",
        "constant_ratio": "yes" if membrane else "no",
        "margin": f"{float(margin):g}",
        "cuda_soa": bool(cuda_soa),
        "minimize_first": bool(minimize_first),
        "minimize_steps": int(minimize_steps),
        "stages": stages,
        "has_input": flags["has_input"],
        "has_velocities": flags["has_velocities"],
        "needs_temperature": not flags["has_velocities"],
        "needs_pbc_block": needs_pbc,
        "pbc_block": pbc_block,
        "ensemble": ensemble,
        "npt": ensemble == "NPT",
        "thermostat_langevin": thermostat == "langevin",
        "thermostat_bussi": thermostat == "bussi",
        "thermostat_period": f"{float(thermostat_period_ps):g}",
        "barostat_langevin_npt": ensemble == "NPT" and barostat == "langevin",
        "barostat_berendsen_npt": ensemble == "NPT" and barostat == "berendsen",
        "seed": int(seed) if seed is not None else 0,
        "firsttimestep_value": int(firsttimestep_value),
    }
    rendered = _render(_read_template("equilibrate_charmm.namd.tmpl"), ctx)
    namd_filename = "equil_resume.namd" if resume else "equil.namd"
    namd_path = os.path.join(run_dir, namd_filename)
    with open(namd_path, "w") as fh:
        fh.write(rendered)

    return {
        "namd_input": namd_path,
        "run_dir": run_dir,
        "n_restrained_atoms": n_restrained,
        "parameters": parameters,
        "stages": stages,
        "total_steps": total_steps,
        "membrane": bool(membrane),
        "margin": float(margin),
        "input_files": flags,
        "ensemble": ensemble,
        "thermostat": thermostat,
        "barostat": barostat if ensemble == "NPT" else None,
        "firsttimestep": int(firsttimestep_value),
        "seed": int(seed) if seed is not None else None,
        "resume": bool(resume),
    }


# --- Production -------------------------------------------------------------

def apply_hmr_to_psf(psf_in: str, psf_out: str) -> Dict[str, Any]:
    """Run parmed's HMassRepartition on a CHARMM PSF, writing a new PSF.

    Repartitions hydrogen masses (default 3.024 amu) by subtracting the gain
    from the bonded heavy atom. Allows 4 fs timesteps with rigidBonds all.
    """
    import parmed as pmd
    from parmed.tools import HMassRepartition

    psf = pmd.charmm.CharmmPsfFile(psf_in)
    HMassRepartition(psf).execute()
    psf.write_psf(psf_out)
    masses = [a.mass for a in psf.atoms]
    return {
        "psf": psf_out,
        "n_atoms": len(masses),
        "min_mass": float(min(masses)),
        "max_mass": float(max(masses)),
    }


def write_production(
    prev_dir: str,
    run_dir: str,
    *,
    run_ns: float = 100.0,
    temperature: float = 300.0,
    pressure: float = 1.01325,
    timestep_fs: float = 4.0,
    hydrogen_mass_repartition: bool = True,
    membrane: bool = False,
    margin: float = 2.0,
    dcd_freq_ps: float = 10.0,
    restart_freq_ps: float = 100.0,
    output_freq: int = 5000,
    cuda_soa: bool = True,
    ensemble: str = "NPT",
    thermostat: str = "langevin",
    barostat: str = "langevin",
    thermostat_period_ps: float = 1.0,
    barostat_period_ps: float = 0.2,
    seed: Optional[int] = None,
    forcefield: str = "charmm",
) -> Dict[str, Any]:
    """Write prod.namd. Stages prev_dir's equilibrated state and (by default)
    runs HMassRepartition on the PSF so a 4 fs timestep is safe.

    The template emits ``run N`` (delta from firsttimestep), so the duration
    actually run is ``run_ns`` regardless of the equilibration's final step
    counter. (Earlier versions emitted ``numsteps`` which NAMD treats as an
    absolute target, leading to truncated runs when firsttimestep was high.)

    Set ``margin`` above the default 2.0 (e.g. 4–5) for membrane systems
    where the bilayer has packed and the patch grid is tight."""
    if forcefield != "charmm":
        raise NotImplementedError("only CHARMM is wired in this build")
    ensemble = ensemble.upper()
    if ensemble not in ("NPT", "NVT"):
        raise ValueError(f"ensemble must be 'NPT' or 'NVT', got {ensemble!r}")
    thermostat = thermostat.lower()
    if thermostat not in ("langevin", "bussi"):
        raise ValueError(
            f"thermostat must be 'langevin' or 'bussi' (NAMD stochastic "
            f"velocity rescaling), got {thermostat!r}")
    barostat = barostat.lower()
    if barostat not in ("langevin", "berendsen"):
        raise ValueError(
            f"barostat must be 'langevin' (Langevin piston, NHL/MTK) or "
            f"'berendsen', got {barostat!r}. NAMD has no Parrinello-Rahman "
            f"barostat; 'langevin' is the closest equivalent.")

    flags = _stage_run_inputs(prev_dir, run_dir, prev_outname="equil")
    if not (flags["has_input"] and flags["has_velocities"] and flags["has_xsc"]):
        raise RuntimeError(
            f"Expected equil.coor/.vel/.xsc in {prev_dir} (got {flags}); "
            "production needs a complete restartable equilibration state."
        )
    parameters = _list_param_basenames(run_dir)

    # Optional HMR
    hmr_info = None
    if hydrogen_mass_repartition:
        psf_in = os.path.join(run_dir, "structure.psf")
        psf_out = os.path.join(run_dir, "structure_hmr.psf")
        hmr_info = apply_hmr_to_psf(psf_in, psf_out)
        psf_for_run = "structure_hmr.psf"
    else:
        psf_for_run = "structure.psf"

    total_steps = int(round(run_ns * 1e6 / timestep_fs))
    dcd_steps = max(1, int(round(dcd_freq_ps * 1000.0 / timestep_fs)))
    rst_steps = max(dcd_steps, int(round(restart_freq_ps * 1000.0 / timestep_fs)))
    firsttimestep_value = _read_xsc_step(Path(run_dir) / "input.xsc")

    ctx = {
        "psf": psf_for_run,
        "pdb": "structure.pdb",
        "parameters": parameters,
        "temperature": f"{temperature:g}",
        "pressure": f"{pressure:g}",
        "timestep": f"{timestep_fs:g}",
        "outname": "prod",
        "output_freq": int(output_freq),
        "dcd_freq": int(dcd_steps),
        "restart_freq": int(rst_steps),
        "flex_cell": "yes" if membrane else "no",
        "constant_ratio": "yes" if membrane else "no",
        "margin": f"{float(margin):g}",
        "cuda_soa": bool(cuda_soa),
        "ensemble": ensemble,
        "npt": ensemble == "NPT",
        "thermostat_langevin": thermostat == "langevin",
        "thermostat_bussi": thermostat == "bussi",
        "thermostat_period": f"{float(thermostat_period_ps):g}",
        "barostat_langevin_npt": ensemble == "NPT" and barostat == "langevin",
        "barostat_berendsen_npt": ensemble == "NPT" and barostat == "berendsen",
        "piston_period": f"{float(barostat_period_ps) * 1000.0:g}",
        "piston_decay": f"{float(barostat_period_ps) * 1000.0 / 2.0:g}",
        "seed": int(seed) if seed is not None else 0,
        "firsttimestep_value": int(firsttimestep_value),
        "num_steps": int(total_steps),
    }
    rendered = _render(_read_template("produce_charmm.namd.tmpl"), ctx)
    namd_path = os.path.join(run_dir, "prod.namd")
    with open(namd_path, "w") as fh:
        fh.write(rendered)

    return {
        "namd_input": namd_path,
        "run_dir": run_dir,
        "parameters": parameters,
        "total_steps": total_steps,
        "dcd_steps": dcd_steps,
        "restart_steps": rst_steps,
        "hmr": hmr_info,
        "psf_used": psf_for_run,
        "ensemble": ensemble,
        "thermostat": thermostat,
        "barostat": barostat if ensemble == "NPT" else None,
        "margin": float(margin),
        "firsttimestep": int(firsttimestep_value),
        "seed": int(seed) if seed is not None else None,
    }
