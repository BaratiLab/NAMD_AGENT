"""Build a protein + ligand system for MD."""

from __future__ import annotations

import json
import logging
import os
from typing import Any, Dict, List, Optional

import numpy as np

logger = logging.getLogger(__name__)


def parametrize_ligand(
    ligand_input: str,
    ligand_resname: str = "LIG",
    *,
    method: str = "swissparam",
    outdir: str = "lig_params",
    refresh: bool = False,
) -> Dict[str, Any]:
    """Parametrize a small molecule for CHARMM. Currently supports
    Swiss-Param (CGenFF-style atom types). Returns paths to .rtf, .prm, .pdb.
    """
    if method != "swissparam":
        raise NotImplementedError(f"unknown parametrization method {method!r}")
    from htmd_mcp.swissparam import parametrize_ligand_swissparam
    return parametrize_ligand_swissparam(
        ligand_input,
        ligand_resname=ligand_resname,
        outdir=outdir,
        refresh=refresh,
    )


def _place_ligand(prot, lig, place_at: Optional[List[float]],
                 random_far: bool, seed: Optional[int],
                 prot_pre_center_com: Optional[np.ndarray] = None,
                 ) -> Dict[str, Any]:
    """Apply rotation + translation to ``lig`` in place. Returns metadata.

    When ``place_at`` is None and ``random_far`` is False, treat the
    ligand input as already in its bound pose: do not re-center it.
    Instead apply the same translation that was applied to the protein
    (passed in via ``prot_pre_center_com``), so the relative
    protein-ligand geometry is preserved.
    """
    from moleculekit.util import maxDistance, uniformRandomRotation

    rng = np.random.default_rng(seed)

    if place_at is not None:
        lig.center()
        lig.moveBy(np.array(place_at, dtype=float))
        return {"placement": "fixed", "xyz": list(map(float, place_at))}

    if random_far:
        lig.center()
        # Random rotation, then translate +X by max(protein-extent) + 10 Å
        # so the ligand starts well outside the binding site.
        # We seed numpy then call HTMD's uniformRandomRotation (which uses
        # the global RNG state).
        np.random.seed(int(rng.integers(0, 2**31 - 1)))
        lig.rotateBy(uniformRandomRotation())
        d = float(maxDistance(prot, "all")) + 10.0
        lig.moveBy([d, 0.0, 0.0])
        np.random.seed(int(rng.integers(0, 2**31 - 1)))
        lig.rotateBy(uniformRandomRotation())
        return {"placement": "random_far", "distance": d}

    # Preserve binding pose: keep the ligand at its input coordinates and
    # apply the same translation we applied to the protein when we
    # centered it, so the relative geometry is intact.
    if prot_pre_center_com is None:
        # Backwards-compatible fallback: caller forgot to pass the
        # pre-centering COM. Best we can do is leave the ligand alone.
        return {"placement": "input_coords_no_shift"}
    lig.moveBy(-np.asarray(prot_pre_center_com, dtype=float))
    return {
        "placement": "input_coords_preserved",
        "applied_shift_A": list(map(float, -np.asarray(prot_pre_center_com))),
    }


def build_protein_ligand(
    protein_pdb: str,
    *,
    ligand_input: Optional[str] = None,
    ligand_rcsb_id: Optional[str] = None,
    ligand_smiles: Optional[str] = None,
    ligand_resname: str = "LIG",
    parametrize: bool = True,
    parametrize_method: str = "swissparam",
    ligand_rtf: Optional[str] = None,
    ligand_prm: Optional[str] = None,
    ligand_pdb: Optional[str] = None,
    place_at: Optional[List[float]] = None,
    random_far: bool = True,
    pad: float = 12.0,
    saltconc: float = 0.15,
    cation: str = "SOD",
    anion: str = "CLA",
    pH: float = 7.4,
    forcefield: str = "charmm",
    outdir: str = "build_proteinlig",
    seed: Optional[int] = None,
    keep_selection_protein: Optional[str] = None,
    remove_selection_protein: Optional[str] = "resname BEN",
) -> Dict[str, Any]:
    """Prepare → autoSegment → place ligand → solvate → CHARMM build.

    Two modes for the ligand:

    1. ``parametrize=True`` (default): supply ``ligand_input`` as a mol2
       file; we hand it to Swiss-Param to get CHARMM CGenFF .rtf/.prm.
    2. ``parametrize=False``: supply ``ligand_rtf`` + ``ligand_prm`` +
       ``ligand_pdb`` from a previous run or another tool (CGenFF web,
       FFTK, etc.). The PDB resname must match ``ligand_resname``.

    By default the ligand is rotated randomly and translated to
    ``maxDistance(protein) + 10 Å`` along +X — the standard "unbinding"
    setup for binding free-energy or kinetics simulations. Set
    ``place_at=[x,y,z]`` to position it explicitly (e.g. in the binding site).
    """
    if forcefield != "charmm":
        raise NotImplementedError("only CHARMM is wired in this build")

    from moleculekit.molecule import Molecule
    from moleculekit.tools.preparation import systemPrepare
    from moleculekit.tools.autosegment import autoSegment
    from htmd.builder.solvate import solvate
    from htmd.builder import charmm

    outdir = os.path.abspath(outdir)
    os.makedirs(outdir, exist_ok=True)

    # 1. Resolve ligand topology/parameters
    if parametrize:
        # Resolve ligand_input from rcsb_id / smiles if provided
        ligand_source = "ligand_input"
        if ligand_input is None:
            from htmd_mcp.ligand_io import (
                fetch_ligand_from_rcsb,
                prepare_ligand_mol2,
            )
            if ligand_rcsb_id:
                fetched = fetch_ligand_from_rcsb(
                    ligand_rcsb_id, outdir=os.path.join(outdir, "raw_ligand"),
                )
                ligand_input = fetched["mol2"]
                ligand_source = f"rcsb:{ligand_rcsb_id}"
            elif ligand_smiles:
                prepared = prepare_ligand_mol2(
                    ligand_smiles,
                    output=os.path.join(outdir, "raw_ligand", "ligand.mol2"),
                    input_format="smi",
                    name=ligand_resname,
                )
                ligand_input = prepared["mol2"]
                ligand_source = f"smiles:{ligand_smiles}"
            else:
                raise ValueError(
                    "parametrize=True needs one of: ligand_input (mol2 path), "
                    "ligand_rcsb_id (3-letter PDB code), or ligand_smiles."
                )
        param_dir = os.path.join(outdir, "lig_params")
        params = parametrize_ligand(
            ligand_input,
            ligand_resname=ligand_resname,
            method=parametrize_method,
            outdir=param_dir,
        )
        params["source"] = ligand_source
        ligand_rtf = params["rtf"]
        ligand_prm = params["prm"]
        ligand_pdb = params["pdb"]
    else:
        if not (ligand_rtf and ligand_prm and ligand_pdb):
            raise ValueError(
                "parametrize=False requires ligand_rtf + ligand_prm + ligand_pdb"
            )

    # 2. Prepare protein (clean → prepare → segment)
    prot = Molecule(protein_pdb)
    if keep_selection_protein:
        prot.filter(keep_selection_protein)
    if remove_selection_protein:
        prot.remove(remove_selection_protein)
    if not (keep_selection_protein or remove_selection_protein):
        prot.filter("protein or water or ions")

    prot = systemPrepare(prot, pH=float(pH))
    prot = autoSegment(prot, sel="protein")
    prot.set("segid", "W", sel="water")
    prot.set("segid", "I", sel="ions")
    # Record the protein COM before centering so we can apply the same
    # translation to the ligand and keep the input binding pose intact.
    prot_com_pre = np.mean(prot.coords[:, :, prot.frame], axis=0)
    prot.center()

    # 3. Load ligand
    lig = Molecule(ligand_pdb)
    lig.set("segid", "L")
    lig.set("resname", ligand_resname.upper()[:4])

    # 4. Place ligand
    placement = _place_ligand(prot, lig, place_at=place_at,
                              random_far=random_far, seed=seed,
                              prot_pre_center_com=prot_com_pre)

    # 5. Combine, solvate
    mol = prot.copy()
    mol.append(lig)
    solv = solvate(mol, pad=float(pad))

    # 6. CHARMM build with ligand RTF appended to the topology list
    topo = list(charmm.defaultTopo()) + [os.path.abspath(ligand_rtf)]
    built = charmm.build(
        solv,
        topo=topo,
        outdir=outdir,
        saltconc=float(saltconc),
        saltcation=cation,
        saltanion=anion,
    )

    # 7. Persist the ligand .prm path so NAMD3 staging copies it
    extra_params = [os.path.abspath(ligand_prm)]
    with open(os.path.join(outdir, "extra_params.json"), "w") as fh:
        json.dump(extra_params, fh)

    n_lig = int(np.sum(built.atomselect(f"resname {ligand_resname.upper()[:4]}")))
    return {
        "status": "ok",
        "outdir": outdir,
        "forcefield": forcefield,
        "ligand_resname": ligand_resname.upper()[:4],
        "ligand_files": {
            "rtf": ligand_rtf,
            "prm": ligand_prm,
            "pdb": ligand_pdb,
        },
        "placement": placement,
        "n_atoms": int(built.numAtoms),
        "n_protein_atoms": int(np.sum(built.atomselect("protein"))),
        "n_ligand_atoms": n_lig,
        "n_water_atoms": int(np.sum(built.atomselect("water"))),
        "n_ions": int(np.sum(built.atomselect("ions"))),
        "salt_concentration": float(saltconc),
        "files": {
            "pdb": os.path.join(outdir, "structure.pdb"),
            "psf": os.path.join(outdir, "structure.psf"),
        },
    }
