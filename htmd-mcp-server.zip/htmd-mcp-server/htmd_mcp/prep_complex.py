"""Build a protein-protein complex in a water box for MD.

Two input modes:

* **Single-PDB mode** — pass ``receptor_pdb`` only and split it into two
  partners with ``receptor_selection`` / ``partner_selection`` (default
  ``chain A`` / ``chain B``). Use this when you have a co-crystal or docked
  complex stored as one file.
* **Two-PDB mode** — pass both ``receptor_pdb`` and ``partner_pdb``. Each
  is loaded and prepared independently. Use this when partners come from
  different sources (e.g., alphafold monomers, separate docking poses).

Each partner is run through ``systemPrepare`` separately (so propKa scores
each protein in isolation) and through ``autoSegment`` with a distinct
``basename`` so the merged system has unique segids. Optionally, the
partner can be translated along +X (``separation`` Å) for an "unbound"
starting pose used in association/dissociation studies.
"""

from __future__ import annotations

import logging
import os
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)


def _load_and_clean(
    source: str,
    *,
    selection: Optional[str],
    keep_selection: Optional[str],
    remove_selection: Optional[str],
):
    """Load a PDB (path or 4-letter ID), narrow to ``selection`` if given,
    then apply optional keep/remove filters."""
    from moleculekit.molecule import Molecule

    mol = Molecule(source)
    if selection:
        mol.filter(selection)
    if keep_selection:
        mol.filter(keep_selection)
    if remove_selection:
        mol.remove(remove_selection)
    if not (selection or keep_selection or remove_selection):
        # Default cleanup: protein + crystal waters/ions only. Anything else
        # (small-molecule ligands, cofactors) needs separate parametrization.
        mol.filter("protein or water or ions")
    return mol


def _prepare_partner(mol, *, pH: float, segid_basename: str):
    """systemPrepare → autoSegment with a distinct basename."""
    from moleculekit.tools.preparation import systemPrepare
    from moleculekit.tools.autosegment import autoSegment

    prepared = systemPrepare(mol, pH=float(pH))
    prepared = autoSegment(prepared, sel="protein", basename=segid_basename)
    # Tag any crystallographic waters/ions with partner-specific segids so
    # they don't collide between partners after merge.
    prepared.set("segid", f"W{segid_basename}", sel="water")
    prepared.set("segid", f"I{segid_basename}", sel="ions")
    return prepared


def _translate_partner(receptor, partner, separation: float) -> Dict[str, Any]:
    """Move the partner's centroid by ``separation`` Å along +X relative to
    the combined-system center. Returns metadata (initial / final centers)."""
    from moleculekit.util import maxDistance

    rec_center = np.mean(receptor.get("coords", "all"), axis=0)
    part_center_before = np.mean(partner.get("coords", "all"), axis=0)

    # Translate: place partner so its centroid is at receptor_center + (max
    # extent + separation) along +X. This guarantees no overlap regardless
    # of how big either partner is.
    rec_extent = float(maxDistance(receptor, "all"))
    part_extent = float(maxDistance(partner, "all"))
    target_x = rec_center[0] + rec_extent + part_extent + float(separation)
    delta = np.array([target_x - part_center_before[0], 0.0, 0.0])
    partner.moveBy(delta)

    return {
        "separation_A": float(separation),
        "receptor_max_extent_A": rec_extent,
        "partner_max_extent_A": part_extent,
        "translation_A": list(map(float, delta)),
        "receptor_center": list(map(float, rec_center)),
        "partner_center_after": list(map(float,
            np.mean(partner.get("coords", "all"), axis=0))),
    }


def build_protein_protein_complex(
    receptor_pdb: str,
    *,
    partner_pdb: Optional[str] = None,
    receptor_selection: Optional[str] = None,
    partner_selection: Optional[str] = None,
    keep_selection_receptor: Optional[str] = None,
    remove_selection_receptor: Optional[str] = None,
    keep_selection_partner: Optional[str] = None,
    remove_selection_partner: Optional[str] = None,
    receptor_segid_basename: str = "R",
    partner_segid_basename: str = "L",
    separation: Optional[float] = None,
    forcefield: str = "charmm",
    water_model: str = "tip3p",
    pad: float = 12.0,
    saltconc: float = 0.15,
    cation: str = "SOD",
    anion: str = "CLA",
    pH: float = 7.4,
    disulfide: Optional[List[List[str]]] = None,
    outdir: str = "build_complex",
) -> Dict[str, Any]:
    """Build a protein-protein complex in a water box.

    Parameters
    ----------
    receptor_pdb
        4-letter PDB ID or local path. In single-PDB mode this file holds
        both partners; in two-PDB mode it's just the receptor.
    partner_pdb
        Second protein (path or PDB ID). If ``None``, the partner is taken
        from ``receptor_pdb`` via ``partner_selection``.
    receptor_selection / partner_selection
        VMD-style selections to extract each partner. Required only in
        single-PDB mode; defaults to ``chain A`` / ``chain B`` when
        ``partner_pdb`` is omitted and selections aren't given.
    keep_selection_* / remove_selection_*
        Optional per-partner cleanup applied after the chain split.
    receptor_segid_basename / partner_segid_basename
        autoSegment basenames so the merged segids are distinct (e.g.
        ``R0, R1, ...`` vs ``L0, L1, ...``). psfgen uses segids to define
        the topology graph, so they must not collide between partners.
    separation
        If a float, translate the partner along +X by
        ``maxDistance(receptor) + maxDistance(partner) + separation`` Å so
        the two start unbound. ``None`` keeps the partner where it is
        (use this when input is a co-crystal or docked pose).
    forcefield
        ``"charmm"`` (default) or ``"amber"``.
    pad, saltconc, cation, anion, pH, disulfide
        Standard solvate / ionize / build options. Inter-chain disulfides
        are auto-detected by ``charmm.build`` when partners are within
        2.5 Å of each other (e.g., antibody H-L bonds).
    """
    if forcefield not in ("charmm", "amber"):
        raise ValueError(f"unknown forcefield {forcefield!r}")

    from htmd.builder.solvate import solvate

    outdir = os.path.abspath(outdir)
    os.makedirs(outdir, exist_ok=True)

    # --- 1. Resolve inputs ---------------------------------------------------
    two_pdb_mode = partner_pdb is not None
    if two_pdb_mode:
        rec_sel = receptor_selection
        part_sel = partner_selection
    else:
        # Single-PDB mode: must have two distinct selections. Default to A/B.
        rec_sel = receptor_selection or "chain A"
        part_sel = partner_selection or "chain B"
        if rec_sel == part_sel:
            raise ValueError(
                "single-PDB mode needs distinct receptor_selection and "
                f"partner_selection (got {rec_sel!r} for both)"
            )

    receptor = _load_and_clean(
        receptor_pdb,
        selection=rec_sel,
        keep_selection=keep_selection_receptor,
        remove_selection=remove_selection_receptor,
    )
    partner = _load_and_clean(
        partner_pdb if two_pdb_mode else receptor_pdb,
        selection=part_sel,
        keep_selection=keep_selection_partner,
        remove_selection=remove_selection_partner,
    )

    if int(np.sum(receptor.atomselect("protein"))) == 0:
        raise ValueError(
            f"receptor has 0 protein atoms after selection={rec_sel!r}"
        )
    if int(np.sum(partner.atomselect("protein"))) == 0:
        raise ValueError(
            f"partner has 0 protein atoms after selection={part_sel!r}"
        )

    # --- 2. Prepare each partner independently -------------------------------
    if receptor_segid_basename == partner_segid_basename:
        raise ValueError(
            "receptor_segid_basename and partner_segid_basename must differ "
            "(got both = {!r})".format(receptor_segid_basename)
        )

    receptor = _prepare_partner(
        receptor, pH=pH, segid_basename=receptor_segid_basename,
    )
    partner = _prepare_partner(
        partner, pH=pH, segid_basename=partner_segid_basename,
    )

    receptor_segids = sorted(set(receptor.segid[
        receptor.atomselect("protein")].tolist()))
    partner_segids = sorted(set(partner.segid[
        partner.atomselect("protein")].tolist()))

    # --- 3. Optional partner translation (unbound starting pose) ------------
    placement: Dict[str, Any] = {"placement": "as-input"}
    if separation is not None:
        placement = {
            "placement": "translated",
            **_translate_partner(receptor, partner, separation=separation),
        }

    # --- 4. Combine + recenter + solvate ------------------------------------
    mol = receptor.copy()
    # collisions=False: trust the upstream pose (no atom dropping). For
    # docking/co-crystal inputs this is what the user wants.
    mol.append(partner)
    mol.center()

    solv = solvate(mol, pad=float(pad))

    # --- 5. Build with the requested force field ----------------------------
    if forcefield == "charmm":
        from htmd.builder import charmm

        built = charmm.build(
            solv,
            outdir=outdir,
            saltconc=float(saltconc),
            saltcation=cation,
            saltanion=anion,
            disulfide=disulfide,
        )
        files = {
            "pdb": os.path.join(outdir, "structure.pdb"),
            "psf": os.path.join(outdir, "structure.psf"),
        }
    else:
        from htmd.builder import amber

        built = amber.build(
            solv,
            outdir=outdir,
            saltconc=float(saltconc),
            saltcation=cation if cation != "SOD" else "NA",
            saltanion=anion if anion != "CLA" else "CL",
            disulfide=disulfide,
        )
        files = {
            "pdb": os.path.join(outdir, "structure.pdb"),
            "prmtop": os.path.join(outdir, "structure.prmtop"),
        }

    # --- 6. Selections downstream tools should use -------------------------
    rec_segid_sel = "segid " + " ".join(receptor_segids) if receptor_segids else ""
    part_segid_sel = "segid " + " ".join(partner_segids) if partner_segids else ""

    return {
        "status": "ok",
        "outdir": outdir,
        "forcefield": forcefield,
        "two_pdb_mode": two_pdb_mode,
        "receptor_segids": receptor_segids,
        "partner_segids": partner_segids,
        "receptor_selection": rec_segid_sel,
        "partner_selection": part_segid_sel,
        "n_atoms": int(built.numAtoms),
        "n_protein_atoms": int(np.sum(built.atomselect("protein"))),
        "n_water_atoms": int(np.sum(built.atomselect("water"))),
        "n_ions": int(np.sum(built.atomselect("ions"))),
        "n_receptor_residues": int(np.sum(built.atomselect(
            f"name CA and ({rec_segid_sel})" if rec_segid_sel else "false"))),
        "n_partner_residues": int(np.sum(built.atomselect(
            f"name CA and ({part_segid_sel})" if part_segid_sel else "false"))),
        "salt_concentration": float(saltconc),
        "placement": placement,
        "files": files,
    }
