"""Comparative analysis across multiple protein-nucleic-acid trajectories.

Overlays an arbitrary number of systems (mutants / replicas / conditions) and
also emits paper-style individual per-system panels for:

  * RMSD vs time              (protein backbone, optimal superposition to ref)
  * RMSF vs residue           (protein backbone, per residue)
  * protein-nucleic H-bonds   (minimum-image, inter-molecular only)
  * radius of gyration vs time (optional)

Nothing is hard-coded to a particular protein:
  * protein atoms -> mdtraj "protein" selection
  * nucleic atoms -> detected by sugar atoms (C1'/O4'/...), so DNA *and* RNA work
    regardless of residue-name convention
  * ns/frame -> read from the NAMD config (timestep * dcdfreq) when available,
    overridable; falls back to a frame-index x-axis

Built on mdtraj. Writes PNGs/CSVs and a markdown summary into ``out_dir``.
"""
from __future__ import annotations

import glob
import logging
import os
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import numpy as np

logger = logging.getLogger("htmd_md_mcp.compare")

# sugar carbons / ring oxygen -> in every nucleotide, absent in protein.
NUCLEIC_SUGAR_ATOMS = {
    "C1'", "C2'", "C3'", "C4'", "O4'",
    "C1*", "C2*", "C3*", "C4*", "O4*",
}


# --------------------------------------------------------------------------
# input resolution
# --------------------------------------------------------------------------
def _normalize_runs(runs) -> List[tuple]:
    """Accept dict {label: path}, list of "label=path"/[label, path], or list
    of bare paths; return [(label, path), ...]."""
    out = []
    if isinstance(runs, dict):
        items = list(runs.items())
    else:
        items = []
        for r in runs:
            if isinstance(r, (list, tuple)) and len(r) == 2:
                items.append((r[0], r[1]))
            elif isinstance(r, str) and "=" in r:
                lbl, p = r.split("=", 1)
                items.append((lbl, p))
            else:  # bare path -> infer label
                items.append((None, r))
    for label, path in items:
        if label is None:
            base = os.path.basename(os.path.normpath(path))
            label = re.sub(r"^\d+_prod_", "", base) or base
        out.append((str(label), str(path)))
    return out


def _resolve_paths(path, dcd_name, psf_name):
    """(dcd, psf, config_dir) from a run dir, a .dcd file, or 'DCD:PSF'."""
    if ":" in path and path.lower().endswith((".psf", ".pdb")):
        dcd, psf = path.split(":", 1)
        return dcd, psf, os.path.dirname(os.path.abspath(dcd)) or "."
    if os.path.isdir(path):
        return (os.path.join(path, dcd_name),
                os.path.join(path, psf_name), path)
    cfg_dir = os.path.dirname(os.path.abspath(path)) or "."
    return path, os.path.join(cfg_dir, psf_name), cfg_dir


def _time_per_frame_ns(cfg_dir, config_name=None):
    """NAMD timestep(fs) * dcdfreq(steps) -> ns/frame; None if not found."""
    candidates = []
    if config_name:
        candidates.append(os.path.join(cfg_dir, config_name))
    candidates += sorted(glob.glob(os.path.join(cfg_dir, "*.namd")))
    candidates += sorted(glob.glob(os.path.join(cfg_dir, "*.conf")))
    for cfg in candidates:
        if not os.path.isfile(cfg):
            continue
        ts = freq = None
        with open(cfg) as fh:
            for line in fh:
                low = line.strip().lower()
                m = re.match(r"timestep\s+([\d.eE+-]+)", low)
                if m:
                    ts = float(m.group(1))
                m = re.match(r"dcdfreq\s+([\d.eE+-]+)", low)
                if m:
                    freq = float(m.group(1))
        if ts is not None and freq is not None:
            return ts * freq / 1.0e6  # (fs/step * steps/frame) -> ns/frame
    return None


def _as_list(v):
    if v is None:
        return []
    if isinstance(v, str):
        return [s.strip() for s in v.split(",") if s.strip()]
    return list(v)


# --------------------------------------------------------------------------
# selections
# --------------------------------------------------------------------------
def _nucleic_indices(top, protein_set, extra_resnames):
    extra = {r.upper() for r in extra_resnames}
    idx = []
    for r in top.residues:
        if any(a.index in protein_set for a in r.atoms):
            continue
        if any(a.name in NUCLEIC_SUGAR_ATOMS for a in r.atoms) \
                or r.name.upper() in extra:
            idx.extend(a.index for a in r.atoms)
    return np.array(sorted(idx), dtype=int)


def _protein_anchor_molecules(top, protein_set):
    anchors = []
    for mol in top.find_molecules():
        n_prot = sum(1 for a in mol if a.index in protein_set)
        if n_prot > 0.5 * len(mol):
            anchors.append(mol)
    return anchors


# --------------------------------------------------------------------------
# per-system analysis
# --------------------------------------------------------------------------
def _analyze_one(label, dcd, psf, opts, ref_path=None) -> Optional[Dict[str, Any]]:
    import mdtraj as md

    if not (os.path.exists(dcd) and os.path.exists(psf)):
        logger.warning("[%s] missing %s | %s; skipping", label, dcd, psf)
        return None

    full_top = md.load_psf(psf)
    prot_full = full_top.select(opts["protein_sel"])
    if len(prot_full) == 0:
        logger.warning("[%s] no protein atoms; skipping", label)
        return None
    prot_set = set(prot_full.tolist())
    na_full = _nucleic_indices(full_top, prot_set, opts["na_resnames"])
    keep = np.array(sorted(prot_set | set(na_full.tolist())), dtype=int)

    logger.info("[%s] loading %d protein + %d nucleic atoms (stride=%d)",
                label, len(prot_full), len(na_full), opts["stride"])
    traj = md.load(dcd, top=psf, atom_indices=keep, stride=opts["stride"])
    has_box = traj.unitcell_lengths is not None

    stop = traj.topology
    bb = stop.select(f"({opts['protein_sel']}) and ({opts['backbone_sel']})")
    bb = _drop_termini(stop, bb, opts["exclude_termini"])
    prot_sub = set(stop.select(opts["protein_sel"]).tolist())
    na_sub = set(_nucleic_indices(stop, prot_sub, opts["na_resnames"]).tolist())

    if has_box and opts["reimage"] and na_sub:
        try:
            anchors = _protein_anchor_molecules(stop, prot_sub)
            traj.image_molecules(anchor_molecules=anchors or None, make_whole=True)
        except Exception as e:  # periodic H-bonds still correct without this
            logger.warning("[%s] re-imaging skipped (%s)", label, e)

    # RMSD/RMSF reference: an external structure (e.g. crystal) loaded over the
    # same atom subset, or the trajectory's own ref_frame.
    ref_traj, ref_frame = traj, opts["ref_frame"]
    if ref_path:
        try:
            ref_traj = md.load(ref_path, atom_indices=keep)
        except Exception:
            ref_traj = md.load(ref_path, top=psf, atom_indices=keep)
        if ref_traj.n_atoms != traj.n_atoms:
            logger.warning("[%s] ref %s atom mismatch (%d vs %d); using frame %d",
                           label, ref_path, ref_traj.n_atoms, traj.n_atoms,
                           opts["ref_frame"])
            ref_traj, ref_frame = traj, opts["ref_frame"]
        else:
            ref_frame = 0
            logger.info("[%s] RMSD/RMSF reference: %s", label, ref_path)

    rmsd_A = md.rmsd(traj, ref_traj, frame=ref_frame, atom_indices=bb) * 10.0

    rg_nm = md.compute_rg(traj.atom_slice(np.array(sorted(prot_sub), dtype=int))) \
        if opts["compute_rg"] else None

    traj.superpose(ref_traj, frame=ref_frame, atom_indices=bb)
    rmsf_A = md.rmsf(traj, ref_traj, frame=ref_frame, atom_indices=bb) * 10.0
    resids = np.array([stop.atom(int(i)).residue.resSeq for i in bb])

    counts = np.zeros(traj.n_frames, dtype=int)
    if na_sub:
        logger.info("[%s] detecting H-bonds (%s)", label, opts["hbond_method"])
        if opts["hbond_method"] == "gromacs":
            counts = _gmx_hbond_counts(
                traj, prot_sub, na_sub,
                dist_cut_nm=opts["hbond_distance"] / 10.0,  # A -> nm
                angle_cut_deg=opts["hbond_angle"])
        elif opts["hbond_method"] == "baker_hubbard":
            for i in range(traj.n_frames):
                hb = md.baker_hubbard(traj[i], freq=0.0, periodic=has_box,
                                      distance_cutoff=0.35)
                counts[i] = _count_inter(hb, prot_sub, na_sub)
        else:
            for i, hb in enumerate(md.wernet_nilsson(traj, periodic=has_box)):
                counts[i] = _count_inter(hb, prot_sub, na_sub)

    return dict(label=label, rmsd=rmsd_A, rmsf=rmsf_A, resids=resids,
                hbonds=counts, n_frames=int(traj.n_frames),
                rg=(rg_nm if rg_nm is None else rg_nm * 10.0))  # nm -> A


def _count_inter(hb, prot_sub, na_sub):
    if hb is None or len(hb) == 0:
        return 0
    n = 0
    for row in hb:
        d, a = int(row[0]), int(row[2])
        if (d in prot_sub and a in na_sub) or (d in na_sub and a in prot_sub):
            n += 1
    return n


# Heavy atoms that act as H-bond donors/acceptors (GROMACS default: N, O; we
# also allow S, matching common practice).
_HB_HEAVY = {"N", "O", "S"}


def _gmx_hbond_counts(traj, prot_sub, na_sub, dist_cut_nm, angle_cut_deg,
                      chunk=500):
    """Per-frame inter-molecular H-bond count using the GROMACS ``gmx hbond``
    geometric criterion: donor-acceptor distance <= dist_cut AND hydrogen-
    donor-acceptor angle <= angle_cut. Minimum-image, deduplicated per
    donor-acceptor pair. dist_cut_nm in nm, angle_cut_deg in degrees."""
    import mdtraj as md

    top = traj.topology
    # map each hydrogen to its bonded heavy atom
    heavy_of_h = {}
    for a1, a2 in top.bonds:
        s1, s2 = a1.element.symbol, a2.element.symbol
        if s1 == "H" and s2 != "H":
            heavy_of_h[a1.index] = a2.index
        elif s2 == "H" and s1 != "H":
            heavy_of_h[a2.index] = a1.index
    donors = [(hv, h) for h, hv in heavy_of_h.items()
              if top.atom(hv).element.symbol in _HB_HEAVY]
    acc_prot = [a.index for a in top.atoms
                if a.element.symbol in _HB_HEAVY and a.index in prot_sub]
    acc_na = [a.index for a in top.atoms
              if a.element.symbol in _HB_HEAVY and a.index in na_sub]

    H_l, D_l, A_l = [], [], []
    for hv, h in donors:
        if hv in prot_sub:
            partners = acc_na
        elif hv in na_sub:
            partners = acc_prot
        else:
            continue
        for A in partners:
            H_l.append(h); D_l.append(hv); A_l.append(A)

    n_frames = traj.n_frames
    if not D_l:
        return np.zeros(n_frames, dtype=int)

    ang_trip = np.column_stack([H_l, D_l, A_l]).astype(np.int32)
    da_pair = np.column_stack([D_l, A_l]).astype(np.int32)
    _, pair_grp = np.unique(da_pair, axis=0, return_inverse=True)
    ang_cut_rad = np.deg2rad(angle_cut_deg)
    periodic = traj.unitcell_lengths is not None
    counts = np.zeros(n_frames, dtype=int)

    for s in range(0, n_frames, chunk):
        sub = traj[s:s + chunk]
        d = md.compute_distances(sub, da_pair, periodic=periodic)
        ang = md.compute_angles(sub, ang_trip, periodic=periodic)
        sat = (d <= dist_cut_nm) & (ang <= ang_cut_rad)  # nan -> False
        for fi in range(sat.shape[0]):
            g = pair_grp[sat[fi]]
            counts[s + fi] = np.unique(g).size if g.size else 0
    return counts


def _drop_termini(stop, bb, n):
    """Remove the first and last ``n`` protein residues (per chain) from the
    backbone atom-index array ``bb``."""
    if n <= 0:
        return bb
    info = [(stop.atom(int(i)).residue.chain.index,
             stop.atom(int(i)).residue.resSeq) for i in bb]
    by_chain: Dict[int, set] = {}
    for c, rs in info:
        by_chain.setdefault(c, set()).add(rs)
    drop = set()
    for c, rsset in by_chain.items():
        srt = sorted(rsset)
        for rs in srt[:n] + srt[-n:]:
            drop.add((c, rs))
    mask = np.array([(c, rs) not in drop for c, rs in info])
    return bb[mask]


# --------------------------------------------------------------------------
# plotting
# --------------------------------------------------------------------------
def _xaxis(r, tpf):
    return np.arange(r["n_frames"]) * (tpf if tpf else 1.0)


def _running_mean(y):
    import pandas as pd
    w = max(1, len(y) // 100)
    return pd.Series(y).rolling(w, center=True, min_periods=1).mean().to_numpy()


def _make_plots(results, opts, tpf, out: Path) -> List[str]:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    palette = plt.rcParams["axes.prop_cycle"].by_key()["color"]
    colors = {r["label"]: palette[i % len(palette)] for i, r in enumerate(results)}
    use_ns = tpf is not None
    xlabel = "Time (ns)" if use_ns else "Frame index"
    prefix = (opts["system_name"] + " ").lstrip()
    na = opts["na_name"]
    written: List[str] = []

    def save(fig, name):
        p = out / name
        fig.tight_layout()
        fig.savefig(p, dpi=150)
        plt.close(fig)
        written.append(str(p))

    # ---- overlaid comparison ----
    fig = plt.figure(figsize=(9, 5))
    for r in results:
        plt.plot(_xaxis(r, tpf), r["rmsd"], color=colors[r["label"]], lw=0.9,
                 label=r["label"])
    plt.xlabel(xlabel); plt.ylabel(r"Backbone RMSD ($\AA$)")
    plt.title(f"{prefix}backbone RMSD vs time"); plt.legend(); plt.grid(alpha=0.3)
    save(fig, "rmsd_vs_time.png")

    fig = plt.figure(figsize=(9, 5))
    for r in results:
        plt.plot(r["resids"], r["rmsf"], color=colors[r["label"]], lw=1.1,
                 label=r["label"])
    for hr in opts["highlight"]:
        plt.axvline(hr, color="k", ls="--", lw=0.8, alpha=0.6)
    plt.xlabel("Residue number"); plt.ylabel(r"RMSF ($\AA$)")
    plt.title(f"{prefix}per-residue RMSF"); plt.legend(); plt.grid(alpha=0.3)
    save(fig, "rmsf_vs_residue.png")

    fig = plt.figure(figsize=(9, 5))
    for r in results:
        x = _xaxis(r, tpf); c = colors[r["label"]]
        plt.plot(x, r["hbonds"], color=c, lw=0.5, alpha=0.35)
        plt.plot(x, _running_mean(r["hbonds"]), color=c, lw=1.6,
                 label=f"{r['label']} (mean {r['hbonds'].mean():.1f})")
    plt.xlabel(xlabel); plt.ylabel(f"Protein-{na} H-bonds")
    plt.title(f"{prefix}protein-{na} hydrogen bonds vs time")
    plt.legend(); plt.grid(alpha=0.3)
    save(fig, f"protein_{na.lower()}_hbonds_vs_time.png")

    if opts["compute_rg"] and all(r["rg"] is not None for r in results):
        fig = plt.figure(figsize=(9, 5))
        for r in results:
            plt.plot(_xaxis(r, tpf), r["rg"], color=colors[r["label"]], lw=0.9,
                     label=f"{r['label']} (mean {r['rg'].mean():.2f} A)")
        plt.xlabel(xlabel); plt.ylabel(r"Radius of gyration ($\AA$)")
        plt.title(f"{prefix}protein radius of gyration vs time")
        plt.legend(); plt.grid(alpha=0.3)
        save(fig, "radius_of_gyration_vs_time.png")

    # ---- individual per-system panels (paper-style) ----
    if opts["individual"]:
        for r in results:
            c = colors[r["label"]]; x = _xaxis(r, tpf)
            fig, ax = plt.subplots(2, 2, figsize=(12, 8))
            ax[0, 0].plot(x, r["rmsd"], color=c, lw=0.9)
            ax[0, 0].set(xlabel=xlabel, ylabel=r"RMSD ($\AA$)", title="Backbone RMSD")
            ax[0, 0].grid(alpha=0.3)
            ax[0, 1].plot(r["resids"], r["rmsf"], color=c, lw=1.1)
            for hr in opts["highlight"]:
                ax[0, 1].axvline(hr, color="k", ls="--", lw=0.8, alpha=0.6)
            ax[0, 1].set(xlabel="Residue number", ylabel=r"RMSF ($\AA$)", title="Per-residue RMSF")
            ax[0, 1].grid(alpha=0.3)
            ax[1, 0].plot(x, r["hbonds"], color=c, lw=0.5, alpha=0.4)
            ax[1, 0].plot(x, _running_mean(r["hbonds"]), color=c, lw=1.6)
            ax[1, 0].set(xlabel=xlabel, ylabel=f"Protein-{na} H-bonds",
                         title=f"Protein-{na} H-bonds (mean {r['hbonds'].mean():.1f})")
            ax[1, 0].grid(alpha=0.3)
            if r["rg"] is not None:
                ax[1, 1].plot(x, r["rg"], color=c, lw=0.9)
                ax[1, 1].set(xlabel=xlabel, ylabel=r"Rg ($\AA$)", title="Radius of gyration")
            else:
                ax[1, 1].axis("off")
            ax[1, 1].grid(alpha=0.3)
            fig.suptitle(f"{prefix}{r['label']}", fontsize=14)
            save(fig, f"individual_{r['label']}.png")
    return written


# --------------------------------------------------------------------------
def _write_summary_md(results, opts, tpf, out: Path, summary_rows) -> str:
    na = opts["na_name"]
    lines = [f"# {opts['system_name'] or 'Protein-nucleic'} comparative MD analysis",
             "",
             f"Systems: {', '.join(r['label'] for r in results)}",
             f"Time per frame: {tpf} ns" if tpf else "Time axis: frame index",
             "", "## Mean values", "",
             f"| system | frames | sim (ns) | mean RMSD (Å) | mean RMSF (Å) | "
             f"mean P-{na} H-bonds | mean Rg (Å) |",
             "|---|---|---|---|---|---|---|"]
    for row in summary_rows:
        lines.append(
            f"| {row['system']} | {row['n_frames']} | {row['sim_ns']} | "
            f"{row['mean_rmsd_A']} | {row['mean_rmsf_A']} | {row['mean_hbonds']} | "
            f"{row['mean_rg_A']} |")
    if opts["hbond_method"] == "gromacs":
        hb_line = (f"- H-bonds: GROMACS-style criterion (D-A <= "
                   f"{opts['hbond_distance']} Å, H-D-A angle <= {opts['hbond_angle']}°), "
                   f"minimum-image, strictly inter-molecular protein↔nucleic pairs")
    else:
        hb_line = (f"- H-bonds: mdtraj `{opts['hbond_method']}`, minimum-image, "
                   f"strictly inter-molecular protein↔nucleic pairs")
    lines += ["", "## Method",
              f"- protein selection: `{opts['protein_sel']}`; "
              f"backbone for RMSD/RMSF: `{opts['backbone_sel']}`"
              + (f", excluding first/last {opts['exclude_termini']} residues per chain"
                 if opts["exclude_termini"] else ""),
              "- nucleic atoms detected by sugar-atom names (DNA/RNA agnostic)",
              hb_line,
              "- complex re-imaged with the protein as anchor before H-bond detection"
              if opts["reimage"] else "- re-imaging disabled",
              f"- RMSD/RMSF superposed on the backbone to frame {opts['ref_frame']}",
              ""]
    p = out / "analysis_summary.md"
    p.write_text("\n".join(lines))
    return str(p)


# --------------------------------------------------------------------------
def compare_protein_nucleic(
    runs: Union[Dict[str, str], List],
    out_dir: str,
    dcd_name: str = "prod.dcd",
    psf_name: str = "structure.psf",
    config_name: Optional[str] = None,
    time_per_frame_ns: Optional[float] = None,
    protein_sel: str = "protein",
    backbone_sel: str = "name CA",
    na_resnames: Optional[Union[str, List[str]]] = None,
    na_name: str = "DNA",
    highlight: Optional[Union[str, List[int]]] = None,
    ref_frame: int = 0,
    stride: int = 1,
    reimage: bool = True,
    individual: bool = True,
    compute_rg: bool = True,
    hbond_method: str = "wernet_nilsson",
    hbond_distance: float = 3.5,
    hbond_angle: float = 30.0,
    exclude_termini: int = 0,
    rmsd_ref: Optional[str] = None,
    system_name: str = "",
) -> Dict[str, Any]:
    """Compare RMSD / RMSF / protein-nucleic H-bonds (+ optional Rg) across any
    number of protein-DNA/RNA trajectories. Writes overlaid + individual plots,
    per-system CSVs, a summary CSV and a markdown report into ``out_dir``.

    hbond_method: 'wernet_nilsson' | 'baker_hubbard' | 'gromacs'. For 'gromacs',
    a bond is donor-acceptor distance <= ``hbond_distance`` (Å) and H-donor-
    acceptor angle <= ``hbond_angle`` (deg) — the gmx hbond criterion (defaults
    3.5 Å / 30°). ``exclude_termini`` drops the first/last N protein residues
    (per chain) from RMSD/RMSF. ``rmsd_ref`` references RMSD/RMSF to an external
    structure (e.g. the crystal): an absolute path, or a filename resolved
    inside each run dir (e.g. 'structure.pdb'); must share the run's atom order.
    """
    import pandas as pd

    opts = dict(
        protein_sel=protein_sel, backbone_sel=backbone_sel,
        na_resnames=_as_list(na_resnames), na_name=na_name,
        highlight=[int(h) for h in _as_list(highlight)],
        ref_frame=ref_frame, stride=stride, reimage=reimage,
        individual=individual, compute_rg=compute_rg,
        hbond_method=hbond_method, hbond_distance=hbond_distance,
        hbond_angle=hbond_angle, exclude_termini=int(exclude_termini),
        system_name=system_name,
    )

    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    norm = _normalize_runs(runs)

    # time per frame
    if time_per_frame_ns is not None:
        tpf = time_per_frame_ns
    else:
        tpfs = [_time_per_frame_ns(_resolve_paths(p, dcd_name, psf_name)[2],
                                   config_name) for _, p in norm]
        tpf = tpfs[0] if (tpfs and tpfs[0] and all(t == tpfs[0] for t in tpfs)) else None

    results, summary_rows = [], []
    for label, path in norm:
        dcd, psf, cfg = _resolve_paths(path, dcd_name, psf_name)
        ref_path = None
        if rmsd_ref:
            if os.path.exists(rmsd_ref):
                ref_path = rmsd_ref
            else:  # treat as a filename inside the run dir
                rd = path if os.path.isdir(path) else cfg
                cand = os.path.join(rd, rmsd_ref)
                ref_path = cand if os.path.exists(cand) else None
                if ref_path is None:
                    logger.warning("[%s] rmsd_ref %r not found; using frame %d",
                                   label, rmsd_ref, ref_frame)
        r = _analyze_one(label, dcd, psf, opts, ref_path)
        if r is None:
            continue
        results.append(r)
        x = _xaxis(r, tpf)
        pd.DataFrame({("time_ns" if tpf else "frame"): x, "rmsd_A": r["rmsd"],
                      f"protein_{na_name.lower()}_hbonds": r["hbonds"],
                      **({"rg_A": r["rg"]} if r["rg"] is not None else {})}
                     ).to_csv(out / f"{label}_timeseries.csv", index=False)
        pd.DataFrame({"resid": r["resids"], "rmsf_A": r["rmsf"]}).to_csv(
            out / f"{label}_rmsf.csv", index=False)
        summary_rows.append(dict(
            system=label, n_frames=r["n_frames"],
            sim_ns=(round(r["n_frames"] * tpf, 2) if tpf else None),
            mean_rmsd_A=round(float(r["rmsd"].mean()), 2),
            mean_rmsf_A=round(float(r["rmsf"].mean()), 2),
            mean_hbonds=round(float(r["hbonds"].mean()), 2),
            mean_rg_A=(round(float(r["rg"].mean()), 2) if r["rg"] is not None else None)))

    if not results:
        return {"status": "error", "error": "no systems analyzed",
                "out_dir": str(out.resolve())}

    plots = _make_plots(results, opts, tpf, out)
    summ = pd.DataFrame(summary_rows)
    summ.to_csv(out / "summary.csv", index=False)
    report = _write_summary_md(results, opts, tpf, out, summary_rows)

    return {
        "status": "ok",
        "out_dir": str(out.resolve()),
        "n_systems": len(results),
        "time_per_frame_ns": tpf,
        "summary": summary_rows,
        "plots": plots,
        "summary_csv": str((out / "summary.csv").resolve()),
        "report_md": report,
    }
