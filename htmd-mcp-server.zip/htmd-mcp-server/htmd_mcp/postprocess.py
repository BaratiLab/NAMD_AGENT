"""Post-processing for NAMD3 trajectories.

All tools take a ``run_dir`` (the directory holding ``structure.psf``,
``structure.pdb``, and a DCD file produced by NAMD3) plus a selection
string. They write CSVs of per-frame timeseries and optional PNGs into
``run_dir/analysis/``, and return both the time-series array and summary
statistics so the LLM has something compact to reason about.

Implemented entirely on ``moleculekit`` to avoid adding MDAnalysis/MDTraj
as dependencies.
"""

from __future__ import annotations

import csv
import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)


# --- Loading ---------------------------------------------------------------

def _load_traj(
    run_dir: str,
    *,
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
):
    """Return a Molecule with the trajectory read in. Auto-discovers the
    first DCD if not specified.

    The topology must match the DCD atom count. A wrapped/stripped trajectory
    (e.g. ``analysis/aligned.dcd`` from ``wrap_and_align``) has fewer atoms
    than the full ``structure.psf`` it was built from, so a single hard-coded
    topology will not do. We collect candidate topologies — caller-supplied
    ``psf``/``pdb`` first, then a PDB written next to the DCD, then the
    run-dir structure files — and use the first whose atom count matches the
    trajectory.
    """
    from moleculekit.molecule import Molecule

    rd = Path(run_dir)
    if dcd is None:
        candidates = sorted(rd.glob("*.dcd"))
        if not candidates:
            candidates = sorted((rd / "analysis").glob("*.dcd"))
        if not candidates:
            raise FileNotFoundError(f"no DCD files in {run_dir}")
        dcd_path = candidates[-1]  # prod > equil > min lexicographically
    else:
        dcd_path = Path(dcd)
    if not dcd_path.is_file():
        raise FileNotFoundError(f"DCD not found: {dcd_path}")

    # Topology candidates, most-specific first.
    cand: List[Path] = []
    if psf:
        cand.append(Path(psf))
    if pdb:
        cand.append(Path(pdb))
    cand.append(dcd_path.with_suffix(".pdb"))   # e.g. aligned.dcd -> aligned.pdb
    cand.append(dcd_path.with_suffix(".psf"))
    for name in ("structure_hmr.psf", "structure.psf", "structure.pdb"):
        cand.append(rd / name)

    last_err: Optional[Exception] = None
    tried: List[str] = []
    for top in cand:
        if not top.is_file() or str(top) in tried:
            continue
        tried.append(str(top))
        try:
            mol = Molecule(str(top))
            mol.read(str(dcd_path))   # raises ValueError on atom-count mismatch
            _ensure_masses(mol)
            return mol, str(top), str(top), str(dcd_path)
        except Exception as e:  # noqa: BLE001 - try the next topology
            last_err = e
            continue
    raise ValueError(
        f"no topology matched the trajectory {dcd_path.name}; tried "
        f"{tried}; last error: {last_err}"
    )


# Atomic masses (amu) for the elements found in biomolecular MD systems.
_ELEMENT_MASS: Dict[str, float] = {
    "H": 1.008, "C": 12.011, "N": 14.007, "O": 15.999, "P": 30.974,
    "S": 32.06, "NA": 22.990, "CL": 35.45, "MG": 24.305, "K": 39.098,
    "CA": 40.078, "ZN": 65.38, "FE": 55.845, "F": 18.998, "BR": 79.904,
}


def _ensure_masses(mol) -> None:
    """Guarantee usable atomic masses on ``mol``.

    A topology read from a PDB carries no masses, which silently breaks
    mass-weighted analyses (radius of gyration etc.) — they return NaN.
    When the masses are missing, zero or NaN, repopulate them from each
    atom's element (falling back to the leading letters of the atom name).
    """
    masses = np.asarray(getattr(mol, "masses", []), dtype=float)
    if masses.size == mol.numAtoms and np.all(np.isfinite(masses)) \
            and np.any(masses > 0):
        return
    elements = [str(e).strip().upper() for e in mol.element]
    names = [str(n).strip().upper() for n in mol.name]
    filled = np.zeros(mol.numAtoms, dtype=np.float32)
    for i in range(mol.numAtoms):
        el = elements[i] if i < len(elements) else ""
        if el not in _ELEMENT_MASS:
            # Fall back to the atom name: take the longest leading element-
            # like token (handles names such as "CL1", "HG21", "OD2").
            nm = names[i] if i < len(names) else ""
            nm = "".join(c for c in nm if c.isalpha())
            el = nm[:2] if nm[:2] in _ELEMENT_MASS else nm[:1]
        filled[i] = _ELEMENT_MASS.get(el, 12.011)
    mol.masses = filled


def _ensure_outdir(run_dir: str) -> Path:
    out = Path(run_dir) / "analysis"
    out.mkdir(parents=True, exist_ok=True)
    return out


def _write_csv(path: Path, header: List[str], rows: List[List[Any]]) -> None:
    with open(path, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(header)
        w.writerows(rows)


def _summary(values: np.ndarray) -> Dict[str, float]:
    if values.size == 0:
        return {"n": 0}
    return {
        "n": int(values.size),
        "mean": float(np.mean(values)),
        "std": float(np.std(values)),
        "min": float(np.min(values)),
        "max": float(np.max(values)),
        "first": float(values[0]),
        "last": float(values[-1]),
    }


# --- Plot helpers ----------------------------------------------------------
#
# Each analysis tool writes a CSV with the raw numbers and a companion PNG so
# the LLM (or a human) can eyeball trends without having to parse the CSV.
# Plots use the Agg backend so they work in headless contexts.

def _plot_line(
    x,
    y,
    *,
    xlabel: str,
    ylabel: str,
    title: str,
    png_path: Path,
    overlay_mean: bool = True,
) -> str:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(8, 4))
    ax.plot(x, y, lw=1.2, color="#1f77b4")
    if overlay_mean and len(y) > 1:
        m = float(np.nanmean(y))
        ax.axhline(m, color="#d62728", ls="--", lw=0.8,
                   label=f"mean={m:.3g}")
        ax.legend(loc="best", fontsize=8)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(str(png_path), dpi=120)
    plt.close(fig)
    return str(png_path)


def _plot_bar(
    labels: List[str],
    values: List[float],
    *,
    xlabel: str,
    ylabel: str,
    title: str,
    png_path: Path,
    max_bars: int = 30,
) -> str:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    if len(labels) > max_bars:
        labels = labels[:max_bars]
        values = values[:max_bars]
    n = len(labels)
    fig, ax = plt.subplots(figsize=(max(6.0, 0.35 * n + 2.0), 4.5))
    ax.bar(range(n), values, color="#1f77b4")
    ax.set_xticks(range(n))
    ax.set_xticklabels(labels, rotation=60, ha="right", fontsize=8)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()
    fig.savefig(str(png_path), dpi=120)
    plt.close(fig)
    return str(png_path)


def _plot_heatmap(
    matrix: np.ndarray,
    *,
    xlabel: str,
    ylabel: str,
    title: str,
    png_path: Path,
    cmap: str = "viridis",
    cbar_label: str = "",
    extent=None,
) -> str:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(8, 5))
    im = ax.imshow(matrix, aspect="auto", cmap=cmap, origin="lower",
                   extent=extent)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    fig.colorbar(im, ax=ax, label=cbar_label)
    fig.tight_layout()
    fig.savefig(str(png_path), dpi=120)
    plt.close(fig)
    return str(png_path)


# --- Wrap & align ----------------------------------------------------------

def wrap_and_align(
    run_dir: str,
    *,
    align_sel: str = "protein and name CA",
    wrap_sel: Optional[str] = "protein",
    output_basename: str = "aligned",
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> Dict[str, Any]:
    """Wrap waters/ions back into the box around ``wrap_sel`` then align the
    trajectory on ``align_sel``. Writes ``<basename>.dcd`` and a stripped
    ``<basename>.pdb`` (waters and ions removed) for downstream analysis."""
    mol, psf_path, pdb_path, dcd_path = _load_traj(
        run_dir, psf=psf, pdb=pdb, dcd=dcd,
    )
    n_frames = mol.numFrames
    if wrap_sel:
        mol.wrap(wrap_sel)
    mol.align(align_sel)

    out = _ensure_outdir(run_dir)
    aligned_dcd = out / f"{output_basename}.dcd"
    aligned_pdb = out / f"{output_basename}.pdb"

    # Write a stripped reference PDB (no water/ions) — saves ~95% of file size
    # and makes downstream analyses faster.
    stripped = mol.copy()
    stripped.filter("protein or lipid or nucleic or "
                    "(not water and not ions)")
    stripped.write(str(aligned_pdb))
    stripped.write(str(aligned_dcd))

    return {
        "status": "ok",
        "n_frames": int(n_frames),
        "psf": psf_path,
        "pdb": str(aligned_pdb),
        "dcd": str(aligned_dcd),
        "align_sel": align_sel,
        "wrap_sel": wrap_sel,
    }


# --- RMSD -----------------------------------------------------------------

def compute_rmsd(
    run_dir: str,
    *,
    sel: str = "protein and name CA",
    ref_frame: int = 0,
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> Dict[str, Any]:
    """Per-frame RMSD vs. ``ref_frame``. Writes CSV. Returns timeseries +
    summary stats."""
    from moleculekit.projections.metricrmsd import MetricRmsd

    mol, *_ = _load_traj(run_dir, psf=psf, pdb=pdb, dcd=dcd)
    ref = mol.copy()
    ref.dropFrames(keep=int(ref_frame))
    # pbc=False so MetricRmsd does not try to wrap (which fails on
    # trajectories without complete box info on every frame).
    metric = MetricRmsd(ref, sel, pbc=False)
    rmsd = metric.project(mol).flatten()

    out = _ensure_outdir(run_dir)
    csv_path = out / f"rmsd_{ref_frame:04d}.csv"
    _write_csv(csv_path, ["frame", "rmsd_A"],
               [[i, float(v)] for i, v in enumerate(rmsd)])
    png_path = out / f"rmsd_{ref_frame:04d}.png"
    _plot_line(np.arange(len(rmsd)), rmsd,
               xlabel="frame", ylabel="RMSD (Å)",
               title=f"RMSD vs frame {ref_frame} ({sel})",
               png_path=png_path)
    return {
        "status": "ok",
        "selection": sel,
        "ref_frame": int(ref_frame),
        "csv": str(csv_path),
        "plot_png": str(png_path),
        "summary": _summary(rmsd),
        "n_atoms": int(np.sum(mol.atomselect(sel))),
    }


# --- RMSF -----------------------------------------------------------------

def compute_rmsf(
    run_dir: str,
    *,
    sel: str = "protein and name CA",
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> Dict[str, Any]:
    """Per-residue RMSF (root-mean-square fluctuation) over the trajectory."""
    mol, *_ = _load_traj(run_dir, psf=psf, pdb=pdb, dcd=dcd)
    sel_mask = mol.atomselect(sel)
    if not sel_mask.any():
        return {"status": "error", "error": f"selection {sel!r} matched 0 atoms"}

    coords = mol.coords[sel_mask]  # (N_atoms, 3, N_frames)
    mean = coords.mean(axis=2, keepdims=True)
    diffs = coords - mean
    rmsf = np.sqrt(np.mean(np.sum(diffs ** 2, axis=1), axis=1))  # (N_atoms,)

    resids = mol.resid[sel_mask]
    resnames = mol.resname[sel_mask]
    chains = mol.chain[sel_mask]

    out = _ensure_outdir(run_dir)
    csv_path = out / "rmsf.csv"
    _write_csv(
        csv_path,
        ["chain", "resid", "resname", "rmsf_A"],
        [[str(c), int(r), str(rn), float(v)]
         for c, r, rn, v in zip(chains, resids, resnames, rmsf)],
    )

    # Per-residue line plot (one trace per chain so labels read naturally).
    png_path = out / "rmsf.png"
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(9, 4))
    unique_chains = sorted(set(str(c) for c in chains))
    for c in unique_chains:
        m = np.array([str(cc) == c for cc in chains])
        if m.any():
            order = np.argsort(resids[m])
            ax.plot(np.asarray(resids[m])[order], rmsf[m][order],
                    lw=1.2, label=f"chain {c}")
    ax.set_xlabel("residue id")
    ax.set_ylabel("RMSF (Å)")
    ax.set_title(f"Per-residue RMSF ({sel})")
    ax.grid(alpha=0.3)
    if len(unique_chains) > 1:
        ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(str(png_path), dpi=120)
    plt.close(fig)

    return {
        "status": "ok",
        "selection": sel,
        "csv": str(csv_path),
        "plot_png": str(png_path),
        "summary": _summary(rmsf),
        "n_residues_or_atoms": int(rmsf.size),
    }


# --- SASA ------------------------------------------------------------------

def compute_sasa(
    run_dir: str,
    *,
    sel: str = "protein",
    mode: str = "total",  # "total" | "residue"
    probe_radius: float = 1.4,
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> Dict[str, Any]:
    """Solvent-accessible surface area via moleculekit (freesasa backend)."""
    from moleculekit.projections.metricsasa import MetricSasa

    mol, *_ = _load_traj(run_dir, psf=psf, pdb=pdb, dcd=dcd)
    # MetricSasa only supports "residue" / "atom"; for "total" we sum atoms.
    backend_mode = "atom" if mode == "total" else mode
    metric = MetricSasa(sel=sel, mode=backend_mode,
                        probeRadius=float(probe_radius))
    # MetricSasa returns nm^2 despite its docstring claiming Å^2 (it converts
    # radii to nm internally and uses mdtraj's shrake_rupley). Convert.
    sasa = metric.project(mol) * 100.0  # nm^2 -> A^2

    out = _ensure_outdir(run_dir)
    csv_path = out / f"sasa_{mode}.csv"
    png_path = out / f"sasa_{mode}.png"
    if mode == "total":
        total = sasa.sum(axis=1) if sasa.ndim == 2 else sasa
        _write_csv(csv_path, ["frame", "sasa_A2"],
                   [[i, float(v)] for i, v in enumerate(total)])
        summary = _summary(total)
        _plot_line(np.arange(len(total)), total,
                   xlabel="frame", ylabel="SASA (Å²)",
                   title=f"Total SASA ({sel})", png_path=png_path)
    else:
        n_frames, n_units = sasa.shape
        rows = [[i, j, float(sasa[i, j])]
                for i in range(n_frames) for j in range(n_units)]
        _write_csv(csv_path, ["frame", f"{mode}_index", "sasa_A2"], rows)
        summary = _summary(sasa.flatten())
        # Heatmap: residue index (y) vs frame (x). Transpose so frames go on x.
        _plot_heatmap(sasa.T,
                      xlabel="frame", ylabel=f"{mode} index",
                      title=f"Per-{mode} SASA ({sel})",
                      png_path=png_path,
                      cbar_label="SASA (Å²)")

    return {
        "status": "ok",
        "selection": sel,
        "mode": mode,
        "probe_radius": float(probe_radius),
        "csv": str(csv_path),
        "plot_png": str(png_path),
        "summary": summary,
    }


# --- Distances ------------------------------------------------------------

def compute_distances(
    run_dir: str,
    *,
    sel1: str,
    sel2: str,
    metric: str = "min",  # "min" | "centroid" | "all_pairs"
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> Dict[str, Any]:
    """Per-frame distance between two selections. ``metric``:
    ``min`` = minimum atom-atom distance, ``centroid`` = COM-COM,
    ``all_pairs`` = full N1*N2 distance matrix per frame (CSV may be large)."""
    mol, *_ = _load_traj(run_dir, psf=psf, pdb=pdb, dcd=dcd)
    a = mol.atomselect(sel1)
    b = mol.atomselect(sel2)
    if not a.any() or not b.any():
        return {"status": "error",
                "error": f"selection matched 0 atoms (sel1={a.sum()}, sel2={b.sum()})"}

    coords = mol.coords  # (N, 3, F)
    n_frames = coords.shape[2]
    out = _ensure_outdir(run_dir)
    csv_path = out / f"distance_{metric}.csv"

    png_path = out / f"distance_{metric}.png"
    if metric == "centroid":
        com1 = coords[a].mean(axis=0)  # (3, F)
        com2 = coords[b].mean(axis=0)
        d = np.linalg.norm(com1 - com2, axis=0)  # (F,)
        _write_csv(csv_path, ["frame", "distance_A"],
                   [[i, float(v)] for i, v in enumerate(d)])
        summary = _summary(d)
        _plot_line(np.arange(len(d)), d,
                   xlabel="frame", ylabel="centroid distance (Å)",
                   title=f"COM-COM distance: {sel1} ↔ {sel2}",
                   png_path=png_path)
    elif metric == "min":
        d = np.empty(n_frames, dtype=np.float64)
        for f in range(n_frames):
            c1 = coords[a, :, f]
            c2 = coords[b, :, f]
            diffs = c1[:, None, :] - c2[None, :, :]
            dist = np.sqrt(np.sum(diffs ** 2, axis=-1))
            d[f] = float(dist.min())
        _write_csv(csv_path, ["frame", "min_distance_A"],
                   [[i, float(v)] for i, v in enumerate(d)])
        summary = _summary(d)
        _plot_line(np.arange(len(d)), d,
                   xlabel="frame", ylabel="min distance (Å)",
                   title=f"Min atom-atom distance: {sel1} ↔ {sel2}",
                   png_path=png_path)
    elif metric == "all_pairs":
        rows: List[List[Any]] = []
        # Also build a mean-over-pairs timeseries and the mean pair matrix for
        # plotting (the raw all_pairs CSV can be huge but the summary plots
        # are cheap).
        n1, n2 = int(a.sum()), int(b.sum())
        mean_over_pairs = np.empty(n_frames, dtype=np.float64)
        mean_matrix = np.zeros((n1, n2), dtype=np.float64)
        for f in range(n_frames):
            c1 = coords[a, :, f]
            c2 = coords[b, :, f]
            diffs = c1[:, None, :] - c2[None, :, :]
            dist = np.sqrt(np.sum(diffs ** 2, axis=-1))
            mean_over_pairs[f] = float(dist.mean())
            mean_matrix += dist
            for i in range(dist.shape[0]):
                for j in range(dist.shape[1]):
                    rows.append([f, i, j, float(dist[i, j])])
        mean_matrix /= max(n_frames, 1)
        _write_csv(csv_path, ["frame", "i", "j", "distance_A"], rows)
        summary = {"n_pairs": n1 * n2, "n_frames": int(n_frames)}
        _plot_heatmap(mean_matrix,
                      xlabel=f"sel2 atom index (n={n2})",
                      ylabel=f"sel1 atom index (n={n1})",
                      title=f"Mean pair distance over {n_frames} frames",
                      png_path=png_path,
                      cbar_label="distance (Å)")
    else:
        return {"status": "error", "error": f"unknown metric {metric!r}"}

    return {
        "status": "ok",
        "sel1": sel1, "sel2": sel2, "metric": metric,
        "csv": str(csv_path),
        "plot_png": str(png_path),
        "summary": summary,
    }


# --- Radius of gyration ---------------------------------------------------

def radius_of_gyration(
    run_dir: str,
    *,
    sel: str = "protein and noh",
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> Dict[str, Any]:
    """Per-frame radius of gyration of ``sel``."""
    mol, *_ = _load_traj(run_dir, psf=psf, pdb=pdb, dcd=dcd)
    mask = mol.atomselect(sel)
    if not mask.any():
        return {"status": "error", "error": f"selection matched 0 atoms"}
    masses = mol.masses[mask]
    coords = mol.coords[mask]  # (N, 3, F)
    total_m = float(masses.sum())
    com = (coords * masses[:, None, None]).sum(axis=0) / total_m  # (3, F)
    diff = coords - com[None, :, :]
    rg = np.sqrt(
        (masses[:, None] * np.sum(diff ** 2, axis=1)).sum(axis=0) / total_m
    )
    out = _ensure_outdir(run_dir)
    csv_path = out / "rg.csv"
    _write_csv(csv_path, ["frame", "rg_A"],
               [[i, float(v)] for i, v in enumerate(rg)])
    png_path = out / "rg.png"
    _plot_line(np.arange(len(rg)), rg,
               xlabel="frame", ylabel="Rg (Å)",
               title=f"Radius of gyration ({sel})",
               png_path=png_path)
    return {
        "status": "ok",
        "selection": sel,
        "csv": str(csv_path),
        "plot_png": str(png_path),
        "summary": _summary(rg),
    }


# --- Ligand-specific ------------------------------------------------------

def ligand_rmsd(
    run_dir: str,
    *,
    ligand_resname: str,
    ref_frame: int = 0,
    align_protein_first: bool = True,
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> Dict[str, Any]:
    """RMSD of ligand heavy atoms vs ``ref_frame``, optionally after
    aligning the protein backbone (so we measure ligand drift relative
    to the protein, not box wandering)."""
    mol, *_ = _load_traj(run_dir, psf=psf, pdb=pdb, dcd=dcd)
    if align_protein_first:
        mol.align("protein and name CA")

    from moleculekit.projections.metricrmsd import MetricRmsd
    ref = mol.copy()
    ref.dropFrames(keep=int(ref_frame))
    sel = f"resname {ligand_resname.upper()} and noh"
    metric = MetricRmsd(ref, sel, pbc=False)
    rmsd = metric.project(mol).flatten()

    out = _ensure_outdir(run_dir)
    csv_path = out / f"ligand_rmsd_{ligand_resname.upper()}.csv"
    _write_csv(csv_path, ["frame", "rmsd_A"],
               [[i, float(v)] for i, v in enumerate(rmsd)])
    png_path = out / f"ligand_rmsd_{ligand_resname.upper()}.png"
    _plot_line(
        np.arange(len(rmsd)), rmsd,
        xlabel="frame", ylabel="ligand RMSD (Å)",
        title=(f"Ligand {ligand_resname.upper()} RMSD vs frame {ref_frame}"
               + (" (protein-aligned)" if align_protein_first else "")),
        png_path=png_path,
    )
    return {
        "status": "ok",
        "ligand_resname": ligand_resname.upper(),
        "ref_frame": int(ref_frame),
        "csv": str(csv_path),
        "plot_png": str(png_path),
        "summary": _summary(rmsd),
    }


def ligand_protein_contacts(
    run_dir: str,
    *,
    ligand_resname: str,
    cutoff_A: float = 4.0,
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> Dict[str, Any]:
    """Per-residue contact frequency (fraction of frames any ligand atom
    is within ``cutoff_A`` of any protein atom of that residue)."""
    mol, *_ = _load_traj(run_dir, psf=psf, pdb=pdb, dcd=dcd)
    lig = mol.atomselect(f"resname {ligand_resname.upper()}")
    prot = mol.atomselect("protein")
    if not lig.any():
        return {"status": "error",
                "error": f"resname {ligand_resname!r} not found"}

    coords = mol.coords  # (N, 3, F)
    n_frames = coords.shape[2]
    cutoff2 = float(cutoff_A) ** 2

    # Group protein atoms by (chain, resid)
    chains = mol.chain
    resids = mol.resid
    resnames = mol.resname
    prot_idx = np.where(prot)[0]
    groups: Dict[Tuple[str, int], Tuple[List[int], str]] = {}
    for i in prot_idx:
        key = (str(chains[i]), int(resids[i]))
        if key not in groups:
            groups[key] = ([i], str(resnames[i]))
        else:
            groups[key][0].append(i)

    lig_idx = np.where(lig)[0]
    counts = {k: 0 for k in groups}

    for f in range(n_frames):
        lc = coords[lig_idx, :, f]  # (Nlig, 3)
        for key, (idxs, _) in groups.items():
            pc = coords[idxs, :, f]  # (Np, 3)
            diffs = lc[:, None, :] - pc[None, :, :]
            d2 = np.sum(diffs ** 2, axis=-1)
            if (d2 <= cutoff2).any():
                counts[key] += 1

    rows = []
    for (chain, resid), n in counts.items():
        freq = float(n) / float(n_frames) if n_frames else 0.0
        if freq > 0:
            rows.append([chain, resid, groups[(chain, resid)][1], n, freq])
    rows.sort(key=lambda r: -r[4])

    out = _ensure_outdir(run_dir)
    csv_path = out / f"ligand_contacts_{ligand_resname.upper()}.csv"
    _write_csv(csv_path,
               ["chain", "resid", "resname", "n_frames_in_contact", "frequency"],
               rows)

    top = rows[:20]
    png_path = out / f"ligand_contacts_{ligand_resname.upper()}.png"
    if rows:
        labels = [f"{r[2]}{r[1]}{(':'+r[0]) if r[0] else ''}" for r in top]
        values = [float(r[4]) for r in top]
        _plot_bar(
            labels, values,
            xlabel="residue", ylabel="contact frequency",
            title=(f"Top contacts of {ligand_resname.upper()} "
                   f"(cutoff {cutoff_A:.1f} Å)"),
            png_path=png_path,
        )
    else:
        png_path = None
    return {
        "status": "ok",
        "ligand_resname": ligand_resname.upper(),
        "cutoff_A": float(cutoff_A),
        "n_frames": int(n_frames),
        "n_residues_with_contact": len(rows),
        "csv": str(csv_path),
        "plot_png": str(png_path) if png_path else None,
        "top_contacts": [
            {"chain": r[0], "resid": r[1], "resname": r[2], "frequency": r[4]}
            for r in top
        ],
    }


# --- Protein-protein interface ---------------------------------------------

def _per_residue_contact_frequency(
    coords: np.ndarray,
    side_idx: np.ndarray,
    other_idx: np.ndarray,
    chains: np.ndarray,
    resids: np.ndarray,
    resnames: np.ndarray,
    segids: np.ndarray,
    cutoff_A: float,
) -> List[List[Any]]:
    """Compute per-residue contact frequency on ``side_idx`` against any atom
    in ``other_idx``. Returns rows of [chain, resid, resname, segid, n, freq]
    sorted by descending frequency."""
    n_frames = coords.shape[2]
    cutoff2 = float(cutoff_A) ** 2

    groups: Dict[Tuple[str, int, str], Tuple[List[int], str]] = {}
    for i in side_idx:
        key = (str(chains[i]), int(resids[i]), str(segids[i]))
        if key not in groups:
            groups[key] = ([int(i)], str(resnames[i]))
        else:
            groups[key][0].append(int(i))

    counts = {k: 0 for k in groups}
    for f in range(n_frames):
        oc = coords[other_idx, :, f]
        for key, (idxs, _) in groups.items():
            sc = coords[idxs, :, f]
            diffs = sc[:, None, :] - oc[None, :, :]
            d2 = np.sum(diffs ** 2, axis=-1)
            if (d2 <= cutoff2).any():
                counts[key] += 1

    rows: List[List[Any]] = []
    for (chain, resid, segid), n in counts.items():
        freq = float(n) / float(n_frames) if n_frames else 0.0
        if freq > 0:
            rows.append([chain, resid, groups[(chain, resid, segid)][1],
                         segid, int(n), float(freq)])
    rows.sort(key=lambda r: -r[5])
    return rows


def interface_contacts(
    run_dir: str,
    *,
    receptor_sel: str,
    partner_sel: str,
    cutoff_A: float = 4.5,
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> Dict[str, Any]:
    """Per-residue contact frequency at a protein-protein interface.

    Returns one CSV per side (receptor / partner) listing each residue and
    the fraction of frames in which any of its atoms is within ``cutoff_A``
    of any atom in the other partner. The summary returns the top 20 hot
    residues on each side — these are the interface residues to highlight
    in figures and in the report.

    Use ``receptor_sel`` / ``partner_sel`` from
    ``build_protein_protein_complex``'s output (``receptor_selection`` and
    ``partner_selection`` keys), or provide your own VMD-style selections."""
    mol, *_ = _load_traj(run_dir, psf=psf, pdb=pdb, dcd=dcd)
    rec_mask = mol.atomselect(receptor_sel)
    part_mask = mol.atomselect(partner_sel)
    if not rec_mask.any() or not part_mask.any():
        return {
            "status": "error",
            "error": (f"empty selection (receptor={int(rec_mask.sum())}, "
                      f"partner={int(part_mask.sum())})"),
        }

    coords = mol.coords  # (N, 3, F)
    rec_idx = np.where(rec_mask)[0]
    part_idx = np.where(part_mask)[0]

    rec_rows = _per_residue_contact_frequency(
        coords, rec_idx, part_idx,
        mol.chain, mol.resid, mol.resname, mol.segid, cutoff_A,
    )
    part_rows = _per_residue_contact_frequency(
        coords, part_idx, rec_idx,
        mol.chain, mol.resid, mol.resname, mol.segid, cutoff_A,
    )

    out = _ensure_outdir(run_dir)
    rec_csv = out / "interface_contacts_receptor.csv"
    part_csv = out / "interface_contacts_partner.csv"
    header = ["chain", "resid", "resname", "segid",
              "n_frames_in_contact", "frequency"]
    _write_csv(rec_csv, header, rec_rows)
    _write_csv(part_csv, header, part_rows)

    def _top(rows):
        return [
            {"chain": r[0], "resid": r[1], "resname": r[2],
             "segid": r[3], "frequency": r[5]}
            for r in rows[:20]
        ]

    rec_png = out / "interface_contacts_receptor.png"
    part_png = out / "interface_contacts_partner.png"
    if rec_rows:
        labels = [f"{r[2]}{r[1]}{(':'+r[0]) if r[0] else ''}"
                  for r in rec_rows[:20]]
        values = [float(r[5]) for r in rec_rows[:20]]
        _plot_bar(labels, values,
                  xlabel="receptor residue", ylabel="contact frequency",
                  title=(f"Receptor interface hotspots "
                         f"(cutoff {cutoff_A:.1f} Å)"),
                  png_path=rec_png)
    else:
        rec_png = None
    if part_rows:
        labels = [f"{r[2]}{r[1]}{(':'+r[0]) if r[0] else ''}"
                  for r in part_rows[:20]]
        values = [float(r[5]) for r in part_rows[:20]]
        _plot_bar(labels, values,
                  xlabel="partner residue", ylabel="contact frequency",
                  title=(f"Partner interface hotspots "
                         f"(cutoff {cutoff_A:.1f} Å)"),
                  png_path=part_png)
    else:
        part_png = None

    return {
        "status": "ok",
        "receptor_sel": receptor_sel,
        "partner_sel": partner_sel,
        "cutoff_A": float(cutoff_A),
        "n_frames": int(coords.shape[2]),
        "n_receptor_interface_residues": len(rec_rows),
        "n_partner_interface_residues": len(part_rows),
        "csv_receptor": str(rec_csv),
        "csv_partner": str(part_csv),
        "plot_png_receptor": str(rec_png) if rec_png else None,
        "plot_png_partner": str(part_png) if part_png else None,
        "top_receptor": _top(rec_rows),
        "top_partner": _top(part_rows),
    }


def interface_rmsd(
    run_dir: str,
    *,
    receptor_sel: str,
    partner_sel: str,
    cutoff_A: float = 5.0,
    align_receptor_first: bool = True,
    ref_frame: int = 0,
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> Dict[str, Any]:
    """Backbone RMSD of interface residues across the trajectory.

    Interface residues are those with any atom within ``cutoff_A`` of the
    other partner in ``ref_frame`` (the IRMSD definition used in CAPRI
    docking benchmarks). When ``align_receptor_first`` is True, the
    trajectory is first aligned on the receptor backbone so the RMSD
    reports relative motion of the partner's interface residues against a
    fixed receptor — i.e., binding-pose drift."""
    mol, *_ = _load_traj(run_dir, psf=psf, pdb=pdb, dcd=dcd)
    rec_mask = mol.atomselect(receptor_sel)
    part_mask = mol.atomselect(partner_sel)
    if not rec_mask.any() or not part_mask.any():
        return {
            "status": "error",
            "error": f"empty selection (receptor={int(rec_mask.sum())}, "
                     f"partner={int(part_mask.sum())})",
        }

    # Identify interface residues in ref_frame: residues on either side
    # whose any-atom distance to the other partner is < cutoff at frame 0.
    coords_ref = mol.coords[:, :, int(ref_frame)]
    rec_idx = np.where(rec_mask)[0]
    part_idx = np.where(part_mask)[0]
    rc = coords_ref[rec_idx]
    pc = coords_ref[part_idx]
    diffs = rc[:, None, :] - pc[None, :, :]
    d2 = np.sum(diffs ** 2, axis=-1)
    cutoff2 = float(cutoff_A) ** 2
    rec_close_atom = (d2 <= cutoff2).any(axis=1)  # (N_rec_atoms,)
    part_close_atom = (d2 <= cutoff2).any(axis=0)  # (N_part_atoms,)

    # Promote atom-level closeness to residue-level via (chain, resid, segid)
    chains, resids, segids = mol.chain, mol.resid, mol.segid

    def _residue_keys(side_idx, close_atom):
        keys = set()
        for k, idx in enumerate(side_idx):
            if close_atom[k]:
                keys.add((str(chains[idx]), int(resids[idx]),
                          str(segids[idx])))
        return keys

    rec_iface_keys = _residue_keys(rec_idx, rec_close_atom)
    part_iface_keys = _residue_keys(part_idx, part_close_atom)
    if not rec_iface_keys or not part_iface_keys:
        return {
            "status": "error",
            "error": "no interface residues at ref_frame within cutoff",
        }

    # Build a backbone-only mask of all interface residues (both sides).
    backbone = mol.atomselect("backbone")
    iface_mask = np.zeros(mol.numAtoms, dtype=bool)
    for k in rec_iface_keys | part_iface_keys:
        chain, resid, segid = k
        iface_mask |= (
            (chains == chain) & (resids == resid) & (segids == segid)
            & backbone
        )
    if not iface_mask.any():
        return {"status": "error",
                "error": "interface backbone selection matched 0 atoms"}

    # Build a moleculekit selection string usable by MetricRmsd.
    # Easier: use the precomputed mask via a selection on user-defined field.
    # Mole-cule has no "by-mask-selection" syntax, so we compute RMSD by hand.
    if align_receptor_first:
        mol.align(f"({receptor_sel}) and backbone")

    coords = mol.coords  # (N, 3, F)
    n_frames = coords.shape[2]
    ref = coords[iface_mask, :, int(ref_frame)]
    rmsd = np.empty(n_frames, dtype=np.float64)
    for f in range(n_frames):
        diff = coords[iface_mask, :, f] - ref
        rmsd[f] = float(np.sqrt(np.mean(np.sum(diff ** 2, axis=1))))

    out = _ensure_outdir(run_dir)
    csv_path = out / f"interface_rmsd_{ref_frame:04d}.csv"
    _write_csv(csv_path, ["frame", "interface_rmsd_A"],
               [[i, float(v)] for i, v in enumerate(rmsd)])

    png_path = out / f"interface_rmsd_{ref_frame:04d}.png"
    _plot_line(np.arange(len(rmsd)), rmsd,
               xlabel="frame", ylabel="interface RMSD (Å)",
               title=(f"Interface backbone RMSD vs frame {ref_frame} "
                      f"(cutoff {cutoff_A:.1f} Å"
                      + (", receptor-aligned" if align_receptor_first else "")
                      + ")"),
               png_path=png_path)

    return {
        "status": "ok",
        "receptor_sel": receptor_sel,
        "partner_sel": partner_sel,
        "cutoff_A": float(cutoff_A),
        "ref_frame": int(ref_frame),
        "align_receptor_first": bool(align_receptor_first),
        "n_interface_residues_receptor": len(rec_iface_keys),
        "n_interface_residues_partner": len(part_iface_keys),
        "n_interface_backbone_atoms": int(iface_mask.sum()),
        "csv": str(csv_path),
        "plot_png": str(png_path),
        "summary": _summary(rmsd),
    }


def buried_sasa(
    run_dir: str,
    *,
    receptor_sel: str,
    partner_sel: str,
    probe_radius: float = 1.4,
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> Dict[str, Any]:
    """Per-frame interfacial buried SASA::

        ΔSASA = SASA(receptor alone) + SASA(partner alone) − SASA(complex)

    Computed by deleting one partner at a time from a temporary copy.
    Higher buried SASA means a tighter interface; the standard threshold
    for a "real" interface is ~600 Å² (Jones & Thornton, 1996)."""
    from moleculekit.projections.metricsasa import MetricSasa

    mol_complex, *_ = _load_traj(run_dir, psf=psf, pdb=pdb, dcd=dcd)
    if not mol_complex.atomselect(receptor_sel).any():
        return {"status": "error",
                "error": f"receptor_sel {receptor_sel!r} matched 0 atoms"}
    if not mol_complex.atomselect(partner_sel).any():
        return {"status": "error",
                "error": f"partner_sel {partner_sel!r} matched 0 atoms"}

    # MetricSasa has a known wart: when sel is a subset of the molecule it
    # returns nm^2; when sel is "all" of a filtered molecule it returns A^2.
    # Side-step by always filtering first and projecting with sel="all", so
    # units stay Å² throughout.
    def _total_sasa_filtered(m_filtered):
        v = MetricSasa(sel="all", mode="atom",
                       probeRadius=float(probe_radius)).project(m_filtered)
        if v.ndim == 2:
            return v.sum(axis=1)
        return v

    union_only = mol_complex.copy()
    union_only.filter(f"({receptor_sel}) or ({partner_sel})")
    sasa_complex = _total_sasa_filtered(union_only)

    rec_only = mol_complex.copy()
    rec_only.filter(receptor_sel)
    sasa_receptor = _total_sasa_filtered(rec_only)

    part_only = mol_complex.copy()
    part_only.filter(partner_sel)
    sasa_partner = _total_sasa_filtered(part_only)

    n = min(len(sasa_complex), len(sasa_receptor), len(sasa_partner))
    sasa_complex = sasa_complex[:n]
    sasa_receptor = sasa_receptor[:n]
    sasa_partner = sasa_partner[:n]
    buried = sasa_receptor + sasa_partner - sasa_complex

    out = _ensure_outdir(run_dir)
    csv_path = out / "buried_sasa.csv"
    _write_csv(
        csv_path,
        ["frame", "sasa_receptor_A2", "sasa_partner_A2",
         "sasa_complex_A2", "buried_sasa_A2"],
        [[i, float(sasa_receptor[i]), float(sasa_partner[i]),
          float(sasa_complex[i]), float(buried[i])]
         for i in range(n)],
    )

    # Per-frame plot: buried SASA on its own panel, all three component SASAs
    # on a second panel.  The ~600 Å² rule of thumb is drawn as a dashed line.
    png_path = out / "buried_sasa.png"
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(9, 6), sharex=True)
    frames = np.arange(n)
    ax1.plot(frames, buried, lw=1.4, color="#d62728", label="buried SASA")
    ax1.axhline(600.0, color="gray", ls="--", lw=0.8,
                label="~600 Å² interface threshold")
    if buried.size:
        ax1.axhline(float(np.mean(buried)), color="#1f77b4", ls=":",
                    lw=0.8, label=f"mean={float(np.mean(buried)):.0f}")
    ax1.set_ylabel("buried SASA (Å²)")
    ax1.set_title("Interfacial buried SASA")
    ax1.grid(alpha=0.3)
    ax1.legend(fontsize=8, loc="best")
    ax2.plot(frames, sasa_receptor, lw=1.0, label="receptor alone")
    ax2.plot(frames, sasa_partner, lw=1.0, label="partner alone")
    ax2.plot(frames, sasa_complex, lw=1.0, label="complex")
    ax2.set_xlabel("frame")
    ax2.set_ylabel("SASA (Å²)")
    ax2.grid(alpha=0.3)
    ax2.legend(fontsize=8, loc="best")
    fig.tight_layout()
    fig.savefig(str(png_path), dpi=120)
    plt.close(fig)

    return {
        "status": "ok",
        "receptor_sel": receptor_sel,
        "partner_sel": partner_sel,
        "probe_radius": float(probe_radius),
        "n_frames": int(n),
        "csv": str(csv_path),
        "plot_png": str(png_path),
        "summary_buried_A2": _summary(buried),
        "summary_complex_A2": _summary(sasa_complex),
    }
