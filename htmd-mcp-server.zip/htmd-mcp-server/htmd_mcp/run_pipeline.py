"""High-level convenience: run an entire MD pipeline from a build directory.

``prepare_run`` chains:

1. ``setup_minimization`` + ``run_namd3`` (synchronous)
2. ``setup_equilibration`` + ``run_namd3`` (synchronous)
3. ``setup_production`` + ``run_namd3`` (background by default)

It writes everything under ``workspace/{min,equil,prod}/`` and returns the
PID + log path of the production run so the caller can poll with
``monitor_namd_run``.
"""

from __future__ import annotations

import logging
import os
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


def prepare_run(
    build_dir: str,
    workspace: str,
    *,
    # Minimization
    min_steps: int = 5000,
    min_restraint_selection: Optional[str] = "protein and noh and not name CA",
    min_restraint_k: float = 1.0,
    skip_min: bool = False,
    # Equilibration
    equil_run_ns: float = 2.0,
    equil_timestep_fs: float = 2.0,
    equil_restraint_selection: str = "protein and name CA",
    equil_restraint_k: float = 1.0,
    equil_restraint_schedule: Optional[List[List[float]]] = None,
    equil_minimize_first: bool = True,
    equil_minimize_steps: int = 1000,
    equil_ensemble: str = "NPT",
    skip_equil: bool = False,
    # Production
    prod_run_ns: float = 100.0,
    prod_timestep_fs: float = 4.0,
    hydrogen_mass_repartition: bool = True,
    prod_dcd_freq_ps: float = 10.0,
    prod_restart_freq_ps: float = 100.0,
    prod_ensemble: str = "NPT",
    background_production: bool = True,
    background_equilibration: bool = False,
    # Common
    membrane: bool = False,
    margin: float = 2.0,
    temperature: float = 300.0,
    pressure: float = 1.01325,
    seed: Optional[int] = None,
    num_threads: int = 4,
    gpu_devices: str = "0",
    forcefield: str = "charmm",
) -> Dict[str, Any]:
    """Run min → equil → prod from a built system. Returns per-stage info.

    By default the production run is launched in the background and the
    function returns immediately with its PID. Set
    ``background_production=False`` to block until production completes."""
    from htmd_mcp.namd3_writer import (
        write_minimization, write_equilibration, write_production,
    )
    from htmd_mcp.namd3_runner import run_namd3, parse_namd_log

    build_dir = os.path.abspath(build_dir)
    workspace = os.path.abspath(workspace)
    os.makedirs(workspace, exist_ok=True)

    min_dir = os.path.join(workspace, "min")
    equil_dir = os.path.join(workspace, "equil")
    prod_dir = os.path.join(workspace, "prod")

    timeline = {"started_at": time.time()}
    result: Dict[str, Any] = {
        "status": "ok",
        "build_dir": build_dir,
        "workspace": workspace,
        "membrane": bool(membrane),
        "stages": {},
    }

    # --- Stage 1: minimization -------------------------------------------
    if skip_min and (Path(min_dir) / "min.coor").is_file():
        result["stages"]["minimization"] = {
            "status": "skipped",
            "run_dir": min_dir,
        }
    else:
        t0 = time.time()
        write_minimization(
            build_dir=build_dir,
            run_dir=min_dir,
            steps=int(min_steps),
            temperature=float(temperature),
            timestep_fs=1.0,
            output_freq=max(100, int(min_steps // 10)),
            restraint_selection=min_restraint_selection,
            restraint_k=float(min_restraint_k),
            seed=seed,
            forcefield=forcefield,
        )
        run_info = run_namd3(
            run_dir=min_dir,
            namd_input="min.namd",
            num_threads=int(num_threads),
            gpu_devices=str(gpu_devices),
            wait=True,
        )
        result["stages"]["minimization"] = {
            "run_dir": min_dir,
            "elapsed_s": time.time() - t0,
            **run_info,
        }
        if run_info.get("status") != "ok":
            result["status"] = "error"
            result["error"] = "minimization failed"
            return result

    # --- Stage 2: equilibration ------------------------------------------
    if skip_equil and (Path(equil_dir) / "equil.coor").is_file():
        result["stages"]["equilibration"] = {
            "status": "skipped",
            "run_dir": equil_dir,
        }
    else:
        t0 = time.time()
        write_equilibration(
            prev_dir=min_dir,
            run_dir=equil_dir,
            run_ns=float(equil_run_ns),
            temperature=float(temperature),
            pressure=float(pressure),
            timestep_fs=float(equil_timestep_fs),
            minimize_first=bool(equil_minimize_first),
            minimize_steps=int(equil_minimize_steps),
            restraint_selection=equil_restraint_selection,
            restraint_k=float(equil_restraint_k),
            restraint_schedule=equil_restraint_schedule,
            membrane=bool(membrane),
            margin=float(margin),
            ensemble=equil_ensemble,
            seed=seed,
            forcefield=forcefield,
        )
        run_info = run_namd3(
            run_dir=equil_dir,
            namd_input="equil.namd",
            num_threads=int(num_threads),
            gpu_devices=str(gpu_devices),
            wait=not bool(background_equilibration),
        )
        result["stages"]["equilibration"] = {
            "run_dir": equil_dir,
            "elapsed_s": time.time() - t0,
            **run_info,
        }
        if background_equilibration:
            # User asked us not to wait — production won't be set up yet.
            # Tell them how to run prod after equilibration finishes.
            result["status"] = "started"
            result["next_step"] = (
                f"Equilibration backgrounded. After it completes, call "
                f"setup_production with prev_dir='{equil_dir}' and "
                f"run_dir='{prod_dir}', then run_namd3 with wait=False."
            )
            return result
        if run_info.get("status") != "ok":
            result["status"] = "error"
            result["error"] = "equilibration failed"
            return result

    # --- Stage 3: production --------------------------------------------
    write_info = write_production(
        prev_dir=equil_dir,
        run_dir=prod_dir,
        run_ns=float(prod_run_ns),
        temperature=float(temperature),
        pressure=float(pressure),
        timestep_fs=float(prod_timestep_fs),
        hydrogen_mass_repartition=bool(hydrogen_mass_repartition),
        membrane=bool(membrane),
        margin=float(margin),
        dcd_freq_ps=float(prod_dcd_freq_ps),
        restart_freq_ps=float(prod_restart_freq_ps),
        ensemble=prod_ensemble,
        seed=seed,
        forcefield=forcefield,
    )
    t0 = time.time()
    run_info = run_namd3(
        run_dir=prod_dir,
        namd_input="prod.namd",
        num_threads=int(num_threads),
        gpu_devices=str(gpu_devices),
        wait=not bool(background_production),
    )
    if not background_production:
        run_info["elapsed_s"] = time.time() - t0
    result["stages"]["production"] = {
        "run_dir": prod_dir,
        "config": write_info,
        **run_info,
    }

    # Surface the loop suggestion at the top level so it's the first thing
    # the user sees in the response.
    if background_production and run_info.get("loop_suggestion"):
        result["status"] = "started"
        result["loop_suggestion"] = run_info["loop_suggestion"]
        result["loop_interval"] = run_info.get("loop_interval")
        result["expected_runtime_hours"] = run_info.get("expected_runtime_hours")
        result["human_message"] = run_info.get("human_message")

    timeline["finished_at"] = time.time()
    timeline["wall_s"] = timeline["finished_at"] - timeline["started_at"]
    result["timeline"] = timeline
    return result
