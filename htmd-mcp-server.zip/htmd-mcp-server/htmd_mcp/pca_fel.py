"""PCA, clustering, free-energy landscapes, kernel-density estimation.

All tools take a ``run_dir`` and write outputs into ``run_dir/analysis/``.

PCA is run on aligned Cartesian coordinates of a user-chosen selection
(default Cα). Resulting projections double as collective variables for the
FEL / KDE tools.
"""

from __future__ import annotations

import csv
import json
import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from htmd_mcp.postprocess import (
    _load_traj, _ensure_outdir, _write_csv, _summary,
)

logger = logging.getLogger(__name__)

# kT at 300 K in kcal/mol = R * T = 1.987e-3 * 300 = 0.596 kcal/mol
KT_KCAL_PER_MOL_300K = 0.5961621


# --- PCA -------------------------------------------------------------------

def compute_pca(
    run_dir: str,
    *,
    sel: str = "protein and name CA",
    n_components: int = 10,
    align_first: bool = True,
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> Dict[str, Any]:
    """Cartesian PCA after aligning the trajectory on ``sel``.

    Returns: explained variance ratios, projections per frame for all
    components, and CSVs of (frame, PC1, PC2, ...). Eigenvectors are
    saved as a npy file (large) for later reconstruction."""
    from sklearn.decomposition import PCA

    mol, *_ = _load_traj(run_dir, psf=psf, pdb=pdb, dcd=dcd)
    if align_first:
        mol.align(sel)

    mask = mol.atomselect(sel)
    if not mask.any():
        return {"status": "error", "error": f"selection {sel!r} matched 0 atoms"}

    coords = mol.coords[mask]  # (N, 3, F)
    n_atoms, _, n_frames = coords.shape
    # Reshape to (n_frames, 3*n_atoms)
    X = coords.transpose(2, 0, 1).reshape(n_frames, -1)

    n_comp = int(min(n_components, X.shape[0] - 1, X.shape[1]))
    if n_comp < 1:
        return {"status": "error", "error": "not enough frames/atoms for PCA"}
    pca = PCA(n_components=n_comp)
    proj = pca.fit_transform(X)  # (frames, n_comp)

    out = _ensure_outdir(run_dir)
    csv_path = out / "pca_projections.csv"
    header = ["frame"] + [f"PC{i+1}" for i in range(n_comp)]
    rows = [[i] + [float(v) for v in proj[i]] for i in range(n_frames)]
    _write_csv(csv_path, header, rows)

    var_csv = out / "pca_explained_variance.csv"
    _write_csv(
        var_csv,
        ["component", "eigenvalue", "explained_variance_ratio", "cumulative"],
        [[i + 1, float(pca.explained_variance_[i]),
          float(pca.explained_variance_ratio_[i]),
          float(np.cumsum(pca.explained_variance_ratio_)[i])]
         for i in range(n_comp)],
    )

    np.save(out / "pca_components.npy", pca.components_)

    # Plot variance + PC1-PC2 scatter
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    axes[0].plot(np.arange(1, n_comp + 1),
                 pca.explained_variance_ratio_, "o-")
    axes[0].set_xlabel("PC index")
    axes[0].set_ylabel("explained variance ratio")
    axes[0].set_title("Scree")

    axes[1].plot(proj[:, 0], proj[:, 1] if n_comp > 1 else proj[:, 0] * 0,
                 "-", lw=0.5, alpha=0.7)
    sc = axes[1].scatter(proj[:, 0], proj[:, 1] if n_comp > 1 else proj[:, 0] * 0,
                         c=np.arange(n_frames), cmap="viridis", s=8)
    plt.colorbar(sc, ax=axes[1], label="frame")
    axes[1].set_xlabel("PC1")
    axes[1].set_ylabel("PC2" if n_comp > 1 else "")
    axes[1].set_title("PC1 vs PC2")
    fig.tight_layout()
    png = out / "pca.png"
    fig.savefig(png, dpi=120)
    plt.close(fig)

    return {
        "status": "ok",
        "selection": sel,
        "n_frames": int(n_frames),
        "n_atoms": int(n_atoms),
        "n_components": int(n_comp),
        "explained_variance_ratio": [float(v) for v in pca.explained_variance_ratio_],
        "cumulative_variance": [float(v) for v in np.cumsum(pca.explained_variance_ratio_)],
        "projections_csv": str(csv_path),
        "variance_csv": str(var_csv),
        "components_npy": str(out / "pca_components.npy"),
        "plot_png": str(png),
    }


# --- Clustering ------------------------------------------------------------

def cluster_trajectory(
    run_dir: str,
    *,
    method: str = "kmeans",  # "kmeans" | "agglomerative" | "dbscan"
    n_clusters: int = 5,
    on: str = "pca",  # "pca" -> use existing pca_projections.csv | "rmsd"
    n_components: int = 3,
    sel: str = "protein and name CA",
    eps: float = 1.0,
    min_samples: int = 5,
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> Dict[str, Any]:
    """Cluster trajectory frames.

    on='pca' loads ``run_dir/analysis/pca_projections.csv`` (run compute_pca first)
    and clusters in PC space using the first ``n_components`` PCs.
    on='rmsd' computes a pairwise RMSD matrix on the Cα atoms and clusters that.
    """
    out = _ensure_outdir(run_dir)

    if on == "pca":
        proj_csv = out / "pca_projections.csv"
        if not proj_csv.is_file():
            return {"status": "error",
                    "error": "PCA projections not found; run compute_pca first."}
        with open(proj_csv) as fh:
            r = csv.reader(fh)
            header = next(r)
            arr = np.array([[float(x) for x in row[1:]] for row in r])
        X = arr[:, :int(n_components)]
        n_frames = arr.shape[0]
    elif on == "rmsd":
        from moleculekit.molecule import Molecule
        mol, *_ = _load_traj(run_dir, psf=psf, pdb=pdb, dcd=dcd)
        mol.align(sel)
        mask = mol.atomselect(sel)
        if not mask.any():
            return {"status": "error", "error": f"selection {sel!r} matched 0 atoms"}
        coords = mol.coords[mask].transpose(2, 0, 1)  # (F, N, 3)
        n_frames = coords.shape[0]
        X = coords.reshape(n_frames, -1)
    else:
        return {"status": "error", "error": f"unknown 'on' {on!r}"}

    from sklearn.cluster import KMeans, AgglomerativeClustering, DBSCAN
    from sklearn.metrics import silhouette_score

    if method == "kmeans":
        clustering = KMeans(n_clusters=int(n_clusters), n_init=10,
                           random_state=0)
    elif method == "agglomerative":
        clustering = AgglomerativeClustering(n_clusters=int(n_clusters))
    elif method == "dbscan":
        clustering = DBSCAN(eps=float(eps), min_samples=int(min_samples))
    else:
        return {"status": "error", "error": f"unknown method {method!r}"}

    labels = clustering.fit_predict(X)
    unique_labels = sorted(set(int(l) for l in labels))
    populations = {int(l): int(np.sum(labels == l)) for l in unique_labels}

    silh: Optional[float] = None
    if len(unique_labels) > 1 and -1 not in unique_labels:
        try:
            silh = float(silhouette_score(X, labels))
        except Exception:
            silh = None

    # Per-cluster representative frame: closest to centroid
    representatives: Dict[int, int] = {}
    for l in unique_labels:
        if l < 0:
            continue
        members = np.where(labels == l)[0]
        if len(members) == 0:
            continue
        sub = X[members]
        centroid = sub.mean(axis=0)
        dists = np.linalg.norm(sub - centroid, axis=1)
        representatives[int(l)] = int(members[int(np.argmin(dists))])

    csv_path = out / f"clusters_{method}.csv"
    _write_csv(csv_path, ["frame", "cluster"],
               [[i, int(labels[i])] for i in range(n_frames)])

    summary_path = out / f"clusters_{method}_summary.json"
    summary = {
        "method": method,
        "n_clusters": len(unique_labels),
        "populations": populations,
        "representatives": representatives,
        "silhouette_score": silh,
    }
    summary_path.write_text(json.dumps(summary, indent=2))

    # Plot
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    if X.shape[1] >= 2:
        fig, ax = plt.subplots(figsize=(7, 6))
        sc = ax.scatter(X[:, 0], X[:, 1], c=labels, cmap="tab10", s=10)
        ax.set_xlabel("PC1" if on == "pca" else "dim0")
        ax.set_ylabel("PC2" if on == "pca" else "dim1")
        ax.set_title(f"Clusters ({method}, k={len(unique_labels)})")
        plt.colorbar(sc, ax=ax, label="cluster")
        fig.tight_layout()
        png = out / f"clusters_{method}.png"
        fig.savefig(png, dpi=120)
        plt.close(fig)
    else:
        png = None

    return {
        "status": "ok",
        "method": method,
        "n_clusters": len(unique_labels),
        "n_frames": int(n_frames),
        "populations": populations,
        "representatives": representatives,
        "silhouette_score": silh,
        "labels_csv": str(csv_path),
        "summary_json": str(summary_path),
        "plot_png": str(png) if png else None,
    }


# --- Free-energy landscape (2D / 3D) --------------------------------------

def free_energy_landscape(
    run_dir: str,
    *,
    cv_csv: Optional[str] = None,
    cv_columns: Optional[List[str]] = None,
    method: str = "histogram",  # "histogram" | "kde"
    bins: int = 60,
    temperature: float = 300.0,
    output_basename: str = "fel",
) -> Dict[str, Any]:
    """Compute -kT*ln(P) on 2 or 3 collective variables.

    By default reads ``run_dir/analysis/pca_projections.csv`` and uses PC1+PC2
    (2D) or PC1+PC2+PC3 (3D). Writes:

    * ``<basename>_2d.png`` — matplotlib filled contour with energy in kcal/mol
    * ``<basename>_3d.html`` — plotly volume / isosurface (interactive)
    * ``<basename>_grid.npz`` — raw grids for further analysis
    """
    out = _ensure_outdir(run_dir)
    if cv_csv is None:
        cv_csv = str(out / "pca_projections.csv")
    if not os.path.isfile(cv_csv):
        return {"status": "error",
                "error": f"CV CSV not found: {cv_csv}. Run compute_pca first."}

    with open(cv_csv) as fh:
        r = csv.reader(fh)
        header = next(r)
        arr = np.array([[float(x) for x in row[1:]] for row in r])
    available_cols = header[1:]
    if cv_columns is None:
        cv_columns = available_cols[:2]  # default PC1, PC2
    cols = [available_cols.index(c) for c in cv_columns]
    data = arr[:, cols]
    ndim = data.shape[1]
    if ndim not in (2, 3):
        return {"status": "error", "error": f"FEL needs 2 or 3 CVs, got {ndim}"}

    # kT in kcal/mol at user T
    kT = 1.987e-3 * float(temperature)

    if method == "histogram":
        if ndim == 2:
            H, xedges, yedges = np.histogram2d(
                data[:, 0], data[:, 1], bins=int(bins),
            )
            P = H / H.sum()
            with np.errstate(divide="ignore"):
                F = -kT * np.log(P, where=(P > 0))
                F[P <= 0] = np.nan
            F -= np.nanmin(F)
            grid_x = (xedges[:-1] + xedges[1:]) / 2
            grid_y = (yedges[:-1] + yedges[1:]) / 2
            np.savez(out / f"{output_basename}_grid.npz",
                     F=F, x=grid_x, y=grid_y, cv_names=np.array(cv_columns))
        else:
            H, edges = np.histogramdd(data, bins=int(bins))
            P = H / H.sum()
            with np.errstate(divide="ignore"):
                F = -kT * np.log(P, where=(P > 0))
                F[P <= 0] = np.nan
            F -= np.nanmin(F)
            grids = [(e[:-1] + e[1:]) / 2 for e in edges]
            np.savez(out / f"{output_basename}_grid.npz",
                     F=F, x=grids[0], y=grids[1], z=grids[2],
                     cv_names=np.array(cv_columns))
    elif method == "kde":
        from scipy.stats import gaussian_kde
        kde = gaussian_kde(data.T)
        if ndim == 2:
            grid_x = np.linspace(data[:, 0].min(), data[:, 0].max(), int(bins))
            grid_y = np.linspace(data[:, 1].min(), data[:, 1].max(), int(bins))
            X, Y = np.meshgrid(grid_x, grid_y, indexing="ij")
            P = kde(np.vstack([X.ravel(), Y.ravel()])).reshape(X.shape)
            P = P / P.sum()
            with np.errstate(divide="ignore"):
                F = -kT * np.log(P, where=(P > 0))
                F[P <= 0] = np.nan
            F -= np.nanmin(F)
            np.savez(out / f"{output_basename}_grid.npz",
                     F=F, x=grid_x, y=grid_y, cv_names=np.array(cv_columns))
        else:
            grid_x = np.linspace(data[:, 0].min(), data[:, 0].max(), int(bins))
            grid_y = np.linspace(data[:, 1].min(), data[:, 1].max(), int(bins))
            grid_z = np.linspace(data[:, 2].min(), data[:, 2].max(), int(bins))
            X, Y, Z = np.meshgrid(grid_x, grid_y, grid_z, indexing="ij")
            P = kde(np.vstack([X.ravel(), Y.ravel(), Z.ravel()])).reshape(X.shape)
            P = P / P.sum()
            with np.errstate(divide="ignore"):
                F = -kT * np.log(P, where=(P > 0))
                F[P <= 0] = np.nan
            F -= np.nanmin(F)
            np.savez(out / f"{output_basename}_grid.npz",
                     F=F, x=grid_x, y=grid_y, z=grid_z,
                     cv_names=np.array(cv_columns))
    else:
        return {"status": "error", "error": f"unknown method {method!r}"}

    # Plot 2D (always make a 2D contour, even from 3D — slice through min energy)
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    if ndim == 2:
        fig, ax = plt.subplots(figsize=(7, 6))
        cs = ax.contourf(grid_x, grid_y, F.T, 20, cmap="viridis")
        plt.colorbar(cs, ax=ax, label="ΔF (kcal/mol)")
        ax.set_xlabel(cv_columns[0])
        ax.set_ylabel(cv_columns[1])
        ax.set_title(f"FEL ({method}, T={temperature} K)")
        fig.tight_layout()
        png_2d = out / f"{output_basename}_2d.png"
        fig.savefig(png_2d, dpi=120)
        plt.close(fig)
        html_3d = None
    else:
        # Marginalize z to make a 2D contour PNG too
        F2 = np.nanmin(F, axis=2)
        F2 -= np.nanmin(F2)
        fig, ax = plt.subplots(figsize=(7, 6))
        cs = ax.contourf(grid_x, grid_y, F2.T, 20, cmap="viridis")
        plt.colorbar(cs, ax=ax, label="min over PC3 ΔF (kcal/mol)")
        ax.set_xlabel(cv_columns[0])
        ax.set_ylabel(cv_columns[1])
        ax.set_title(f"3D FEL projected ({method}, T={temperature} K)")
        fig.tight_layout()
        png_2d = out / f"{output_basename}_3d_proj.png"
        fig.savefig(png_2d, dpi=120)
        plt.close(fig)
        # Plotly interactive 3D isosurface
        html_3d = _fel_3d_html(F, grid_x, grid_y, grid_z, cv_columns,
                              out / f"{output_basename}_3d.html")

    return {
        "status": "ok",
        "method": method,
        "ndim": int(ndim),
        "cv_columns": list(cv_columns),
        "n_frames": int(arr.shape[0]),
        "bins": int(bins),
        "temperature": float(temperature),
        "min_dF_kcal_per_mol": 0.0,
        "max_dF_kcal_per_mol": float(np.nanmax(F)),
        "grid_npz": str(out / f"{output_basename}_grid.npz"),
        "png_2d": str(png_2d),
        "html_3d": str(html_3d) if html_3d else None,
    }


def _fel_3d_html(F, x, y, z, cv_names, html_path: Path) -> str:
    import plotly.graph_objects as go

    # Interactive isosurface at three contour levels (1, 2, 3 kcal/mol above min)
    Fnan_to_max = np.where(np.isnan(F), np.nanmax(F), F)
    X, Y, Z = np.meshgrid(x, y, z, indexing="ij")
    fig = go.Figure(data=go.Isosurface(
        x=X.flatten(), y=Y.flatten(), z=Z.flatten(),
        value=Fnan_to_max.flatten(),
        isomin=float(np.nanmin(F) + 0.5),
        isomax=float(np.nanmin(F) + 4.0),
        surface_count=4,
        colorscale="Viridis",
        opacity=0.6,
        colorbar=dict(title="ΔF (kcal/mol)"),
    ))
    fig.update_layout(
        title="3D Free-energy landscape",
        scene=dict(xaxis_title=cv_names[0],
                   yaxis_title=cv_names[1],
                   zaxis_title=cv_names[2]),
        height=720, width=900,
    )
    fig.write_html(str(html_path), include_plotlyjs="cdn", full_html=True)
    return str(html_path)


# --- Kernel density estimation ---------------------------------------------

def kernel_density_estimation(
    run_dir: str,
    *,
    cv_csv: Optional[str] = None,
    cv_columns: Optional[List[str]] = None,
    bins: int = 100,
    output_basename: str = "kde",
) -> Dict[str, Any]:
    """1D or 2D KDE on collective variables. Writes a PDF estimate (not energy)
    so this is the "P" before the -kT*log step. Useful for visualizing
    populations directly."""
    from scipy.stats import gaussian_kde
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    out = _ensure_outdir(run_dir)
    if cv_csv is None:
        cv_csv = str(out / "pca_projections.csv")
    if not os.path.isfile(cv_csv):
        return {"status": "error", "error": f"CV CSV not found: {cv_csv}"}

    with open(cv_csv) as fh:
        r = csv.reader(fh)
        header = next(r)
        arr = np.array([[float(x) for x in row[1:]] for row in r])
    available = header[1:]
    if cv_columns is None:
        cv_columns = available[:2]
    cols = [available.index(c) for c in cv_columns]
    data = arr[:, cols]
    ndim = data.shape[1]
    if ndim not in (1, 2):
        return {"status": "error", "error": "KDE supports 1 or 2 dims here"}

    kde = gaussian_kde(data.T) if ndim > 1 else gaussian_kde(data[:, 0])

    if ndim == 1:
        grid = np.linspace(data[:, 0].min(), data[:, 0].max(), int(bins))
        P = kde(grid)
        fig, ax = plt.subplots(figsize=(7, 4))
        ax.plot(grid, P, lw=1.5)
        ax.fill_between(grid, P, alpha=0.3)
        ax.set_xlabel(cv_columns[0])
        ax.set_ylabel("density")
        ax.set_title("Kernel density estimate")
        fig.tight_layout()
        png = out / f"{output_basename}_1d.png"
        fig.savefig(png, dpi=120)
        plt.close(fig)
        np.savez(out / f"{output_basename}_grid.npz", grid=grid, P=P,
                 cv_names=np.array(cv_columns))
    else:
        gx = np.linspace(data[:, 0].min(), data[:, 0].max(), int(bins))
        gy = np.linspace(data[:, 1].min(), data[:, 1].max(), int(bins))
        X, Y = np.meshgrid(gx, gy, indexing="ij")
        P = kde(np.vstack([X.ravel(), Y.ravel()])).reshape(X.shape)
        fig, ax = plt.subplots(figsize=(7, 6))
        cs = ax.contourf(gx, gy, P.T, 25, cmap="magma")
        plt.colorbar(cs, ax=ax, label="density")
        ax.set_xlabel(cv_columns[0])
        ax.set_ylabel(cv_columns[1])
        ax.set_title("Kernel density estimate")
        fig.tight_layout()
        png = out / f"{output_basename}_2d.png"
        fig.savefig(png, dpi=120)
        plt.close(fig)
        np.savez(out / f"{output_basename}_grid.npz", x=gx, y=gy, P=P,
                 cv_names=np.array(cv_columns))

    return {
        "status": "ok",
        "ndim": int(ndim),
        "cv_columns": list(cv_columns),
        "bins": int(bins),
        "n_frames": int(arr.shape[0]),
        "png": str(png),
        "grid_npz": str(out / f"{output_basename}_grid.npz"),
    }
