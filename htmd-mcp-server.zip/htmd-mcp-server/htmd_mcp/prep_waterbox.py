"""Build a soluble protein in a water box for MD."""

from __future__ import annotations

import logging
import os
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


def build_protein_waterbox(
    input_pdb: str,
    *,
    forcefield: str = "charmm",
    water_model: str = "tip3p",
    pad: float = 12.0,
    saltconc: float = 0.15,
    cation: str = "SOD",
    anion: str = "CLA",
    pH: float = 7.4,
    disulfide: Optional[List[List[str]]] = None,
    keep_selection: Optional[str] = None,
    remove_selection: Optional[str] = None,
    outdir: str = "build_waterbox",
) -> Dict[str, Any]:
    """Prepare → segment → solvate → CHARMM build a soluble protein.

    Parameters
    ----------
    input_pdb
        Local PDB path or 4-letter PDB ID (HTMD will fetch).
    forcefield
        ``"charmm"`` (default) or ``"amber"``.
    water_model
        Currently informational; both engines write TIP3P-compatible water.
    pad
        Padding (Å) added in every direction during solvation.
    saltconc
        NaCl concentration in M, after neutralization.
    cation, anion
        CHARMM-style ion names. For amber pass ``"NA"`` / ``"CL"``.
    disulfide
        Optional list of pairs of atomselection strings; otherwise auto-detect.
    keep_selection / remove_selection
        Optional cleanup before preparation.
    """
    if forcefield not in ("charmm", "amber"):
        raise ValueError(f"unknown forcefield {forcefield!r}")

    from moleculekit.molecule import Molecule
    from moleculekit.tools.preparation import systemPrepare
    from moleculekit.tools.autosegment import autoSegment
    from htmd.builder.solvate import solvate

    outdir = os.path.abspath(outdir)
    os.makedirs(outdir, exist_ok=True)

    mol = Molecule(input_pdb)
    if keep_selection:
        mol.filter(keep_selection)
    if remove_selection:
        mol.remove(remove_selection)

    # Strip everything but protein + crystal waters by default if user didn't
    # pre-clean. Most builders cannot handle ligands without parameters.
    if not (keep_selection or remove_selection):
        mol.filter("protein or water or ions")

    prepared = systemPrepare(mol, pH=pH)
    prepared = autoSegment(prepared, sel="protein")
    prepared.set("segid", "W", sel="water")
    prepared.set("segid", "I", sel="ions")
    prepared.center()

    # Solvate
    solv = solvate(prepared, pad=float(pad))

    if forcefield == "charmm":
        from htmd.builder import charmm

        built = charmm.build(
            solv,
            outdir=outdir,
            saltconc=float(saltconc),
            saltcation=cation,
            saltanion=anion,
            disulfide=disulfide,
        )
        files = {
            "pdb": os.path.join(outdir, "structure.pdb"),
            "psf": os.path.join(outdir, "structure.psf"),
        }
    else:
        from htmd.builder import amber

        built = amber.build(
            solv,
            outdir=outdir,
            saltconc=float(saltconc),
            saltcation=cation if cation != "SOD" else "NA",
            saltanion=anion if anion != "CLA" else "CL",
            disulfide=disulfide,
        )
        files = {
            "pdb": os.path.join(outdir, "structure.pdb"),
            "prmtop": os.path.join(outdir, "structure.prmtop"),
        }

    return {
        "status": "ok",
        "outdir": outdir,
        "forcefield": forcefield,
        "n_atoms": int(built.numAtoms),
        "n_residues": int(len(set(zip(built.resid, built.segid)))),
        "files": files,
        "salt_concentration": float(saltconc),
    }
