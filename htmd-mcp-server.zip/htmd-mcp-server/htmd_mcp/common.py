"""Shared preparation utilities: fetch, inspect, prepare, segment, clean."""

from __future__ import annotations

import os
from typing import Any, Dict, List, Optional


def fetch_pdb(pdb_id_or_path: str, outdir: str = "fetched") -> Dict[str, Any]:
    """Return a local path to a PDB. Accepts an existing path or a 4-letter ID
    (Molecule constructor will fetch from RCSB)."""
    from moleculekit.molecule import Molecule

    outdir = os.path.abspath(outdir)
    os.makedirs(outdir, exist_ok=True)

    if os.path.isfile(pdb_id_or_path):
        local = os.path.abspath(pdb_id_or_path)
    else:
        mol = Molecule(pdb_id_or_path)
        local = os.path.join(outdir, f"{pdb_id_or_path}.pdb")
        mol.write(local)

    mol = Molecule(local)
    return {
        "status": "ok",
        "path": local,
        "n_atoms": int(mol.numAtoms),
        "chains": sorted(set(mol.chain.tolist())),
    }


def inspect_structure(path: str) -> Dict[str, Any]:
    """High-level audit: chains, residues, ligands, gaps, segids, water, ions."""
    from moleculekit.molecule import Molecule
    import numpy as np

    mol = Molecule(path)

    chains = sorted(set(mol.chain.tolist()))
    segids = sorted(set(mol.segid.tolist()))
    n_water = int(np.sum(mol.atomselect("water and name OH2")) +
                  np.sum(mol.atomselect("water and name O")))
    n_ions = int(np.sum(mol.atomselect("ions")))

    # ligands = anything not protein/nuc/water/ion
    lig_mask = mol.atomselect(
        "not protein and not nucleic and not water and not ions and not lipid"
    )
    lig_resnames = sorted(set(mol.resname[lig_mask].tolist()))

    # gaps = consecutive resids in the same chain that differ by >1
    gaps = []
    for ch in chains:
        sel = (mol.chain == ch) & mol.atomselect("protein and name CA")
        resids = mol.resid[sel]
        for i in range(1, len(resids)):
            if resids[i] - resids[i - 1] > 1:
                gaps.append({"chain": ch, "from": int(resids[i - 1]),
                             "to": int(resids[i])})

    return {
        "status": "ok",
        "path": os.path.abspath(path),
        "n_atoms": int(mol.numAtoms),
        "chains": chains,
        "segids": segids,
        "n_protein_residues": int(np.sum(mol.atomselect("protein and name CA"))),
        "n_water_molecules": n_water,
        "n_ions": n_ions,
        "ligand_resnames": lig_resnames,
        "chain_gaps": gaps[:50],
    }


def prepare_protein(
    path: str,
    *,
    pH: float = 7.4,
    hydrophobic_thickness: Optional[float] = None,
    outdir: str = "prepared",
    out_name: str = "prepared.pdb",
) -> Dict[str, Any]:
    """Wrap moleculekit.systemPrepare. Writes prepared PDB and returns the pKa
    table summary."""
    from moleculekit.molecule import Molecule
    from moleculekit.tools.preparation import systemPrepare

    outdir = os.path.abspath(outdir)
    os.makedirs(outdir, exist_ok=True)
    out_path = os.path.join(outdir, out_name)

    mol = Molecule(path)
    prepared, details = systemPrepare(
        mol,
        pH=float(pH),
        hydrophobic_thickness=hydrophobic_thickness,
        return_details=True,
    )
    prepared.write(out_path)

    # Surface a compact summary of the details DataFrame
    try:
        import pandas as pd  # noqa: F401
        modified = details.data
        modified = modified[modified.get("forced_protonation") |
                            modified.get("changed", False)]
        summary = modified[["resname", "resid", "chain", "protonation"]].to_dict(
            orient="records"
        ) if len(modified) else []
    except Exception:
        summary = []

    return {
        "status": "ok",
        "input": os.path.abspath(path),
        "output": out_path,
        "pH": float(pH),
        "modified_residues": summary[:200],
    }


def auto_segment(
    path: str,
    *,
    sel: str = "protein",
    outdir: str = "segmented",
    out_name: str = "segmented.pdb",
) -> Dict[str, Any]:
    from moleculekit.molecule import Molecule
    from moleculekit.tools.autosegment import autoSegment

    outdir = os.path.abspath(outdir)
    os.makedirs(outdir, exist_ok=True)
    out_path = os.path.join(outdir, out_name)

    mol = Molecule(path)
    mol = autoSegment(mol, sel=sel)
    mol.write(out_path)

    return {
        "status": "ok",
        "input": os.path.abspath(path),
        "output": out_path,
        "segids": sorted(set(mol.segid.tolist())),
    }


def clean_structure(
    path: str,
    *,
    keep_selection: Optional[str] = None,
    remove_selection: Optional[str] = None,
    outdir: str = "cleaned",
    out_name: str = "cleaned.pdb",
) -> Dict[str, Any]:
    from moleculekit.molecule import Molecule

    outdir = os.path.abspath(outdir)
    os.makedirs(outdir, exist_ok=True)
    out_path = os.path.join(outdir, out_name)

    mol = Molecule(path)
    n_before = mol.numAtoms
    if keep_selection:
        mol.filter(keep_selection)
    if remove_selection:
        mol.remove(remove_selection)
    mol.write(out_path)

    return {
        "status": "ok",
        "input": os.path.abspath(path),
        "output": out_path,
        "atoms_before": int(n_before),
        "atoms_after": int(mol.numAtoms),
    }
