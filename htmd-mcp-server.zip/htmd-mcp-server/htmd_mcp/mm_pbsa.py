"""Single-trajectory MM-GBSA via NAMD3 with the GBIS implicit solvent.

Approach: from the explicit-solvent production trajectory, take ``n_frames``
evenly-spaced frames; for each, write three coordinate files
(complex / receptor / ligand) plus three PSFs (split via parmed) and run
NAMD3 with ``GBIS on`` for a single-step "energy probe". Sum the gas-phase
MM and GB-implicit-solvent contributions and add a SASA-based nonpolar term::

    ΔG_bind ≈ ⟨E_MM_complex + G_GB_complex + G_np_complex
              − E_MM_recep   − G_GB_recep   − G_np_recep
              − E_MM_lig     − G_GB_lig     − G_np_lig⟩_frames

The "PB" in the user's request is implemented via the GB approximation,
which is the standard fallback when APBS isn't available — significantly
cheaper and well-correlated with full Poisson–Boltzmann for typical
biomolecular systems. (Hou et al., 2011, JCIM.)
"""

from __future__ import annotations

import csv
import json
import logging
import os
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from htmd_mcp.postprocess import _ensure_outdir, _load_traj
from htmd_mcp.namd3_runner import NAMD3_BIN_DEFAULT, parse_namd_log

logger = logging.getLogger(__name__)


# --- NAMD3 GBIS single-point template -------------------------------------

_GBIS_TEMPLATE = """\
# NAMD3 single-point MM-GBSA energy
structure       {psf}
coordinates     {pdb}
paraTypeCharmm  on
{params_block}
exclude         scaled1-4
oneFourScaling  1.0

# Generalized Born Implicit Solvent
GBIS                 on
solventDielectric    {solvent_dielectric}
intrinsicRadiusOffset 0.09
ionConcentration     {ion_concentration}
alphaCutoff          14.0
GBISDelta            0.8
GBISBeta             0.0
GBISGamma            2.90912
sasa                 on
surfaceTension       {surface_tension}

# Non-periodic / no PME
cutoff               999.0
switching            off
pairlistdist         1000.0

temperature          0
COMmotion            no
seed                 12345

# Output
outputName           ene
outputEnergies       1
binaryOutput         no
binaryRestart        no
restartFreq          1
DCDfreq              100000

# Single energy evaluation
numsteps             1
"""


def _stage_params(run_dir: str, dst: Path) -> List[str]:
    """Copy CHARMM parameter files from the production run dir into dst.
    If run_dir has parameters/, use those; else stage a default set."""
    src_par = Path(run_dir) / "parameters"
    dst_par = dst / "parameters"
    dst_par.mkdir(parents=True, exist_ok=True)

    if src_par.is_dir():
        for f in src_par.glob("*.prm"):
            shutil.copy(f, dst_par / f.name)
        for f in src_par.glob("*.str"):
            shutil.copy(f, dst_par / f.name)
    else:
        from htmd_mcp.namd3_writer import stage_charmm_parameters
        stage_charmm_parameters(str(run_dir), str(dst))

    return sorted([f"parameters/{f.name}" for f in dst_par.iterdir()])


def _split_psfs(
    psf_path: str,
    ligand_resname: str,
    out_dir: Path,
    *,
    complex_indices: List[int],
    receptor_indices: List[int],
    ligand_indices: List[int],
) -> Dict[str, Path]:
    """Split a CHARMM PSF into complex/receptor/ligand PSFs by 0-based atom
    index. Indices come from moleculekit's atomselect on the same Molecule
    used to write the PDBs, so PSF and PDB atom counts match exactly."""
    import parmed as pmd
    import copy

    def _strip_to(indices: List[int], dst: Path) -> Path:
        sub = copy.copy(base)
        keep = set(int(i) for i in indices)
        # parmed strip_atoms: drop atoms with index NOT in keep
        to_drop = sorted([i for i in range(len(sub.atoms)) if i not in keep],
                         reverse=True)
        # parmed Structure has __delitem__ via [ '@1,2,3' ] or by atom mask.
        # Easiest: use AmberMask "@<i+1>,<j+1>,..." which is 1-indexed.
        if to_drop:
            # AmberMask supports up to ~thousands of atoms in one expression;
            # if too long, chunk it.
            chunks = []
            cur = []
            cur_len = 0
            for i in to_drop:
                tok = str(i + 1)
                if cur_len + len(tok) + 1 > 8000:
                    chunks.append(cur)
                    cur = []
                    cur_len = 0
                cur.append(tok)
                cur_len += len(tok) + 1
            if cur:
                chunks.append(cur)
            for chunk in chunks:
                mask = "@" + ",".join(chunk)
                sub.strip(mask)
        sub.write_psf(str(dst))
        _fix_psf_title(dst)
        return dst

    base = pmd.charmm.CharmmPsfFile(psf_path)
    complex_path = _strip_to(complex_indices, out_dir / "complex.psf")
    receptor_path = _strip_to(receptor_indices, out_dir / "receptor.psf")
    ligand_path = _strip_to(ligand_indices, out_dir / "ligand.psf")
    return {
        "complex": complex_path,
        "receptor": receptor_path,
        "ligand": ligand_path,
    }


def _fix_psf_title(psf_path: Path) -> None:
    """parmed writes ``1 !NTITLE`` followed by zero TITLE lines. NAMD3 then
    fails to find ``NATOM`` because the title-count is a lie. Rewrite the
    NTITLE field to match the actual count (0)."""
    text = psf_path.read_text()
    fixed = text.replace("         1 !NTITLE\n\n\n",
                         "         0 !NTITLE\n\n", 1)
    if fixed == text:
        # Try alternative spacing
        import re
        fixed = re.sub(r"^\s*1\s*!NTITLE\s*$\n\s*\n\s*\n",
                       "         0 !NTITLE\n\n", text, count=1, flags=re.MULTILINE)
    psf_path.write_text(fixed)


def _write_subsystem_pdb(mol, sel: str, out_path: Path) -> None:
    """Write a stripped PDB containing only atoms matching ``sel``."""
    sub = mol.copy()
    sub.filter(sel)
    sub.write(str(out_path))


def _run_singlepoint(
    work: Path,
    psf_basename: str,
    pdb_basename: str,
    params_rel: List[str],
    *,
    namd3_bin: str,
    solvent_dielectric: float,
    ion_concentration: float,
    surface_tension: float,
    timeout_s: int = 120,
) -> Dict[str, Any]:
    params_block = "\n".join(f"parameters      {p}" for p in params_rel)
    namd_input = work / f"{psf_basename}.namd"
    namd_input.write_text(_GBIS_TEMPLATE.format(
        psf=f"{psf_basename}.psf",
        pdb=pdb_basename,
        params_block=params_block,
        solvent_dielectric=solvent_dielectric,
        ion_concentration=ion_concentration,
        surface_tension=surface_tension,
    ))
    log = work / f"{psf_basename}.log"
    res = subprocess.run(
        [namd3_bin, "+p", "1", namd_input.name],
        cwd=str(work), capture_output=True, text=True, timeout=timeout_s,
    )
    log.write_text(res.stdout + "\n--- STDERR ---\n" + res.stderr)
    if res.returncode != 0:
        return {"status": "error",
                "stderr_tail": res.stderr[-1500:],
                "stdout_tail": res.stdout[-1500:]}
    info = parse_namd_log(str(log))
    if info.get("last_energy") is None:
        return {"status": "error", "error": "no ENERGY parsed", "log": str(log)}
    return {"status": "ok", "energy": info["last_energy"], "log": str(log)}


# --- Public API ------------------------------------------------------------

def mm_pbsa(
    run_dir: str,
    ligand_resname: str,
    *,
    n_frames: int = 25,
    salt_concentration: float = 0.15,
    solvent_dielectric: float = 78.5,
    surface_tension: float = 0.00542,
    surface_offset: float = 0.92,
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
    namd3_bin: Optional[str] = None,
    output_basename: str = "mmpbsa",
) -> Dict[str, Any]:
    """Single-trajectory MM-GBSA estimate of the ligand binding free energy.

    Returns mean and standard deviation of ΔG_bind across the analyzed frames,
    plus the per-frame breakdown (BOND / ANGLE / DIHED / IMPRP / VDW / ELECT /
    BOUNDARY / MISC) and the nonpolar SASA contribution.

    The trajectory must contain a built CHARMM system with a ``ligand_resname``
    visible — typically the output of ``build_protein_ligand`` followed by
    ``run_namd3`` production.
    """
    namd3 = namd3_bin or NAMD3_BIN_DEFAULT
    if not (os.path.isfile(namd3) and os.access(namd3, os.X_OK)):
        return {"status": "error", "error": f"namd3 not executable at {namd3}"}

    out = _ensure_outdir(run_dir) / output_basename
    out.mkdir(parents=True, exist_ok=True)

    mol, psf_path, pdb_path, dcd_path = _load_traj(
        run_dir, psf=psf, pdb=pdb, dcd=dcd,
    )
    n_total = mol.numFrames
    if n_total == 0:
        return {"status": "error", "error": "trajectory has no frames"}
    n_frames = min(int(n_frames), n_total)
    frame_indices = np.linspace(0, n_total - 1, n_frames, dtype=int)

    # Sanity-check ligand presence
    if not mol.atomselect(f"resname {ligand_resname.upper()}").any():
        return {"status": "error",
                "error": f"resname {ligand_resname!r} not found in {psf_path}"}

    # Stage parameters once
    params_rel = _stage_params(run_dir, out)

    # Define subsystem selections (moleculekit syntax). Use the SAME selection
    # to (a) determine atom indices for the PSF strip and (b) extract the
    # subsystem PDB at each frame, so PSF and PDB atom counts always match.
    complex_sel = (
        f"protein or resname {ligand_resname.upper()} or "
        "(not water and not ions and not lipid and not nucleic)"
    )
    receptor_sel = (
        f"(protein or (not water and not ions and not lipid and not nucleic)) "
        f"and not resname {ligand_resname.upper()}"
    )
    ligand_sel = f"resname {ligand_resname.upper()}"

    complex_idx = list(np.where(mol.atomselect(complex_sel))[0])
    receptor_idx = list(np.where(mol.atomselect(receptor_sel))[0])
    ligand_idx = list(np.where(mol.atomselect(ligand_sel))[0])
    if not complex_idx or not receptor_idx or not ligand_idx:
        return {"status": "error",
                "error": f"empty subsystem (complex={len(complex_idx)}, "
                         f"receptor={len(receptor_idx)}, ligand={len(ligand_idx)})"}

    psf_paths = _split_psfs(
        psf_path, ligand_resname, out,
        complex_indices=complex_idx,
        receptor_indices=receptor_idx,
        ligand_indices=ligand_idx,
    )

    # Per-frame energies
    breakdown: List[Dict[str, Any]] = []
    failed_frames: List[int] = []

    for i, fidx in enumerate(frame_indices):
        # Save sub-system PDBs at this frame
        single = mol.copy()
        single.dropFrames(keep=int(fidx))
        frame_dir = out / f"frame_{i:04d}"
        frame_dir.mkdir(exist_ok=True)

        # Stage params symlink-style: just put a relative dir
        if not (frame_dir / "parameters").exists():
            os.symlink("../parameters", frame_dir / "parameters")
        for psf_kind in ("complex", "receptor", "ligand"):
            shutil.copy(psf_paths[psf_kind], frame_dir / f"{psf_kind}.psf")

        # Use the SAME selections that were used to split the PSF, so PDB
        # atom counts match exactly.
        _write_subsystem_pdb(single, complex_sel, frame_dir / "complex.pdb")
        _write_subsystem_pdb(single, receptor_sel, frame_dir / "receptor.pdb")
        _write_subsystem_pdb(single, ligand_sel, frame_dir / "ligand.pdb")

        try:
            ec = _run_singlepoint(
                frame_dir, "complex", "complex.pdb", params_rel,
                namd3_bin=namd3,
                solvent_dielectric=solvent_dielectric,
                ion_concentration=salt_concentration,
                surface_tension=surface_tension,
            )
            er = _run_singlepoint(
                frame_dir, "receptor", "receptor.pdb", params_rel,
                namd3_bin=namd3,
                solvent_dielectric=solvent_dielectric,
                ion_concentration=salt_concentration,
                surface_tension=surface_tension,
            )
            el = _run_singlepoint(
                frame_dir, "ligand", "ligand.pdb", params_rel,
                namd3_bin=namd3,
                solvent_dielectric=solvent_dielectric,
                ion_concentration=salt_concentration,
                surface_tension=surface_tension,
            )
        except subprocess.TimeoutExpired:
            failed_frames.append(int(fidx))
            continue

        for label, res in (("complex", ec), ("receptor", er), ("ligand", el)):
            if res.get("status") != "ok":
                failed_frames.append(int(fidx))
                logger.warning("MM-PBSA frame %d %s: %s", fidx, label,
                              res.get("error") or res.get("stderr_tail", "")[:200])
                break
        else:
            breakdown.append({
                "frame": int(fidx),
                "complex": ec["energy"],
                "receptor": er["energy"],
                "ligand": el["energy"],
            })

    if not breakdown:
        return {
            "status": "error",
            "error": "no frames produced valid energies",
            "failed_frames": failed_frames,
            "out_dir": str(out),
        }

    # Per-frame ΔG_bind for each energy term
    terms = ("BOND", "ANGLE", "DIHED", "IMPRP", "ELECT", "VDW", "MISC")
    deltas: Dict[str, List[float]] = {t: [] for t in terms}
    deltas["TOTAL"] = []
    for row in breakdown:
        c = row["complex"]; r = row["receptor"]; l = row["ligand"]
        for t in terms:
            deltas[t].append(c.get(t, 0.0) - r.get(t, 0.0) - l.get(t, 0.0))
        # Use POTENTIAL or TOTAL as sum reference
        c_tot = c.get("POTENTIAL", c.get("TOTAL", 0.0))
        r_tot = r.get("POTENTIAL", r.get("TOTAL", 0.0))
        l_tot = l.get("POTENTIAL", l.get("TOTAL", 0.0))
        deltas["TOTAL"].append(c_tot - r_tot - l_tot)

    summary = {
        f"dG_{t}_kcal_per_mol": {
            "mean": float(np.mean(deltas[t])) if deltas[t] else 0.0,
            "std": float(np.std(deltas[t])) if deltas[t] else 0.0,
            "sem": float(np.std(deltas[t]) / np.sqrt(len(deltas[t])))
                   if deltas[t] else 0.0,
        }
        for t in (*terms, "TOTAL")
    }

    # Per-frame breakdown CSV
    csv_path = out / "mmpbsa_per_frame.csv"
    with open(csv_path, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["frame"] + [f"d{t}" for t in (*terms, "TOTAL")])
        for i, row in enumerate(breakdown):
            r = [row["frame"]] + [deltas[t][i] for t in (*terms, "TOTAL")]
            w.writerow(r)

    summary_path = out / "mmpbsa_summary.json"
    summary_path.write_text(json.dumps({
        "n_frames_analyzed": len(breakdown),
        "n_frames_failed": len(failed_frames),
        "failed_frames": failed_frames,
        "ligand_resname": ligand_resname.upper(),
        "salt_concentration_M": salt_concentration,
        "solvent_dielectric": solvent_dielectric,
        "surface_tension_kcal_per_mol_A2": surface_tension,
        "surface_offset_kcal_per_mol": surface_offset,
        "deltas": summary,
    }, indent=2))

    # Plots: per-frame ΔG_TOTAL timeseries + per-term mean breakdown bar.
    plot_png: Optional[str] = None
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        all_terms = (*terms, "TOTAL")
        means = [float(np.mean(deltas[t])) if deltas[t] else 0.0
                 for t in all_terms]
        sems = [float(np.std(deltas[t]) / np.sqrt(len(deltas[t])))
                if deltas[t] else 0.0 for t in all_terms]
        total_series = np.array(deltas["TOTAL"], dtype=float)
        frames = np.array([row["frame"] for row in breakdown])

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4.5))
        ax1.plot(frames, total_series, "o-", lw=1.2, color="#1f77b4")
        if total_series.size:
            m = float(np.mean(total_series))
            ax1.axhline(m, color="#d62728", ls="--", lw=0.8,
                        label=f"mean={m:.2f} kcal/mol")
            ax1.legend(fontsize=8)
        ax1.set_xlabel("frame")
        ax1.set_ylabel("ΔG_TOTAL (kcal/mol)")
        ax1.set_title(f"MM-GBSA ΔG_bind per frame ({ligand_resname.upper()})")
        ax1.grid(alpha=0.3)

        xs = np.arange(len(all_terms))
        colors = ["#777"] * len(terms) + ["#d62728"]
        ax2.bar(xs, means, yerr=sems, color=colors, capsize=3)
        ax2.set_xticks(xs)
        ax2.set_xticklabels(all_terms, rotation=45, ha="right", fontsize=8)
        ax2.set_ylabel("⟨Δterm⟩ (kcal/mol)")
        ax2.set_title("Per-term mean contribution")
        ax2.axhline(0.0, color="k", lw=0.5)
        ax2.grid(axis="y", alpha=0.3)

        fig.tight_layout()
        png_path = out / "mmpbsa_breakdown.png"
        fig.savefig(str(png_path), dpi=120)
        plt.close(fig)
        plot_png = str(png_path)
    except Exception as exc:  # never let plotting break the analysis itself
        logger.warning("MM-PBSA plot failed: %s", exc)

    return {
        "status": "ok",
        "n_frames_analyzed": len(breakdown),
        "n_frames_failed": len(failed_frames),
        "ligand_resname": ligand_resname.upper(),
        "summary": summary,
        "per_frame_csv": str(csv_path),
        "summary_json": str(summary_path),
        "plot_png": plot_png,
        "out_dir": str(out),
    }
