"""Advanced trajectory analyses: hydrogen bonds, secondary structure.

Built on top of mdtraj. Each tool writes CSVs (and an interactive HTML
visualization where it adds value) into ``run_dir/analysis/``.
"""

from __future__ import annotations

import csv
import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from htmd_mcp.postprocess import _load_traj, _ensure_outdir, _summary, _write_csv

logger = logging.getLogger(__name__)


# --- Internal: moleculekit Molecule -> mdtraj Trajectory --------------------

def _mol_to_mdtraj(mol):
    """Convert a moleculekit Molecule (with frames) into an mdtraj Trajectory.
    We dump topology to a temporary PDB and feed coordinates via numpy.
    """
    import mdtraj as md
    import tempfile

    with tempfile.NamedTemporaryFile(suffix=".pdb", delete=False) as tmp:
        ref = mol.copy()
        ref.dropFrames(keep=0)
        ref.write(tmp.name)
        topo_pdb = tmp.name
    top = md.load(topo_pdb).topology
    # mdtraj wants coords in nm shape (frames, atoms, 3)
    coords_nm = np.swapaxes(mol.coords, 0, 2)  # (F, 3, N)
    coords_nm = np.swapaxes(coords_nm, 1, 2) / 10.0  # (F, N, 3) in nm
    traj = md.Trajectory(coords_nm.astype(np.float32), topology=top)
    if mol.box is not None and np.any(mol.box):
        # mdtraj wants nm cell lengths
        if mol.box.shape == (3, mol.numFrames):
            ang = np.full((mol.numFrames, 3), 90.0, dtype=np.float32)
            traj.unitcell_lengths = (mol.box.T / 10.0).astype(np.float32)
            traj.unitcell_angles = ang
    return traj, topo_pdb


# --- H-bond analysis --------------------------------------------------------

def analyze_hbonds(
    run_dir: str,
    *,
    method: str = "baker_hubbard",   # "baker_hubbard" | "wernet_nilsson"
    freq_threshold: float = 0.1,     # Only report pairs present in >=10% of frames
    sel: str = "protein",
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> Dict[str, Any]:
    """Per-frame H-bond detection across the trajectory.

    Returns a per-pair frequency table (donor residue → acceptor residue),
    a per-frame H-bond count timeseries, and an interactive plotly HTML
    matrix of donor × acceptor frequencies.

    method='baker_hubbard' (Baker–Hubbard 1984; uses average geometry
    criteria; faster), or 'wernet_nilsson' (Wernet–Nilsson 2004; per-frame
    but stricter). Defaults to baker_hubbard.
    """
    import mdtraj as md

    mol, *_ = _load_traj(run_dir, psf=psf, pdb=pdb, dcd=dcd)
    if sel:
        mol.filter(sel)
    traj, _topo_pdb = _mol_to_mdtraj(mol)

    out = _ensure_outdir(run_dir)

    # Per-frame H-bond list
    if method == "baker_hubbard":
        hbonds = md.baker_hubbard(traj, freq=0.0, distance_cutoff=0.35,
                                  angle_cutoff=120, periodic=False)
        # baker_hubbard returns (donor, hydrogen, acceptor) atom indices
        # aggregated across the whole trajectory; recompute per-frame for
        # timeseries.
        per_frame_hbond_indices = _per_frame_hbonds(traj)
    elif method == "wernet_nilsson":
        per_frame_hbond_indices = md.wernet_nilsson(traj, periodic=False)
        hbonds = _aggregate_unique(per_frame_hbond_indices)
    else:
        return {"status": "error", "error": f"unknown method {method!r}"}

    # Frequency table: count fraction of frames each (donor_atom, accep_atom)
    # appears
    n_frames = traj.n_frames
    pair_counts: Dict[Tuple[int, int], int] = {}
    for frame_pairs in per_frame_hbond_indices:
        seen = set()
        for triplet in frame_pairs:
            d, _h, a = int(triplet[0]), int(triplet[1]), int(triplet[2])
            key = (d, a)
            if key not in seen:
                pair_counts[key] = pair_counts.get(key, 0) + 1
                seen.add(key)

    # Aggregate per residue
    top = traj.topology
    res_pair_count: Dict[Tuple[int, int], Dict[str, Any]] = {}
    for (d, a), n in pair_counts.items():
        d_res = top.atom(d).residue
        a_res = top.atom(a).residue
        rkey = (d_res.index, a_res.index)
        prev = res_pair_count.get(rkey)
        if prev is None or n > prev["count"]:
            res_pair_count[rkey] = {
                "donor_resname": d_res.name,
                "donor_resid": d_res.resSeq,
                "donor_chain": d_res.chain.chain_id,
                "acceptor_resname": a_res.name,
                "acceptor_resid": a_res.resSeq,
                "acceptor_chain": a_res.chain.chain_id,
                "count": n,
            }

    # Per-frame H-bond count
    counts_per_frame = np.array([len(p) for p in per_frame_hbond_indices])

    # Persistent pairs above threshold
    rows = []
    for rkey, info in res_pair_count.items():
        freq = info["count"] / float(n_frames)
        if freq >= freq_threshold:
            rows.append([
                info["donor_chain"], info["donor_resid"], info["donor_resname"],
                info["acceptor_chain"], info["acceptor_resid"], info["acceptor_resname"],
                info["count"], freq,
            ])
    rows.sort(key=lambda r: -r[7])

    csv_path = out / f"hbonds_{method}.csv"
    _write_csv(csv_path,
               ["donor_chain", "donor_resid", "donor_resname",
                "acceptor_chain", "acceptor_resid", "acceptor_resname",
                "n_frames_in_contact", "frequency"], rows)

    timeseries_path = out / f"hbonds_count_{method}.csv"
    _write_csv(timeseries_path, ["frame", "n_hbonds"],
               [[i, int(c)] for i, c in enumerate(counts_per_frame)])

    # Per-frame H-bond count PNG (a static companion to the interactive heatmap).
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    timeseries_png = out / f"hbonds_count_{method}.png"
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.plot(np.arange(len(counts_per_frame)), counts_per_frame,
            lw=1.2, color="#1f77b4")
    if counts_per_frame.size:
        m = float(np.mean(counts_per_frame))
        ax.axhline(m, color="#d62728", ls="--", lw=0.8,
                   label=f"mean={m:.1f}")
        ax.legend(fontsize=8)
    ax.set_xlabel("frame")
    ax.set_ylabel("# H-bonds")
    ax.set_title(f"H-bond count vs frame ({method})")
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(str(timeseries_png), dpi=120)
    plt.close(fig)

    # Top-persistent bar chart (static companion to the heatmap so a quick
    # static PNG is available without opening the HTML).
    persistence_png = out / f"hbonds_top_{method}.png"
    if rows:
        top_rows = rows[:20]
        labels = [f"{r[0]}:{r[1]}{r[2]} → {r[3]}:{r[4]}{r[5]}"
                  for r in top_rows]
        values = [float(r[7]) for r in top_rows]
        n = len(labels)
        fig, ax = plt.subplots(figsize=(max(7.0, 0.45 * n + 2.0), 5.0))
        ax.barh(range(n), values, color="#1f77b4")
        ax.set_yticks(range(n))
        ax.set_yticklabels(labels, fontsize=8)
        ax.invert_yaxis()
        ax.set_xlabel("persistence (fraction of frames)")
        ax.set_title(f"Top H-bonds by persistence ({method})")
        ax.grid(axis="x", alpha=0.3)
        fig.tight_layout()
        fig.savefig(str(persistence_png), dpi=120)
        plt.close(fig)
    else:
        persistence_png = None

    # Interactive plotly heatmap
    html_path = _hbond_matrix_html(rows, out / f"hbonds_matrix_{method}.html")

    return {
        "status": "ok",
        "method": method,
        "selection": sel,
        "n_frames": int(n_frames),
        "n_unique_pairs": len(res_pair_count),
        "n_persistent_pairs": len(rows),
        "frequency_threshold": float(freq_threshold),
        "csv": str(csv_path),
        "timeseries_csv": str(timeseries_path),
        "timeseries_png": str(timeseries_png),
        "persistence_png": str(persistence_png) if persistence_png else None,
        "matrix_html": str(html_path),
        "summary": _summary(counts_per_frame.astype(float)),
        "top_persistent": [
            {"donor": f"{r[0]}:{r[1]}{r[2]}",
             "acceptor": f"{r[3]}:{r[4]}{r[5]}",
             "frequency": r[7]}
            for r in rows[:20]
        ],
    }


def _per_frame_hbonds(traj):
    """mdtraj.baker_hubbard but evaluated on each frame individually."""
    import mdtraj as md
    out = []
    for f in range(traj.n_frames):
        try:
            sub = traj[f]
            triplets = md.baker_hubbard(sub, freq=0.0, distance_cutoff=0.35,
                                       angle_cutoff=120, periodic=False)
            out.append(triplets)
        except Exception:
            out.append(np.zeros((0, 3), dtype=np.int32))
    return out


def _aggregate_unique(per_frame_lists):
    seen = set()
    for lst in per_frame_lists:
        for triplet in lst:
            seen.add(tuple(int(x) for x in triplet))
    return np.array(sorted(seen), dtype=np.int32) if seen else np.zeros((0, 3), dtype=np.int32)


def _hbond_matrix_html(rows: List[list], out_path: Path) -> str:
    """Plotly interactive donor × acceptor frequency heatmap."""
    import plotly.graph_objects as go

    if not rows:
        out_path.write_text("<html><body>No persistent H-bonds.</body></html>")
        return str(out_path)

    donors = sorted(set((r[0], r[1], r[2]) for r in rows),
                    key=lambda t: (t[0], t[1]))
    acceptors = sorted(set((r[3], r[4], r[5]) for r in rows),
                       key=lambda t: (t[0], t[1]))
    d_index = {d: i for i, d in enumerate(donors)}
    a_index = {a: i for i, a in enumerate(acceptors)}

    matrix = np.zeros((len(donors), len(acceptors)))
    for r in rows:
        i = d_index[(r[0], r[1], r[2])]
        j = a_index[(r[3], r[4], r[5])]
        matrix[i, j] = max(matrix[i, j], r[7])

    fig = go.Figure(data=go.Heatmap(
        z=matrix,
        x=[f"{a[0]}:{a[1]}{a[2]}" for a in acceptors],
        y=[f"{d[0]}:{d[1]}{d[2]}" for d in donors],
        colorscale="Viridis",
        colorbar=dict(title="frequency"),
        hovertemplate="donor %{y}<br>acceptor %{x}<br>freq=%{z:.2f}<extra></extra>",
    ))
    fig.update_layout(
        title="Hydrogen-bond persistence (donor × acceptor)",
        xaxis_title="acceptor residue",
        yaxis_title="donor residue",
        height=max(400, 18 * len(donors)),
        width=max(600, 18 * len(acceptors)),
    )
    fig.write_html(str(out_path), include_plotlyjs="cdn", full_html=True)
    return str(out_path)


# --- Secondary structure ----------------------------------------------------

def compute_secondary_structure(
    run_dir: str,
    *,
    simplified: bool = True,
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> Dict[str, Any]:
    """Per-residue secondary-structure assignment (DSSP) over the trajectory.

    simplified=True returns 3-letter codes (H/E/C). Output: per-frame per-residue
    CSV, per-residue fraction CSV, and a heatmap PNG (residue × time).
    """
    import mdtraj as md
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    mol, *_ = _load_traj(run_dir, psf=psf, pdb=pdb, dcd=dcd)
    mol.filter("protein")
    traj, _ = _mol_to_mdtraj(mol)
    ss = md.compute_dssp(traj, simplified=bool(simplified))  # (frames, residues)

    out = _ensure_outdir(run_dir)
    ts_csv = out / "ss_timeseries.csv"
    n_frames, n_res = ss.shape
    residues = list(traj.topology.residues)
    rows = []
    for i in range(n_frames):
        for j, res in enumerate(residues):
            rows.append([i, res.index, res.resSeq, res.name, str(ss[i, j])])
    _write_csv(ts_csv, ["frame", "residue_index", "resid", "resname", "ss_code"], rows)

    # Per-residue fractions
    codes = ["H", "E", "C"] if simplified else \
            ["H", "B", "E", "G", "I", "T", "S", " "]
    frac_rows = []
    for j, res in enumerate(residues):
        c = ss[:, j]
        rec = [res.index, res.resSeq, res.name]
        for code in codes:
            rec.append(float(np.sum(c == code)) / float(n_frames))
        frac_rows.append(rec)
    frac_csv = out / "ss_fractions.csv"
    _write_csv(frac_csv,
               ["residue_index", "resid", "resname"] + [f"f_{c.strip() or 'coil'}" for c in codes],
               frac_rows)

    # Heatmap PNG: residue × time, color = ss code
    code_map = {c: i for i, c in enumerate(codes)}
    img = np.array([[code_map.get(str(ss[t, j]), -1) for t in range(n_frames)]
                    for j in range(n_res)])
    fig, ax = plt.subplots(figsize=(min(20, max(6, n_frames / 50)),
                                    max(3, n_res / 50)))
    cmap = plt.colormaps.get_cmap("tab10")
    im = ax.imshow(img, aspect="auto", cmap=cmap, interpolation="nearest",
                   vmin=0, vmax=len(codes) - 1)
    ax.set_xlabel("frame")
    ax.set_ylabel("residue index")
    ax.set_title("Secondary structure (DSSP)")
    cbar = fig.colorbar(im, ax=ax, ticks=range(len(codes)))
    cbar.ax.set_yticklabels(codes)
    fig.tight_layout()
    png_path = out / "ss_heatmap.png"
    fig.savefig(png_path, dpi=120)
    plt.close(fig)

    # Helix / sheet fraction summary
    helix = float(np.mean(ss == "H"))
    sheet = float(np.mean(ss == "E"))
    coil = float(np.mean(ss == "C")) if simplified else float(1 - helix - sheet)

    return {
        "status": "ok",
        "n_frames": int(n_frames),
        "n_residues": int(n_res),
        "fraction_helix": helix,
        "fraction_sheet": sheet,
        "fraction_coil": coil,
        "timeseries_csv": str(ts_csv),
        "fractions_csv": str(frac_csv),
        "heatmap_png": str(png_path),
    }
