"""Build a protein + N small molecules system for MD.

Each ligand spec in the input list is one of three flavors:

* ``ligand_input``  — mol2 path (Swiss-Param-ready)
* ``ligand_rcsb_id`` — 3-letter PDB chemical-component ID (BEN, ATP, NAG, ...)
* ``ligand_smiles`` — SMILES; converted to mol2 via RDKit + OpenBabel

Each spec also carries a unique ``resname`` (so psfgen can disambiguate
topology lookups), an optional ``copies`` count for stoichiometry, and an
optional placement (``place_at`` or ``random_far``). Ligands with the same
underlying mol2 content are parametrized once via Swiss-Param's content-
addressed cache; multiple copies of the same ligand reuse the same
.rtf/.prm but get distinct segids (``L0, L1, L2, ...``).

Output is a CHARMM build dir with ``structure.psf`` / ``structure.pdb``,
all ligand RTFs included in psfgen's topo list, and an
``extra_params.json`` listing the ligand .prm files so NAMD3 staging picks
them up automatically.
"""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np

logger = logging.getLogger(__name__)


def _resolve_ligand_input(
    spec: Dict[str, Any],
    *,
    outdir: str,
    spec_index: int,
) -> Dict[str, Any]:
    """Materialize a mol2 from a spec. Returns dict with mol2 path + source."""
    from htmd_mcp.ligand_io import (
        fetch_ligand_from_rcsb,
        prepare_ligand_mol2,
    )

    if spec.get("ligand_input"):
        return {"mol2": spec["ligand_input"], "source": "ligand_input"}
    if spec.get("ligand_rcsb_id"):
        rid = spec["ligand_rcsb_id"]
        fetched = fetch_ligand_from_rcsb(
            rid,
            outdir=os.path.join(outdir, f"raw_ligand_{spec_index}"),
        )
        return {"mol2": fetched["mol2"], "source": f"rcsb:{rid}"}
    if spec.get("ligand_smiles"):
        smi = spec["ligand_smiles"]
        prepared = prepare_ligand_mol2(
            smi,
            output=os.path.join(outdir, f"raw_ligand_{spec_index}",
                                "ligand.mol2"),
            input_format="smi",
            name=spec.get("resname", f"LI{spec_index}"),
        )
        return {"mol2": prepared["mol2"], "source": f"smiles:{smi}"}

    # Pre-parametrized triple
    if spec.get("ligand_rtf") and spec.get("ligand_prm") and spec.get("ligand_pdb"):
        return {"prebuilt": True, "source": "prebuilt"}

    raise ValueError(
        f"ligand spec {spec_index} needs one of: ligand_input (mol2), "
        f"ligand_rcsb_id, ligand_smiles, or a (ligand_rtf, ligand_prm, "
        f"ligand_pdb) triple. Got keys: {list(spec.keys())}"
    )


def _place_one_ligand(
    prot,
    lig,
    *,
    place_at: Optional[List[float]],
    random_far: bool,
    rng: np.random.Generator,
    radial_offset_A: float,
) -> Dict[str, Any]:
    """Translate ``lig`` in place. ``radial_offset_A`` increments per ligand
    so multiple unbound copies don't pile up at the same point."""
    from moleculekit.util import maxDistance, uniformRandomRotation

    lig.center()
    if place_at is not None:
        lig.moveBy(np.array(place_at, dtype=float))
        return {"placement": "fixed", "xyz": list(map(float, place_at))}

    if random_far:
        # Each unbound ligand gets a unique angle around +X so they don't
        # collide. seed → uniformRandomRotation reads numpy global state.
        np.random.seed(int(rng.integers(0, 2**31 - 1)))
        lig.rotateBy(uniformRandomRotation())

        d = float(maxDistance(prot, "all")) + 10.0 + radial_offset_A
        # Spread copies around +X axis: small perpendicular jitter per copy.
        jitter_y = float(rng.uniform(-5.0, 5.0))
        jitter_z = float(rng.uniform(-5.0, 5.0))
        lig.moveBy([d, jitter_y, jitter_z])
        np.random.seed(int(rng.integers(0, 2**31 - 1)))
        lig.rotateBy(uniformRandomRotation())
        return {
            "placement": "random_far",
            "distance_A": d,
            "jitter_yz_A": [jitter_y, jitter_z],
        }

    return {"placement": "at_protein_center"}


def build_protein_multiligand(
    protein_pdb: str,
    ligands: List[Dict[str, Any]],
    *,
    parametrize: bool = True,
    parametrize_method: str = "swissparam",
    pad: float = 12.0,
    saltconc: float = 0.15,
    cation: str = "SOD",
    anion: str = "CLA",
    pH: float = 7.4,
    forcefield: str = "charmm",
    outdir: str = "build_multiligand",
    seed: Optional[int] = None,
    keep_selection_protein: Optional[str] = None,
    remove_selection_protein: Optional[str] = "resname BEN",
) -> Dict[str, Any]:
    """Prepare protein → place N ligands → solvate → CHARMM build.

    Parameters
    ----------
    protein_pdb
        Local PDB path or 4-letter PDB ID.
    ligands
        List of dicts. Each dict must specify the ligand source (one of
        ``ligand_input``, ``ligand_rcsb_id``, ``ligand_smiles``, or the
        triple ``ligand_rtf`` + ``ligand_prm`` + ``ligand_pdb``) plus a
        unique ``resname`` (max 4 chars, will be uppercased). Optional:
        ``copies`` (default 1), ``place_at`` (xyz list), ``random_far``
        (default True if no place_at), ``parametrize`` (override per-spec).
    parametrize
        Default ``True``: each non-prebuilt spec is sent to Swiss-Param.
    pad, saltconc, cation, anion, pH
        Standard solvate / ionize options.
    seed
        Seed for random placement reproducibility.

    Constraints
    -----------
    Resnames must be unique across the list — psfgen looks up topology by
    resname, so two ligands sharing a resname would collide. If you want
    multiple copies of the same chemical species, use ``copies=N`` on a
    single spec instead.
    """
    if forcefield != "charmm":
        raise NotImplementedError("only CHARMM is wired in this build")
    if not ligands:
        raise ValueError("ligands list is empty; use build_protein_waterbox "
                         "for a no-ligand system")

    from moleculekit.molecule import Molecule
    from moleculekit.tools.preparation import systemPrepare
    from moleculekit.tools.autosegment import autoSegment
    from htmd.builder.solvate import solvate
    from htmd.builder import charmm

    outdir = os.path.abspath(outdir)
    os.makedirs(outdir, exist_ok=True)
    rng = np.random.default_rng(seed)

    # --- 1. Validate resname uniqueness -------------------------------------
    normalized_specs: List[Dict[str, Any]] = []
    seen_resnames: Dict[str, int] = {}
    for i, spec in enumerate(ligands):
        rn = (spec.get("resname") or f"LI{i}").upper()[:4]
        if rn in seen_resnames:
            raise ValueError(
                f"duplicate resname {rn!r} in ligands[{seen_resnames[rn]}] "
                f"and ligands[{i}]. Use 'copies' for stoichiometry, or pick "
                f"a distinct resname per ligand."
            )
        seen_resnames[rn] = i
        s = dict(spec)
        s["resname"] = rn
        s.setdefault("copies", 1)
        s.setdefault("place_at", None)
        s.setdefault("random_far", s.get("place_at") is None)
        normalized_specs.append(s)

    # --- 2. Parametrize each unique ligand ---------------------------------
    from htmd_mcp.prep_ligand import parametrize_ligand
    lig_params: List[Dict[str, Any]] = []  # parallel to normalized_specs
    for i, spec in enumerate(normalized_specs):
        do_parametrize = spec.get("parametrize", parametrize)
        if not do_parametrize:
            for k in ("ligand_rtf", "ligand_prm", "ligand_pdb"):
                if not spec.get(k):
                    raise ValueError(
                        f"ligands[{i}] (resname={spec['resname']}) has "
                        f"parametrize=False but no {k} provided"
                    )
            lig_params.append({
                "rtf": os.path.abspath(spec["ligand_rtf"]),
                "prm": os.path.abspath(spec["ligand_prm"]),
                "pdb": os.path.abspath(spec["ligand_pdb"]),
                "source": "prebuilt",
            })
            continue

        resolved = _resolve_ligand_input(spec, outdir=outdir, spec_index=i)
        if resolved.get("prebuilt"):
            lig_params.append({
                "rtf": os.path.abspath(spec["ligand_rtf"]),
                "prm": os.path.abspath(spec["ligand_prm"]),
                "pdb": os.path.abspath(spec["ligand_pdb"]),
                "source": "prebuilt",
            })
            continue

        params = parametrize_ligand(
            resolved["mol2"],
            ligand_resname=spec["resname"],
            method=parametrize_method,
            outdir=os.path.join(outdir, f"lig_params_{i}"),
        )
        lig_params.append({
            "rtf": params["rtf"],
            "prm": params["prm"],
            "pdb": params["pdb"],
            "source": resolved.get("source", "ligand_input"),
        })

    # --- 3. Prepare protein -------------------------------------------------
    prot = Molecule(protein_pdb)
    if keep_selection_protein:
        prot.filter(keep_selection_protein)
    if remove_selection_protein:
        prot.remove(remove_selection_protein)
    if not (keep_selection_protein or remove_selection_protein):
        prot.filter("protein or water or ions")
    prot = systemPrepare(prot, pH=float(pH))
    prot = autoSegment(prot, sel="protein")
    prot.set("segid", "W", sel="water")
    prot.set("segid", "I", sel="ions")
    prot.center()

    # --- 4. Place each ligand copy ------------------------------------------
    placement_log: List[Dict[str, Any]] = []
    mol = prot.copy()
    global_copy_idx = 0
    radial_offset = 0.0
    for i, spec in enumerate(normalized_specs):
        lig_pdb = lig_params[i]["pdb"]
        for c in range(int(spec["copies"])):
            lig = Molecule(lig_pdb)
            # Resname rewrite (parametrize_ligand already wrote spec resname,
            # but a prebuilt ligand_pdb may not match — force it to match).
            lig.set("resname", spec["resname"])
            # Distinct segid per copy. psfgen requires unique segid+resid
            # combinations, so a per-copy segid avoids collisions even if
            # two ligands share resids.
            seg = f"L{global_copy_idx}"
            lig.set("segid", seg)
            placement = _place_one_ligand(
                prot, lig,
                place_at=spec["place_at"],
                random_far=spec["random_far"] and spec["place_at"] is None,
                rng=rng,
                radial_offset_A=radial_offset,
            )
            mol.append(lig)
            placement_log.append({
                "spec_index": i,
                "resname": spec["resname"],
                "copy": c,
                "segid": seg,
                **placement,
            })
            global_copy_idx += 1
            # Increment radial offset between unbound copies so multiple
            # ligands don't all pile up at +X.
            if spec["random_far"] and spec["place_at"] is None:
                radial_offset += 8.0

    # --- 5. Solvate ----------------------------------------------------------
    solv = solvate(mol, pad=float(pad))

    # --- 6. CHARMM build with all ligand RTFs in topo -----------------------
    topo = list(charmm.defaultTopo()) + [
        os.path.abspath(p["rtf"]) for p in lig_params
    ]
    built = charmm.build(
        solv,
        topo=topo,
        outdir=outdir,
        saltconc=float(saltconc),
        saltcation=cation,
        saltanion=anion,
    )

    # --- 7. Persist .prm paths so NAMD3 staging copies them -----------------
    extra_params = sorted({os.path.abspath(p["prm"]) for p in lig_params})
    with open(os.path.join(outdir, "extra_params.json"), "w") as fh:
        json.dump(extra_params, fh)

    # --- 8. Per-ligand atom counts ------------------------------------------
    per_ligand: List[Dict[str, Any]] = []
    for i, spec in enumerate(normalized_specs):
        n_atoms_lig = int(np.sum(built.atomselect(
            f"resname {spec['resname']}")))
        per_ligand.append({
            "resname": spec["resname"],
            "copies": int(spec["copies"]),
            "source": lig_params[i]["source"],
            "rtf": lig_params[i]["rtf"],
            "prm": lig_params[i]["prm"],
            "n_atoms_total": n_atoms_lig,
        })

    return {
        "status": "ok",
        "outdir": outdir,
        "forcefield": forcefield,
        "n_atoms": int(built.numAtoms),
        "n_protein_atoms": int(np.sum(built.atomselect("protein"))),
        "n_ligand_atoms": int(np.sum(built.atomselect(
            "(" + " or ".join(
                f"resname {s['resname']}" for s in normalized_specs
            ) + ")"
        ))),
        "n_water_atoms": int(np.sum(built.atomselect("water"))),
        "n_ions": int(np.sum(built.atomselect("ions"))),
        "salt_concentration": float(saltconc),
        "n_ligand_specs": len(normalized_specs),
        "n_ligand_copies": int(global_copy_idx),
        "ligands": per_ligand,
        "placements": placement_log,
        "files": {
            "pdb": os.path.join(outdir, "structure.pdb"),
            "psf": os.path.join(outdir, "structure.psf"),
        },
    }
