"""Fetch and prepare small-molecule ligands for parametrization.

The Swiss-Param API (and most CHARMM ligand tools) want a mol2 file with
explicit hydrogens, 3D coordinates, and partial charges. This module turns
common ligand inputs into such a mol2:

- ``fetch_ligand_from_rcsb(ligand_id)`` — pull the ideal-coordinates SDF
  for a 3-letter PDB chemical-component ID and convert to mol2.
- ``prepare_ligand_mol2(input)`` — accept SMILES, SDF, mol2, PDB, or CIF;
  produce a clean mol2 (Hs added, 3D embedded if needed, Gasteiger charges).

Conversion goes through OpenBabel (``obabel``) which is in the htmd conda
env. RDKit is used for the SMILES → 3D embedding step.
"""

from __future__ import annotations

import logging
import os
import shutil
import subprocess
import sys
import tempfile
import urllib.request
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

def _resolve_obabel() -> str:
    """Return a usable obabel path. Honors OBABEL_BIN env var when valid;
    otherwise falls back to the first ``obabel`` on PATH, then to an obabel
    co-installed in the running interpreter's environment. Returns the env
    value verbatim if nothing is found, so the existence check fires later
    with a clear error."""
    explicit = os.environ.get("OBABEL_BIN")
    if explicit and os.path.isfile(explicit):
        return explicit
    found = shutil.which("obabel")
    if found:
        return found
    # obabel is typically conda-installed alongside the interpreter running
    # this code (same env as moleculekit/rdkit). Resolve it next to
    # sys.executable so it works even when PATH lacks the env's bin dir.
    env_bin = os.path.join(
        os.path.dirname(os.path.abspath(sys.executable)), "obabel"
    )
    if os.path.isfile(env_bin):
        return env_bin
    return explicit or "obabel"


OBABEL_BIN = _resolve_obabel()
RCSB_LIGAND_BASE = "https://files.rcsb.org/ligands/view"


def _detect_format(path: str) -> str:
    """Best-effort format guess from extension. Falls back to ``mol2``."""
    ext = Path(path).suffix.lower().lstrip(".")
    return {
        "smi": "smi", "smiles": "smi",
        "sdf": "sdf", "mol": "mol",
        "mol2": "mol2",
        "pdb": "pdb",
        "cif": "cif", "mmcif": "cif",
    }.get(ext, "mol2")


def _looks_like_smiles(s: str) -> bool:
    if "\n" in s or os.path.exists(s):
        return False
    return any(c in s for c in "()=#[]") or len(s) < 100


def _run_obabel(args: list, *, timeout: int = 120) -> subprocess.CompletedProcess:
    if not os.path.isfile(OBABEL_BIN):
        raise FileNotFoundError(
            f"obabel not found at {OBABEL_BIN}. Set OBABEL_BIN env var."
        )
    return subprocess.run(
        [OBABEL_BIN] + args,
        capture_output=True, text=True, timeout=timeout,
    )


def fetch_ligand_from_rcsb(
    ligand_id: str,
    *,
    outdir: str = "ligands",
    output_format: str = "mol2",
    add_hs: bool = True,
    overwrite: bool = False,
) -> Dict[str, Any]:
    """Fetch a ligand from the RCSB chemical-component dictionary.

    Tries ``<ID>_ideal.sdf`` (idealized geometry, includes hydrogens) first
    and falls back to ``<ID>.sdf`` (model coordinates) if that 404s. The
    downloaded SDF is then converted to mol2 with Gasteiger charges.

    Returns paths to the raw SDF and the converted mol2.
    """
    lid = ligand_id.strip().upper()
    if not (1 <= len(lid) <= 5) or not lid.isalnum():
        raise ValueError(
            f"ligand_id {lid!r} does not look like a PDB chemical component "
            "(1-5 alphanumeric chars, e.g. BEN, NAG, ATP)"
        )
    out = Path(outdir).resolve()
    out.mkdir(parents=True, exist_ok=True)
    sdf_path = out / f"{lid}.sdf"
    mol2_path = out / f"{lid}.mol2"

    if mol2_path.is_file() and not overwrite:
        logger.info("Reusing existing %s", mol2_path)
        return {
            "status": "ok",
            "ligand_id": lid,
            "sdf": str(sdf_path) if sdf_path.is_file() else None,
            "mol2": str(mol2_path),
            "source": "cached",
        }

    last_err = None
    source = None
    for variant in (f"{lid}_ideal.sdf", f"{lid}.sdf"):
        url = f"{RCSB_LIGAND_BASE}/{variant}"
        try:
            urllib.request.urlretrieve(url, sdf_path)
            source = url
            break
        except Exception as e:
            last_err = e
    if source is None:
        raise RuntimeError(
            f"Could not fetch RCSB ligand {lid}: tried _ideal.sdf and .sdf, "
            f"last error: {last_err}"
        )

    if output_format == "sdf":
        return {"status": "ok", "ligand_id": lid, "sdf": str(sdf_path),
                "mol2": None, "source": source}

    args = ["-isdf", str(sdf_path), f"-o{output_format}", "-O", str(mol2_path)]
    if add_hs:
        args.append("-h")
    res = _run_obabel(args)
    if res.returncode != 0 or not mol2_path.is_file():
        raise RuntimeError(
            f"obabel SDF→{output_format} failed for {lid}:\n"
            f"stdout:\n{res.stdout[-1500:]}\nstderr:\n{res.stderr[-1500:]}"
        )

    return {
        "status": "ok",
        "ligand_id": lid,
        "sdf": str(sdf_path),
        "mol2": str(mol2_path),
        "source": source,
    }


def prepare_ligand_mol2(
    ligand_input: str,
    *,
    output: Optional[str] = None,
    input_format: Optional[str] = None,
    add_hs: bool = True,
    embed_3d_if_missing: bool = True,
    compute_charges: bool = True,
    name: str = "LIG",
) -> Dict[str, Any]:
    """Convert any common ligand input to a Swiss-Param-ready mol2.

    Parameters
    ----------
    ligand_input
        A SMILES string, or a path to a SMILES/SDF/mol2/PDB/CIF file.
    output
        Destination .mol2 path. Defaults to ``<input_basename>.mol2``.
    input_format
        Override the auto-detected input format. Use ``"smi"`` to force
        SMILES interpretation of a string argument.
    add_hs
        Add explicit hydrogens (default True).
    embed_3d_if_missing
        For SMILES (or SDF without 3D coords), embed a 3D conformer
        with RDKit's ETKDGv3.
    compute_charges
        Run a Gasteiger-charge pass via obabel after the conversion.
    name
        Title written into the mol2 header (cosmetic; resname rewriting
        happens inside the build step).
    """
    # Resolve input
    if input_format == "smi" or (input_format is None and _looks_like_smiles(ligand_input)
                                 and not os.path.isfile(ligand_input)):
        # SMILES → embed 3D via RDKit, write SDF, then obabel to mol2
        return _from_smiles(ligand_input, output=output, name=name,
                            add_hs=add_hs, compute_charges=compute_charges)

    src = Path(ligand_input).resolve()
    if not src.is_file():
        raise FileNotFoundError(
            f"ligand_input {ligand_input!r} not a SMILES nor an existing file"
        )

    fmt = (input_format or _detect_format(str(src))).lower()
    out_path = Path(output).resolve() if output \
        else src.with_suffix(".mol2").resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)

    if fmt == "sdf" and embed_3d_if_missing:
        # Check if SDF lacks 3D — if so, run through RDKit to embed
        if _sdf_needs_3d(src):
            with tempfile.NamedTemporaryFile(
                "w+", suffix=".sdf", delete=False
            ) as tmp:
                _embed_sdf_3d(src, Path(tmp.name))
                src = Path(tmp.name)

    args = [f"-i{fmt}", str(src), "-omol2", "-O", str(out_path)]
    if add_hs:
        args.append("-h")
    if compute_charges:
        args += ["--partialcharge", "gasteiger"]
    if name:
        args += ["--title", name]
    res = _run_obabel(args)
    if res.returncode != 0 or not out_path.is_file():
        raise RuntimeError(
            f"obabel {fmt}→mol2 failed:\nstdout:\n{res.stdout[-1500:]}\n"
            f"stderr:\n{res.stderr[-1500:]}"
        )

    return {
        "status": "ok",
        "input": str(src),
        "input_format": fmt,
        "mol2": str(out_path),
        "name": name,
    }


def _from_smiles(smiles: str, *, output: Optional[str], name: str,
                add_hs: bool, compute_charges: bool) -> Dict[str, Any]:
    from rdkit import Chem
    from rdkit.Chem import AllChem

    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError(f"RDKit failed to parse SMILES: {smiles!r}")
    if add_hs:
        mol = Chem.AddHs(mol)
    params = AllChem.ETKDGv3()
    params.randomSeed = 0xC0FFEE
    res_emb = AllChem.EmbedMolecule(mol, params)
    if res_emb != 0:
        raise RuntimeError(f"3D embedding failed for SMILES: {smiles!r}")
    AllChem.MMFFOptimizeMolecule(mol)
    mol.SetProp("_Name", name)

    out_path = Path(output).resolve() if output else Path("ligand.mol2").resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", suffix=".sdf", delete=False) as tmp:
        tmp.write(Chem.MolToMolBlock(mol))
        tmp_path = Path(tmp.name)

    args = ["-isdf", str(tmp_path), "-omol2", "-O", str(out_path)]
    if compute_charges:
        args += ["--partialcharge", "gasteiger"]
    if name:
        args += ["--title", name]
    res = _run_obabel(args)
    if res.returncode != 0 or not out_path.is_file():
        raise RuntimeError(f"obabel sdf→mol2 failed: {res.stderr[-1500:]}")

    return {
        "status": "ok",
        "smiles": smiles,
        "input_format": "smi",
        "mol2": str(out_path),
        "name": name,
    }


def _sdf_needs_3d(path: Path) -> bool:
    """Heuristic: SDF lacks 3D if all z-coordinates of the first atom block
    are 0.000."""
    text = path.read_text()
    # Find atom block — it's between the counts line and the bond block.
    lines = text.splitlines()
    # Counts line is line index 3 (4th line) in V2000 format.
    if len(lines) < 5:
        return True
    try:
        n_atoms = int(lines[3].split()[0])
    except (ValueError, IndexError):
        return True
    atom_block = lines[4: 4 + n_atoms]
    zs = []
    for ln in atom_block:
        try:
            zs.append(float(ln[20:30]))
        except (ValueError, IndexError):
            continue
    return bool(zs) and all(abs(z) < 1e-3 for z in zs)


def _embed_sdf_3d(src: Path, dst: Path) -> None:
    from rdkit import Chem
    from rdkit.Chem import AllChem

    suppl = Chem.SDMolSupplier(str(src), removeHs=False)
    mol = next((m for m in suppl if m is not None), None)
    if mol is None:
        raise ValueError(f"RDKit could not read SDF {src}")
    mol = Chem.AddHs(mol)
    params = AllChem.ETKDGv3()
    params.randomSeed = 0xC0FFEE
    if AllChem.EmbedMolecule(mol, params) != 0:
        raise RuntimeError(f"3D embedding failed for {src}")
    AllChem.MMFFOptimizeMolecule(mol)
    writer = Chem.SDWriter(str(dst))
    writer.write(mol)
    writer.close()
