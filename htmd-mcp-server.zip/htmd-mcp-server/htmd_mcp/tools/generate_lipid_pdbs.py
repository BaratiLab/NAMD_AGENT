"""Generate single-lipid PDBs for HTMD's MembraneBuilder by transferring
coordinates from POPC/POPE through psfgen + IC-based guesscoord.

Run once after installation; idempotent. Writes into the conda-installed
HTMD share dir (the same place ``listLipids()`` reports) and updates
``lipiddb.csv`` with APL/head-atom/thickness entries.

The phosphatidyl backbone (P, O11..O14, glycerol C1/C2/C3, ester carbonyl
atoms, sn-1 chain atoms C2X, sn-2 chain atoms C3X) shares the same atom names
across CHARMM phospholipid topologies, so coordinates from a POPC reference
transfer cleanly. Headgroup atoms beyond the phosphate (choline / ethanolamine
/ serine / glycerol / phosphate-H) are filled in by psfgen's IC table.
"""

from __future__ import annotations

import csv
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Tuple

# --- Lipid database ---------------------------------------------------------
# Each entry: (resname, family, APL_A2, head_atom, thickness_A)
# APLs come from CHARMM-GUI / CHARMM36 references; thickness is the standard
# bilayer head-to-head distance for a fluid lamellar phase. These values are
# used only for *initial* lipid placement (they get relaxed during equilibration).

LIPID_TABLE: List[Tuple[str, str, float, str, float]] = [
    # PC family — phosphatidylcholine, head P
    ("dlpc", "PC", 63.2, "P", 32.0),  # 12:0/12:0
    ("dmpc", "PC", 60.6, "P", 35.3),  # 14:0/14:0
    ("dppc", "PC", 62.9, "P", 38.3),  # 16:0/16:0
    ("dspc", "PC", 65.5, "P", 39.3),  # 18:0/18:0
    ("dopc", "PC", 67.4, "P", 38.7),  # 18:1/18:1
    ("sapc", "PC", 70.0, "P", 38.0),  # 18:0/20:4
    ("sdpc", "PC", 70.0, "P", 38.0),  # 18:0/22:6
    ("sopc", "PC", 67.0, "P", 38.0),  # 18:0/18:1
    ("dapc", "PC", 70.0, "P", 38.0),  # 20:4/20:4
    ("lppc", "PC", 50.0, "P", 32.0),  # lyso-PC (single chain)
    # PE family — phosphatidylethanolamine
    ("dlpe", "PE", 51.2, "P", 33.0),
    ("dmpe", "PE", 55.1, "P", 36.3),
    ("dppe", "PE", 56.0, "P", 38.3),
    ("dspe", "PE", 56.0, "P", 39.3),
    ("dope", "PE", 65.0, "P", 38.0),
    # PS family — phosphatidylserine (anionic, charge -1)
    ("dlps", "PS", 50.0, "P", 33.0),
    ("dmps", "PS", 55.0, "P", 36.0),
    ("dpps", "PS", 55.0, "P", 38.0),
    ("dsps", "PS", 58.0, "P", 39.0),
    ("dops", "PS", 64.0, "P", 38.0),
    ("pops", "PS", 62.7, "P", 36.7),
    # PA family — phosphatidic acid
    ("dlpa", "PA", 55.0, "P", 33.0),
    ("dmpa", "PA", 55.0, "P", 36.0),
    ("dppa", "PA", 55.0, "P", 38.0),
    ("dspa", "PA", 58.0, "P", 39.0),
    ("dopa", "PA", 65.0, "P", 38.0),
    ("popa", "PA", 56.5, "P", 36.7),
    # PG family — phosphatidylglycerol
    ("dlpg", "PG", 55.0, "P", 33.0),
    ("dmpg", "PG", 55.0, "P", 36.0),
    ("dppg", "PG", 60.0, "P", 38.0),
    ("dspg", "PG", 60.0, "P", 39.0),
    ("dopg", "PG", 70.0, "P", 38.0),
    ("popg", "PG", 64.3, "P", 36.7),
]


def _htmd_share() -> Path:
    """Return the HTMD share dir on the active htmd python."""
    cmd = [
        os.environ.get(
            "HTMD_PYTHON",
            "/home/achuth-chandrasekhar/miniconda3/envs/htmd/bin/python",
        ),
        "-c",
        "from htmd.home import home; print(home(shareDir=True))",
    ]
    out = subprocess.check_output(cmd, text=True).strip().splitlines()[-1]
    return Path(out)


def _psfgen_bin() -> str:
    return os.environ.get("PSFGEN_BIN", "/usr/local/bin/psfgen")


def _build_lipid_pdb(
    resname: str,
    template_pdb: Path,
    charmmfiles: Path,
    workdir: Path,
) -> Path:
    """Run psfgen with template_pdb's coords transferred to a freshly-built
    single-residue segment of resname. Returns the output PDB path."""
    workdir.mkdir(parents=True, exist_ok=True)
    # Copy topology files into workdir so the Tcl script can use relative paths
    top_src = charmmfiles / "top"
    top_dst = workdir / "top"
    if not top_dst.exists():
        shutil.copytree(top_src, top_dst)
    shutil.copy(template_pdb, workdir / "ref.pdb")

    tcl_path = workdir / f"{resname}.tcl"
    pdb_out = workdir / f"{resname.lower()}.pdb"
    psf_out = workdir / f"{resname.lower()}.psf"
    tcl_path.write_text(
        "package require psfgen\n"
        "topology top/top_all36_lipid.rtf\n"
        "topology top/top_water_ions.rtf\n"
        f"segment L {{ residue 1 {resname.upper()} }}\n"
        "coordpdb ref.pdb L\n"
        "guesscoord\n"
        f"writepsf {psf_out.name}\n"
        f"writepdb {pdb_out.name}\n"
    )
    log = subprocess.run(
        [_psfgen_bin(), tcl_path.name],
        cwd=workdir,
        capture_output=True,
        text=True,
    )
    if log.returncode != 0 or not pdb_out.is_file():
        raise RuntimeError(
            f"psfgen failed for {resname}:\n{log.stdout[-1500:]}\n{log.stderr[-1500:]}"
        )
    return pdb_out


def _validate(pdb_path: Path, head_atom: str) -> Dict[str, float]:
    """Cheap geometry check — head P present, tail extending negative-z, decent length."""
    import numpy as np
    from moleculekit.molecule import Molecule

    m = Molecule(str(pdb_path))
    if not (m.name == head_atom).any():
        raise ValueError(f"head atom {head_atom!r} missing in {pdb_path}")
    z = m.coords[:, 2, 0]
    z_head = float(m.coords[m.name == head_atom, 2, 0][0])
    extent = float(z.max() - z.min())
    return {
        "n_atoms": int(m.numAtoms),
        "z_head": z_head,
        "z_min": float(z.min()),
        "z_max": float(z.max()),
        "extent": extent,
    }


def generate_all(
    *,
    lipid_dir: Path = None,
    charmmfiles: Path = None,
    workdir: Path = Path("/tmp/lipidgen"),
    overwrite: bool = False,
) -> Dict[str, Dict]:
    """Generate every lipid in LIPID_TABLE that is missing under lipid_dir.
    Updates lipiddb.csv. Returns a per-lipid status dict.
    """
    share = _htmd_share()
    lipid_dir = lipid_dir or (share / "membranebuilder" / "lipids")
    charmmfiles = charmmfiles or (share / "builder" / "charmmfiles")

    if not lipid_dir.is_dir():
        raise FileNotFoundError(f"lipid_dir not found: {lipid_dir}")
    if not (charmmfiles / "top" / "top_all36_lipid.rtf").is_file():
        raise FileNotFoundError(
            f"CHARMM lipid topology missing: {charmmfiles}/top/top_all36_lipid.rtf"
        )

    # Reference template = existing POPC
    template = lipid_dir / "popc" / "popc.pdb"
    if not template.is_file():
        raise FileNotFoundError(f"POPC template missing at {template}")

    workdir.mkdir(parents=True, exist_ok=True)
    results: Dict[str, Dict] = {}

    for resname, family, apl, head, thickness in LIPID_TABLE:
        out_dir = lipid_dir / resname.lower()
        out_pdb = out_dir / f"{resname.lower()}.pdb"
        if out_pdb.is_file() and not overwrite:
            results[resname] = {"status": "skipped (exists)", "path": str(out_pdb)}
            continue
        try:
            built = _build_lipid_pdb(
                resname=resname.upper(),
                template_pdb=template,
                charmmfiles=charmmfiles,
                workdir=workdir / resname.lower(),
            )
            geom = _validate(built, head)
            out_dir.mkdir(parents=True, exist_ok=True)
            shutil.copy(built, out_pdb)
            results[resname] = {
                "status": "ok",
                "path": str(out_pdb),
                "family": family,
                "apl": apl,
                "head": head,
                "thickness": thickness,
                **geom,
            }
        except Exception as e:
            results[resname] = {"status": "error", "error": str(e)}

    _update_lipiddb_csv(lipid_dir / "lipiddb.csv", results)
    return results


def _update_lipiddb_csv(csv_path: Path, results: Dict[str, Dict]) -> None:
    """Merge new entries into lipiddb.csv, preserving existing rows."""
    rows: Dict[str, Tuple[str, str, str, str]] = {}
    if csv_path.is_file():
        with open(csv_path) as fh:
            reader = csv.reader(fh)
            header = next(reader, None)
            for row in reader:
                if not row:
                    continue
                rows[row[0].strip()] = tuple(row)

    for resname, info in results.items():
        if info.get("status") not in ("ok", "skipped (exists)"):
            continue
        # Look up table values for this resname
        for r, fam, apl, head, thickness in LIPID_TABLE:
            if r.lower() == resname.lower():
                rows[resname.lower()] = (resname.lower(), str(apl), head, str(thickness))
                break

    with open(csv_path, "w", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["Name", "APL", "Head", "Thickness"])
        for name in sorted(rows):
            writer.writerow(rows[name])


def main(argv: List[str]) -> int:
    overwrite = "--overwrite" in argv
    res = generate_all(overwrite=overwrite)
    ok = sum(1 for v in res.values() if v.get("status") == "ok")
    err = [k for k, v in res.items() if v.get("status") == "error"]
    skipped = sum(1 for v in res.values() if v.get("status") == "skipped (exists)")
    import json
    print(json.dumps({
        "ok": ok, "errors": err, "skipped": skipped,
        "details": res,
    }, indent=2))
    return 0 if not err else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
