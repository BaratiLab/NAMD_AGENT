"""Trajectory visualizations: simulation movies (PyMOL headless +
ffmpeg) and dashboard movies (matplotlib animation of timeseries)."""

from __future__ import annotations

import logging
import os
import shutil
import subprocess
import tempfile
import textwrap
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np

from htmd_mcp.postprocess import _ensure_outdir, _load_traj

logger = logging.getLogger(__name__)

PYMOL_BIN = os.environ.get(
    "PYMOL_BIN",
    "/home/achuth-chandrasekhar/miniconda3/envs/htmd/bin/pymol",
)
FFMPEG_BIN = os.environ.get(
    "FFMPEG_BIN",
    "/home/achuth-chandrasekhar/miniconda3/envs/htmd/bin/ffmpeg",
)


# --- Molecular movie via PyMOL ---------------------------------------------

def render_molecular_movie(
    run_dir: str,
    *,
    output_basename: str = "movie",
    fps: int = 20,
    width: int = 800,
    height: int = 600,
    n_frames: Optional[int] = None,
    representation: str = "cartoon_ligand",  # "cartoon_ligand"|"cartoon"|"surface"
    ligand_resname: Optional[str] = None,
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
    ray_trace: bool = False,
) -> Dict[str, Any]:
    """Render an MP4 of the trajectory using PyMOL headless + ffmpeg.

    The movie shows the protein as cartoon (rainbow by residue), the ligand
    (if specified) as licorice, and waters/ions hidden. Set ``ray_trace=True``
    for publication-quality (slow) rendering.
    """
    out = _ensure_outdir(run_dir)
    movie_dir = out / f"{output_basename}_frames"
    movie_dir.mkdir(parents=True, exist_ok=True)

    # We need a clean stripped PDB + DCD for PyMOL. Use wrap_and_align outputs
    # if they exist; otherwise create them on the fly.
    aligned_pdb = out / "aligned.pdb"
    aligned_dcd = out / "aligned.dcd"
    if not (aligned_pdb.is_file() and aligned_dcd.is_file()):
        from htmd_mcp.postprocess import wrap_and_align
        wrap_and_align(run_dir, psf=psf, pdb=pdb, dcd=dcd,
                       output_basename="aligned")

    # Optional frame stride
    if n_frames is not None and n_frames > 0:
        # mdtraj/pymol can subsample via PyMOL "intra_fit" / "set state" — easier
        # is to just pass a stride to pymol below
        pass

    # PyMOL only parses multi-line Python in .py files; .pml is line-by-line.
    py_script = movie_dir / "render.py"
    py_script.write_text(_pymol_script(
        pdb=str(aligned_pdb), dcd=str(aligned_dcd),
        frames_prefix=str(movie_dir / "frame_"),
        width=width, height=height,
        ligand_resname=ligand_resname,
        representation=representation,
        ray_trace=ray_trace,
        n_frames=n_frames,
    ))

    res = subprocess.run(
        [PYMOL_BIN, "-cq", "-r", str(py_script)],
        capture_output=True, text=True, timeout=3600,
    )
    if res.returncode != 0:
        return {
            "status": "error",
            "error": f"PyMOL failed (code {res.returncode})",
            "stderr_tail": res.stderr[-2000:],
            "stdout_tail": res.stdout[-2000:],
        }

    # ffmpeg concatenate frame_*.png into MP4
    mp4_path = out / f"{output_basename}.mp4"
    ff = subprocess.run(
        [FFMPEG_BIN, "-y", "-framerate", str(fps),
         "-i", str(movie_dir / "frame_%04d.png"),
         "-c:v", "libx264", "-pix_fmt", "yuv420p",
         "-vf", "pad=ceil(iw/2)*2:ceil(ih/2)*2",
         str(mp4_path)],
        capture_output=True, text=True, timeout=1800,
    )
    if ff.returncode != 0 or not mp4_path.is_file():
        return {
            "status": "error",
            "error": f"ffmpeg failed (code {ff.returncode})",
            "stderr_tail": ff.stderr[-2000:],
        }

    n_png = len(list(movie_dir.glob("frame_*.png")))
    return {
        "status": "ok",
        "mp4": str(mp4_path),
        "fps": int(fps),
        "n_frames_rendered": int(n_png),
        "frames_dir": str(movie_dir),
    }


def _pymol_script(*, pdb: str, dcd: str, frames_prefix: str,
                 width: int, height: int,
                 ligand_resname: Optional[str],
                 representation: str,
                 ray_trace: bool,
                 n_frames: Optional[int]) -> str:
    lig_line = ""
    if ligand_resname:
        lig_line = (f'select __lig, resn {ligand_resname.upper()}\n'
                    'show licorice, __lig\n'
                    'color magenta, __lig\n')

    repr_block = {
        "cartoon": "show cartoon, polymer\nspectrum count, rainbow, polymer\n",
        "cartoon_ligand": "show cartoon, polymer\nspectrum count, rainbow, polymer\n",
        "surface": "show surface, polymer\nspectrum count, rainbow, polymer\n",
    }.get(representation, "show cartoon, polymer\nspectrum count, rainbow, polymer\n")

    ray_line = "ray" if ray_trace else "draw"

    stride_block = ""
    if n_frames is not None and n_frames > 0:
        stride_block = textwrap.dedent(f"""
            from pymol import cmd
            total = cmd.count_states()
            stride = max(1, total // {n_frames})
        """)
    else:
        stride_block = ""

    n_target_str = str(n_frames) if n_frames else "total"
    ray_int = 1 if ray_trace else 0

    # Indented body so it lives inside a function — PyMOL's `-r script.py`
    # works with regular Python files but multi-line `for` blocks must be
    # syntactically clean.
    body = (
        'from pymol import cmd\n'
        'cmd.bg_color("white")\n'
        f'cmd.viewport({width}, {height})\n'
        f'cmd.load("{pdb}", "sys")\n'
        f'cmd.load_traj("{dcd}", "sys")\n'
        'cmd.hide("everything")\n'
        'cmd.show("cartoon", "polymer")\n'
        'cmd.spectrum("count", "rainbow", "polymer")\n'
        f'{lig_line}'
        'cmd.set("ray_opaque_background", 0)\n'
        'cmd.set("antialias", 2)\n'
        'cmd.set("cartoon_smooth_loops", 1)\n'
        'cmd.orient()\n'
        'cmd.zoom("polymer", buffer=5)\n'
        '\n'
        'total = cmd.count_states()\n'
        f'n_target = {n_target_str}\n'
        'stride = max(1, total // n_target)\n'
        '\n'
        'idx = 0\n'
        'for s in range(1, total + 1, stride):\n'
        '    cmd.set("state", s)\n'
        f'    fname = "{frames_prefix}" + ("%04d" % idx) + ".png"\n'
        f'    cmd.png(fname, width={width}, height={height}, ray={ray_int}, dpi=120)\n'
        '    idx += 1\n'
        'print("rendered", idx, "frames")\n'
    )
    return body


# --- Dashboard movie via matplotlib ---------------------------------------

def render_dashboard_movie(
    run_dir: str,
    *,
    output_basename: str = "dashboard",
    fps: int = 10,
    width_in: float = 12.0,
    height_in: float = 6.0,
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> Dict[str, Any]:
    """Multi-panel matplotlib movie: protein RMSD, Rg, total SASA, and a
    PC1-PC2 trace, animated frame-by-frame. Uses analyses already present
    in ``run_dir/analysis/`` if available; otherwise computes a small set
    of cheap metrics on the fly.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.animation import FuncAnimation, FFMpegWriter

    # matplotlib looks for `ffmpeg` in PATH; use the conda binary explicitly.
    if os.path.isfile(FFMPEG_BIN):
        matplotlib.rcParams["animation.ffmpeg_path"] = FFMPEG_BIN

    out = _ensure_outdir(run_dir)

    # Load timeseries (compute if missing)
    rmsd = _load_or_compute(run_dir, "rmsd_0000.csv", "rmsd",
                           psf=psf, pdb=pdb, dcd=dcd)
    rg = _load_or_compute(run_dir, "rg.csv", "rg",
                         psf=psf, pdb=pdb, dcd=dcd)
    sasa = _load_or_compute(run_dir, "sasa_total.csv", "sasa",
                          psf=psf, pdb=pdb, dcd=dcd)
    pca_proj = _load_pca(run_dir)

    n = max(len(rmsd), len(rg), len(sasa), len(pca_proj) if pca_proj is not None else 0)
    if n == 0:
        return {"status": "error", "error": "no analysis data found"}

    fig, axes = plt.subplots(2, 2, figsize=(width_in, height_in))
    fig.suptitle("MD dashboard")

    (rmsd_line,) = axes[0, 0].plot([], [], "b-", lw=1.5)
    rmsd_pt = axes[0, 0].scatter([], [], c="red", s=30, zorder=5)
    axes[0, 0].set_xlim(0, n)
    if len(rmsd):
        axes[0, 0].set_ylim(rmsd.min(), rmsd.max() * 1.1 + 0.01)
    axes[0, 0].set_xlabel("frame")
    axes[0, 0].set_ylabel("RMSD (Å)")

    (rg_line,) = axes[0, 1].plot([], [], "g-", lw=1.5)
    rg_pt = axes[0, 1].scatter([], [], c="red", s=30, zorder=5)
    axes[0, 1].set_xlim(0, n)
    if len(rg):
        axes[0, 1].set_ylim(rg.min() - 0.1, rg.max() + 0.1)
    axes[0, 1].set_xlabel("frame")
    axes[0, 1].set_ylabel("Rg (Å)")

    (sa_line,) = axes[1, 0].plot([], [], "m-", lw=1.5)
    sa_pt = axes[1, 0].scatter([], [], c="red", s=30, zorder=5)
    axes[1, 0].set_xlim(0, n)
    if len(sasa):
        axes[1, 0].set_ylim(sasa.min() * 0.9, sasa.max() * 1.05)
    axes[1, 0].set_xlabel("frame")
    axes[1, 0].set_ylabel("SASA (Å²)")

    if pca_proj is not None and pca_proj.shape[1] >= 2:
        axes[1, 1].plot(pca_proj[:, 0], pca_proj[:, 1], "k-", lw=0.4, alpha=0.4)
        sc = axes[1, 1].scatter([], [], c="red", s=40, zorder=5)
        axes[1, 1].set_xlabel("PC1")
        axes[1, 1].set_ylabel("PC2")
        axes[1, 1].set_xlim(pca_proj[:, 0].min() - 1, pca_proj[:, 0].max() + 1)
        axes[1, 1].set_ylim(pca_proj[:, 1].min() - 1, pca_proj[:, 1].max() + 1)
    else:
        axes[1, 1].text(0.5, 0.5, "Run compute_pca first\nto see PC1-PC2",
                        ha="center", va="center", transform=axes[1, 1].transAxes)
        axes[1, 1].axis("off")
        sc = None

    fig.tight_layout()

    def update(i):
        rng = np.arange(min(i + 1, len(rmsd)))
        if len(rmsd):
            rmsd_line.set_data(rng, rmsd[: len(rng)])
            rmsd_pt.set_offsets([[rng[-1], rmsd[rng[-1]]]] if len(rng) else [])
        if len(rg):
            rgrng = np.arange(min(i + 1, len(rg)))
            rg_line.set_data(rgrng, rg[: len(rgrng)])
            rg_pt.set_offsets([[rgrng[-1], rg[rgrng[-1]]]] if len(rgrng) else [])
        if len(sasa):
            srng = np.arange(min(i + 1, len(sasa)))
            sa_line.set_data(srng, sasa[: len(srng)])
            sa_pt.set_offsets([[srng[-1], sasa[srng[-1]]]] if len(srng) else [])
        if sc is not None and pca_proj is not None and i < len(pca_proj):
            sc.set_offsets([[pca_proj[i, 0], pca_proj[i, 1]]])
        return [rmsd_line, rmsd_pt, rg_line, rg_pt, sa_line, sa_pt] + (
            [sc] if sc is not None else [])

    anim = FuncAnimation(fig, update, frames=n, interval=1000 / fps, blit=False)
    mp4_path = out / f"{output_basename}.mp4"

    try:
        writer = FFMpegWriter(fps=int(fps), codec="libx264",
                              bitrate=2400, extra_args=["-pix_fmt", "yuv420p"])
        anim.save(str(mp4_path), writer=writer, dpi=120)
    except Exception as e:
        # Fallback to GIF
        gif_path = out / f"{output_basename}.gif"
        anim.save(str(gif_path), writer="pillow", fps=int(fps), dpi=100)
        plt.close(fig)
        return {
            "status": "ok",
            "format": "gif",
            "path": str(gif_path),
            "fallback_reason": str(e),
            "n_frames": int(n),
        }

    plt.close(fig)
    return {
        "status": "ok",
        "format": "mp4",
        "mp4": str(mp4_path),
        "n_frames": int(n),
        "fps": int(fps),
    }


def _load_or_compute(run_dir: str, csv_name: str, kind: str,
                    *, psf, pdb, dcd) -> np.ndarray:
    """Load a 1-column numeric timeseries from the analysis dir; if missing,
    compute it on the fly."""
    out = _ensure_outdir(run_dir)
    csv_path = out / csv_name
    if csv_path.is_file():
        import csv
        with open(csv_path) as fh:
            r = csv.reader(fh)
            next(r, None)
            vals = []
            for row in r:
                if len(row) >= 2:
                    try:
                        vals.append(float(row[1]))
                    except ValueError:
                        pass
        return np.array(vals, dtype=np.float64)

    # Compute on demand
    from htmd_mcp.postprocess import (
        compute_rmsd, radius_of_gyration, compute_sasa,
    )
    if kind == "rmsd":
        compute_rmsd(run_dir, psf=psf, pdb=pdb, dcd=dcd)
    elif kind == "rg":
        radius_of_gyration(run_dir, psf=psf, pdb=pdb, dcd=dcd)
    elif kind == "sasa":
        compute_sasa(run_dir, mode="total", psf=psf, pdb=pdb, dcd=dcd)
    return _load_or_compute(run_dir, csv_name, kind, psf=psf, pdb=pdb, dcd=dcd) \
        if csv_path.is_file() else np.array([])


def _load_pca(run_dir: str) -> Optional[np.ndarray]:
    out = _ensure_outdir(run_dir)
    csv_path = out / "pca_projections.csv"
    if not csv_path.is_file():
        return None
    import csv
    with open(csv_path) as fh:
        r = csv.reader(fh)
        next(r, None)
        rows = [[float(x) for x in row[1:]] for row in r]
    return np.array(rows) if rows else None
