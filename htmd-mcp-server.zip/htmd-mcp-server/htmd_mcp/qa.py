"""Quality-assurance for NAMD3 simulations.

Reads NAMD3 ENERGY: log lines from min/equil/prod runs and reports:

* Energy stability (drift via linear fit, conservation in NVE)
* Temperature stability (mean ± std, deviation from target)
* Pressure / volume / density evolution (NPT)
* Box-vector drift
* Equilibration detection (block-averaged variance plateau, ``pymbar``-style)
* Bond-length sanity check on the final frame

Output: dashboard PNG + machine-readable JSON.
"""

from __future__ import annotations

import csv
import json
import logging
import os
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from htmd_mcp.postprocess import _ensure_outdir
from htmd_mcp.namd3_runner import parse_namd_log

logger = logging.getLogger(__name__)


def _parse_energy_log(log_path: str) -> Dict[str, np.ndarray]:
    """Pull all ENERGY: timeseries out of a NAMD3 log into per-column arrays."""
    if not os.path.isfile(log_path):
        return {}
    header: List[str] = []
    rows: List[List[float]] = []
    with open(log_path, "r", errors="replace") as fh:
        for line in fh:
            if line.startswith("ETITLE:"):
                header = line.split()[1:]
            elif line.startswith("ENERGY:") and header:
                parts = line.split()[1:]
                if len(parts) == len(header):
                    try:
                        rows.append([float(p) for p in parts])
                    except ValueError:
                        pass
    if not rows or not header:
        return {}
    arr = np.asarray(rows)
    return {col: arr[:, i] for i, col in enumerate(header)}


def _detect_equilibration(timeseries: np.ndarray,
                          n_blocks: int = 10) -> Dict[str, Any]:
    """Crude block-variance equilibration detector. Returns the index after
    which block-to-block variance drops below 2× the long-time variance."""
    n = len(timeseries)
    if n < 4 * n_blocks:
        return {"detected": False, "first_eq_index": 0, "n_points": int(n)}

    block_size = n // n_blocks
    block_means = np.array([
        np.mean(timeseries[i * block_size:(i + 1) * block_size])
        for i in range(n_blocks)
    ])
    long_var = np.var(timeseries[-(n // 2):])
    block_var = np.var(block_means[1:])

    # Heuristic: report the first quarter as "transient"
    first_eq = int(0.25 * n) if block_var > 2 * long_var else 0
    return {
        "detected": bool(block_var <= 2 * long_var),
        "first_eq_index": first_eq,
        "block_var": float(block_var),
        "long_var": float(long_var),
        "n_points": int(n),
    }


def _drift(values: np.ndarray) -> Dict[str, float]:
    """Linear regression slope to detect drift."""
    if values.size < 4:
        return {"slope": 0.0, "intercept": float(values.mean()) if values.size else 0.0}
    x = np.arange(values.size, dtype=np.float64)
    slope, intercept = np.polyfit(x, values, 1)
    return {"slope": float(slope), "intercept": float(intercept)}


def _stats(values: np.ndarray) -> Dict[str, float]:
    if values.size == 0:
        return {"n": 0}
    return {
        "n": int(values.size),
        "mean": float(np.mean(values)),
        "std": float(np.std(values)),
        "min": float(np.min(values)),
        "max": float(np.max(values)),
        "first": float(values[0]),
        "last": float(values[-1]),
    }


def quality_assurance_report(
    run_dirs: List[str],
    *,
    target_temperature: float = 300.0,
    target_pressure: float = 1.01325,
    output_basename: str = "qa_report",
) -> Dict[str, Any]:
    """Aggregate QA report across one or more run directories.

    Pass ``run_dirs=[min_dir, equil_dir, prod_dir]`` to get a complete picture
    of a min → equil → prod pipeline, or a single dir for one stage.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    if isinstance(run_dirs, str):
        run_dirs = [run_dirs]

    stage_data: Dict[str, Dict[str, Any]] = {}
    last_run_dir = None
    for run_dir in run_dirs:
        run_dir = os.path.abspath(run_dir)
        last_run_dir = run_dir
        log_candidates = [Path(run_dir) / "log.txt"] + list(
            Path(run_dir).glob("*.log")
        )
        log_path = next((p for p in log_candidates if p.is_file()), None)
        if log_path is None:
            stage_data[run_dir] = {"status": "no_log"}
            continue
        log_summary = parse_namd_log(str(log_path))
        ts = _parse_energy_log(str(log_path))
        stage_data[run_dir] = {
            "log": str(log_path),
            "log_summary": log_summary,
            "timeseries_keys": sorted(ts.keys()),
            "n_records": int(next(iter(ts.values())).size) if ts else 0,
            "stats": {},
        }
        for key in ("TOTAL", "POTENTIAL", "KINETIC", "TEMP", "PRESSURE",
                    "VOLUME", "BOND", "ELECT", "VDW"):
            if key in ts:
                stage_data[run_dir]["stats"][key] = _stats(ts[key])
                stage_data[run_dir]["stats"][key].update({
                    "drift": _drift(ts[key])["slope"],
                })
        if "TEMP" in ts:
            stage_data[run_dir]["temperature_deviation_from_target_K"] = (
                float(np.mean(ts["TEMP"])) - float(target_temperature)
            )
        if "PRESSURE" in ts:
            stage_data[run_dir]["pressure_deviation_from_target_bar"] = (
                float(np.mean(ts["PRESSURE"])) - float(target_pressure)
            )
        # Equilibration detection on the totalenergy timeseries
        if "TOTAL" in ts:
            stage_data[run_dir]["equilibration"] = _detect_equilibration(ts["TOTAL"])

    # Combined dashboard
    out = _ensure_outdir(last_run_dir or run_dirs[-1])
    fig, axes = plt.subplots(3, 2, figsize=(13, 10))
    fig.suptitle("Quality assurance report")
    titles = [
        ("TOTAL", "Total E (kcal/mol)"),
        ("POTENTIAL", "Potential E (kcal/mol)"),
        ("TEMP", "Temperature (K)"),
        ("PRESSURE", "Pressure (bar)"),
        ("VOLUME", "Volume (Å³)"),
        ("KINETIC", "Kinetic E (kcal/mol)"),
    ]
    colors = {"min": "tab:gray", "equil": "tab:blue", "prod": "tab:green"}

    def _stage_color(run_dir: str) -> str:
        name = Path(run_dir).name.lower()
        for k, c in colors.items():
            if k in name:
                return c
        return "tab:purple"

    for ax, (key, label) in zip(axes.flat, titles):
        offset = 0
        for run_dir, data in stage_data.items():
            log = data.get("log")
            if not log:
                continue
            ts = _parse_energy_log(log)
            if key not in ts:
                continue
            x = np.arange(len(ts[key])) + offset
            ax.plot(x, ts[key], lw=1.0,
                    color=_stage_color(run_dir),
                    label=Path(run_dir).name)
            offset += len(ts[key])
        ax.set_ylabel(label)
        ax.set_xlabel("record")
        ax.grid(alpha=0.2)
    axes.flat[0].legend(loc="upper right", fontsize=8)

    if key == "TEMP":
        axes.flat[2].axhline(target_temperature, color="red", ls="--", lw=0.8)
    if key == "PRESSURE":
        axes.flat[3].axhline(target_pressure, color="red", ls="--", lw=0.8)

    fig.tight_layout()
    png = out / f"{output_basename}.png"
    fig.savefig(png, dpi=120)
    plt.close(fig)

    json_path = out / f"{output_basename}.json"
    json_path.write_text(json.dumps({
        "target_temperature_K": float(target_temperature),
        "target_pressure_bar": float(target_pressure),
        "stages": stage_data,
    }, indent=2, default=str))

    return {
        "status": "ok",
        "n_stages": len([d for d in stage_data.values() if d.get("log")]),
        "stages": stage_data,
        "dashboard_png": str(png),
        "report_json": str(json_path),
    }


# --- Bond-length sanity ---------------------------------------------------

def bond_length_sanity(
    run_dir: str,
    *,
    sel: str = "protein",
    z_threshold: float = 5.0,
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> Dict[str, Any]:
    """For each frame, compute bond lengths within ``sel`` and flag any that
    deviate from the per-bond mean by more than ``z_threshold`` standard
    deviations. Points to broken or stretched bonds (mis-built systems,
    ring-puckering issues, etc.)."""
    from htmd_mcp.postprocess import _load_traj

    mol, *_ = _load_traj(run_dir, psf=psf, pdb=pdb, dcd=dcd)
    bonds = mol.bonds  # (n_bonds, 2)
    if bonds is None or len(bonds) == 0:
        return {"status": "error", "error": "no bonds in PSF"}

    sel_mask = mol.atomselect(sel)
    keep_bond = sel_mask[bonds[:, 0]] & sel_mask[bonds[:, 1]]
    bonds = bonds[keep_bond]
    if len(bonds) == 0:
        return {"status": "error",
                "error": f"no bonds found inside selection {sel!r}"}

    coords = mol.coords  # (N, 3, F)
    a = coords[bonds[:, 0]]  # (B, 3, F)
    b = coords[bonds[:, 1]]
    diff = a - b
    lengths = np.sqrt(np.sum(diff ** 2, axis=1))  # (B, F)

    means = lengths.mean(axis=1)
    stds = lengths.std(axis=1)
    z = np.zeros_like(lengths)
    nonzero = stds > 1e-6
    z[nonzero] = (lengths[nonzero] - means[nonzero, None]) / stds[nonzero, None]
    bad_mask = np.abs(z) > float(z_threshold)
    n_bad_per_frame = bad_mask.sum(axis=0)

    out = _ensure_outdir(run_dir)
    csv_path = out / "bond_lengths_qa.csv"
    rows = [[i, int(n)] for i, n in enumerate(n_bad_per_frame)]
    from htmd_mcp.postprocess import _write_csv
    _write_csv(csv_path, ["frame", "n_bonds_outside_threshold"], rows)

    # Top offenders
    worst_bond_max_z = np.max(np.abs(z), axis=1)
    worst_idx = np.argsort(worst_bond_max_z)[-10:][::-1]
    worst = []
    for bi in worst_idx:
        i1, i2 = bonds[bi]
        worst.append({
            "atom1": f"{mol.resname[i1]}{mol.resid[i1]}:{mol.name[i1]}",
            "atom2": f"{mol.resname[i2]}{mol.resid[i2]}:{mol.name[i2]}",
            "max_abs_z": float(worst_bond_max_z[bi]),
            "mean_length_A": float(means[bi]),
            "std_length_A": float(stds[bi]),
        })

    return {
        "status": "ok",
        "n_bonds_in_selection": int(len(bonds)),
        "n_frames": int(lengths.shape[1]),
        "z_threshold": float(z_threshold),
        "max_abs_z_overall": float(np.max(np.abs(z))),
        "n_bonds_ever_above_threshold": int(np.sum(np.any(bad_mask, axis=1))),
        "csv": str(csv_path),
        "top_offenders": worst,
    }
