"""Build a protein + DNA/RNA system for MD.

Two input modes (mirroring ``build_protein_protein_complex``):

* **Single-PDB mode** — pass ``protein_pdb`` only and let the function
  auto-split into protein and nucleic sub-systems via atomselects.
* **Two-PDB mode** — pass both ``protein_pdb`` and ``nucleic_pdb``.

The protein gets ``systemPrepare`` (propKa) and ``autoSegment`` with
basename ``P``; the nucleic acid is segmented separately with basename
``N`` (so a duplex becomes ``N0``/``N1``). ``systemPrepare`` is NOT run on
the nucleic acid — propKa's residue catalog is protein-specific and would
strip 5'/3' terminal phosphates or mis-protonate ribose hydroxyls.

CHARMM build uses the standard force field plus ``top_all36_na.rtf``
(which is *not* in HTMD's ``defaultTopo()`` — added explicitly here). The
corresponding ``par_all36_na.prm`` is already staged for NAMD3 by
``stage_charmm_parameters``.

DNA handling
------------
CHARMM stores nucleic acids as RNA-like residues (ADE/GUA/CYT/THY/URA)
and converts to DNA via ``DEOX``/``DEO5`` patches. PDB inputs use
``DA/DG/DC/DT/DU`` for DNA; we rename them to the CHARMM short forms and
emit a ``patch DEO5 <seg>:<5'-resid>`` plus ``patch DEOX <seg>:<resid>``
for every other DNA residue. RNA needs no patches — the resnames
(A/G/C/U) are already aliased by HTMD. ``5TER``/``3TER`` terminal caps
are applied to nucleic segments by default (free-strand hydroxyl ends);
override via ``nucleic_caps`` for phosphate or methylated termini.
"""

from __future__ import annotations

import logging
import os
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)

# CHARMM nucleic-acid topology is shipped with HTMD but not registered in
# defaultTopo(); we add it explicitly when there's nucleic in the system.
NA_TOPO = "top/top_all36_na.rtf"

# PDB DNA resname → CHARMM short form. RNA resnames (A/G/C/U) are already
# aliased to ADE/GUA/CYT/URA by HTMD's _printAliases.
DNA_RESNAME_MAP = {
    "DA": "ADE",
    "DG": "GUA",
    "DC": "CYT",
    "DT": "THY",
    "DU": "URA",
}


def _load_nucleic(source: str, selection: Optional[str]):
    """Load and (optionally) narrow to nucleic via VMD-style selection."""
    from moleculekit.molecule import Molecule

    mol = Molecule(source)
    if selection:
        mol.filter(selection)
    return mol


def _detect_and_rename_dna(nuc) -> List[Tuple[str, int, str]]:
    """Rename DNA resnames (DA/DG/DC/DT/DU) to CHARMM short forms in place.
    Returns a list of (segid, resid, insertion) tuples for every DNA residue
    so the caller can generate DEOX/DEO5 patches after autoSegment.

    Insertion code is included because PDB residues with the same resid but
    different insertion codes are distinct in psfgen (``patch DEOX P:5A``)."""
    import numpy as np

    dna_atom_mask = np.isin(nuc.resname, list(DNA_RESNAME_MAP.keys()))
    if not dna_atom_mask.any():
        return []

    # Capture per-residue identity BEFORE rename (to skip duplicate atoms,
    # group by chain+resid+insertion since segid hasn't been assigned yet).
    chains = nuc.chain
    resids = nuc.resid
    insertions = nuc.insertion if hasattr(nuc, "insertion") else \
        np.array([""] * nuc.numAtoms)

    seen = set()
    dna_residues: List[Tuple[str, int, str]] = []
    for i in np.where(dna_atom_mask)[0]:
        key = (str(chains[i]), int(resids[i]), str(insertions[i]))
        if key not in seen:
            seen.add(key)
            dna_residues.append(key)

    # Now rename. One bulk per source resname is faster than per-atom.
    for old, new in DNA_RESNAME_MAP.items():
        nuc.set("resname", new, sel=f"resname {old}")

    return dna_residues


def _make_deoxy_patches(nuc, dna_pre_segment: List[Tuple[str, int, str]]
                        ) -> List[str]:
    """After autoSegment, build ``patch DEO5 <seg>:<resid>`` for the 5'-most
    DNA residue per segment and ``patch DEOX <seg>:<resid>`` for the rest.

    The 5' end is identified as the residue with the lowest resid in each
    segment. (Standard PDB convention numbers DNA strands 5'→3' increasing.
    For inputs that violate this, pass the patches list explicitly via
    ``extra_patches``.)"""
    import numpy as np

    if not dna_pre_segment:
        return []

    # Re-key DNA residues by their NEW segid (post-autoSegment) using
    # (chain, resid, insertion) → segid mapping.
    chains = nuc.chain
    resids = nuc.resid
    segids = nuc.segid
    insertions = nuc.insertion if hasattr(nuc, "insertion") else \
        np.array([""] * nuc.numAtoms)

    key_to_segid: Dict[Tuple[str, int, str], str] = {}
    for i in range(nuc.numAtoms):
        key = (str(chains[i]), int(resids[i]), str(insertions[i]))
        if key not in key_to_segid:
            key_to_segid[key] = str(segids[i])

    # Group DNA residues by their assigned segid
    by_seg: Dict[str, List[Tuple[int, str]]] = {}
    for chain, resid, insertion in dna_pre_segment:
        seg = key_to_segid.get((chain, resid, insertion))
        if seg is None:
            logger.warning(
                "DNA residue %s:%d%s lost its segid after autoSegment; "
                "skipping deoxy patch — DNA build will fail.",
                chain, resid, insertion,
            )
            continue
        by_seg.setdefault(seg, []).append((resid, insertion))

    patches: List[str] = []
    for seg, items in by_seg.items():
        items.sort(key=lambda t: (t[0], t[1]))
        first_resid, first_ins = items[0]
        first_token = f"{seg}:{first_resid}{first_ins}".rstrip(":")
        patches.append(f"patch DEO5 {first_token}")
        for resid, ins in items[1:]:
            tok = f"{seg}:{resid}{ins}".rstrip(":")
            patches.append(f"patch DEOX {tok}")
    return patches


def build_protein_nucleic(
    protein_pdb: str,
    *,
    nucleic_pdb: Optional[str] = None,
    protein_selection: Optional[str] = None,
    nucleic_selection: Optional[str] = None,
    keep_selection_protein: Optional[str] = None,
    remove_selection_protein: Optional[str] = None,
    keep_selection_nucleic: Optional[str] = None,
    remove_selection_nucleic: Optional[str] = None,
    protein_segid_basename: str = "P",
    nucleic_segid_basename: str = "N",
    forcefield: str = "charmm",
    pad: float = 12.0,
    saltconc: float = 0.15,
    cation: str = "SOD",
    anion: str = "CLA",
    pH: float = 7.4,
    disulfide: Optional[List[List[str]]] = None,
    nucleic_caps: Optional[Dict[str, List[str]]] = None,
    extra_patches: Optional[List[str]] = None,
    outdir: str = "build_nucleic",
) -> Dict[str, Any]:
    """Build a protein + DNA/RNA complex in a water box.

    Parameters
    ----------
    protein_pdb
        Path or 4-letter PDB ID. Holds both partners in single-PDB mode.
    nucleic_pdb
        Optional second input. If given, two-PDB mode (each partner from
        its own file).
    protein_selection / nucleic_selection
        VMD-style selections. In single-PDB mode they default to the safe
        ``protein`` / ``nucleic`` partitions, which already discriminate
        amino acids from DNA/RNA correctly. In two-PDB mode you generally
        don't need them; pass selections only when each input contains
        more than just the partner you want.
    keep_selection_* / remove_selection_*
        Optional per-partner cleanup applied after the partition split.
    protein_segid_basename, nucleic_segid_basename
        autoSegment basenames so segids don't collide. Default ``P*`` /
        ``N*`` is sufficient for any real-world system.
    forcefield, pad, saltconc, cation, anion, pH, disulfide
        Standard build options. Note: nucleic acids carry a phosphate at
        each non-terminal residue (charge -1 each), so ionization counts
        will be larger than equivalent-volume waterboxes.
    nucleic_caps
        Optional dict {nucleic_segid: ["first 5TER", "last 3TER"]}. Default:
        free hydroxyl ends (5TER + 3TER) for every nucleic segment. Use
        ``["first 5PHO", "last 3PHO"]`` for phosphorylated termini.
    extra_patches
        Optional list of additional psfgen patch strings (e.g.
        ``"patch DISU P0:5 P0:55"``). Inter-strand crosslinks, methylation
        patches, etc. live here.
    """
    if forcefield != "charmm":
        raise NotImplementedError("only CHARMM is wired in this build")

    from moleculekit.tools.preparation import systemPrepare
    from moleculekit.tools.autosegment import autoSegment
    from htmd.builder.solvate import solvate
    from htmd.builder import charmm

    outdir = os.path.abspath(outdir)
    os.makedirs(outdir, exist_ok=True)

    # --- 1. Resolve inputs ---------------------------------------------------
    two_pdb_mode = nucleic_pdb is not None
    if two_pdb_mode:
        prot_sel = protein_selection or "protein"
        nuc_sel = nucleic_selection or "nucleic"
    else:
        prot_sel = protein_selection or "protein"
        nuc_sel = nucleic_selection or "nucleic"

    # --- 2. Load + clean protein --------------------------------------------
    from moleculekit.molecule import Molecule
    prot = Molecule(protein_pdb)
    prot.filter(prot_sel)
    if keep_selection_protein:
        prot.filter(keep_selection_protein)
    if remove_selection_protein:
        prot.remove(remove_selection_protein)
    if int(np.sum(prot.atomselect("protein"))) == 0:
        raise ValueError(
            f"protein has 0 atoms after selection={prot_sel!r}. Did you mean "
            "two-PDB mode (set nucleic_pdb)?"
        )

    # --- 3. Load + clean nucleic --------------------------------------------
    nuc_source = nucleic_pdb if two_pdb_mode else protein_pdb
    nuc = _load_nucleic(nuc_source, nuc_sel)
    if keep_selection_nucleic:
        nuc.filter(keep_selection_nucleic)
    if remove_selection_nucleic:
        nuc.remove(remove_selection_nucleic)
    if int(np.sum(nuc.atomselect("nucleic"))) == 0:
        raise ValueError(
            f"nucleic has 0 atoms after selection={nuc_sel!r}. Did you mean "
            "two-PDB mode (set nucleic_pdb)?"
        )

    # --- 4. Prepare protein only --------------------------------------------
    # propKa is amino-acid-specific; we explicitly do NOT run systemPrepare
    # on the nucleic copy (it would strip terminal phosphates etc.).
    prot = systemPrepare(prot, pH=float(pH))
    prot = autoSegment(prot, sel="protein", basename=protein_segid_basename)
    prot.set("segid", "W", sel="water")
    prot.set("segid", "I", sel="ions")

    # --- 5. Detect DNA residues and rename to CHARMM short forms -----------
    # Must happen BEFORE autoSegment so we can pre-record residue identity
    # via (chain, resid, insertion); after autoSegment we recover the
    # post-segmented segid for each DNA residue and emit DEO5/DEOX patches.
    dna_pre_segment = _detect_and_rename_dna(nuc)

    # --- 6. Segment nucleic ------------------------------------------------
    nuc = autoSegment(nuc, sel="nucleic", basename=nucleic_segid_basename)
    # Drop crystal waters/ions in nuc; they'll be re-solvated below. (If
    # there are crystal Mg2+ etc. that the user wants, they should pass
    # keep_selection_nucleic to retain them.)
    nuc.filter("nucleic")

    deoxy_patches = _make_deoxy_patches(nuc, dna_pre_segment)

    protein_segids = sorted(set(prot.segid[
        prot.atomselect("protein")].tolist()))
    nucleic_segids = sorted(set(nuc.segid[
        nuc.atomselect("nucleic")].tolist()))

    # --- 7. Combine + solvate ------------------------------------------------
    mol = prot.copy()
    mol.append(nuc)
    mol.center()
    solv = solvate(mol, pad=float(pad))

    # --- 8. Build caps for nucleic segments + collect patches --------------
    # HTMD's _defaultCaps applies "first none, last none" to non-protein
    # segments, which is wrong for DNA/RNA — they need 5TER/3TER (or 5PHO/
    # 3PHO) to terminate the strand correctly.
    caps: Dict[str, List[str]] = {}
    if nucleic_caps:
        caps.update(nucleic_caps)
    for seg in nucleic_segids:
        if seg not in caps:
            caps[seg] = ["first 5TER", "last 3TER"]
    # Protein segments fall back to HTMD's default (ACE/CT3) since we leave
    # them out of `caps` — but charmm.build's cap default fills in only
    # MISSING entries when caps is provided as a dict. Add explicit defaults
    # for protein segments so we don't accidentally drop their caps.
    from htmd.builder.charmm import _defaultCaps
    default_caps = _defaultCaps(solv)
    for seg, c in default_caps.items():
        caps.setdefault(seg, c)

    all_patches = list(deoxy_patches)
    if extra_patches:
        all_patches.extend(extra_patches)

    # --- 9. CHARMM build with NA topology added ----------------------------
    topo = list(charmm.defaultTopo()) + [NA_TOPO]
    built = charmm.build(
        solv,
        topo=topo,
        outdir=outdir,
        caps=caps,
        patches=all_patches,
        saltconc=float(saltconc),
        saltcation=cation,
        saltanion=anion,
        disulfide=disulfide,
    )

    prot_segid_sel = "segid " + " ".join(protein_segids) if protein_segids else ""
    nuc_segid_sel = "segid " + " ".join(nucleic_segids) if nucleic_segids else ""

    return {
        "status": "ok",
        "outdir": outdir,
        "forcefield": forcefield,
        "two_pdb_mode": two_pdb_mode,
        "protein_segids": protein_segids,
        "nucleic_segids": nucleic_segids,
        "protein_selection": prot_segid_sel,
        "nucleic_selection": nuc_segid_sel,
        "n_atoms": int(built.numAtoms),
        "n_protein_atoms": int(np.sum(built.atomselect("protein"))),
        "n_nucleic_atoms": int(np.sum(built.atomselect("nucleic"))),
        "n_water_atoms": int(np.sum(built.atomselect("water"))),
        "n_ions": int(np.sum(built.atomselect("ions"))),
        "n_protein_residues": int(np.sum(built.atomselect(
            "name CA and protein"))),
        "n_nucleic_residues": int(np.sum(built.atomselect(
            "(name P or name C1') and nucleic"))),
        "n_dna_residues_input": len(dna_pre_segment),
        "n_deoxy_patches_emitted": sum(
            1 for p in deoxy_patches if p.startswith("patch DEO")),
        "salt_concentration": float(saltconc),
        "files": {
            "pdb": os.path.join(outdir, "structure.pdb"),
            "psf": os.path.join(outdir, "structure.psf"),
        },
    }
