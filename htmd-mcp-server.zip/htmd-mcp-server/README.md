# htmd-mcp — MD simulation MCP server

An MCP (stdio) server that wraps **HTMD / moleculekit + NAMD3 + SwissParam** for
building, running, and analysing molecular dynamics systems: protein in water,
protein–ligand, protein–protein, protein–nucleic acid, and protein–membrane.

## What's in this archive

```
main.py                  MCP server — tool definitions (FastMCP), shells out to functions.py
functions.py             CLI dispatcher: `python functions.py <fn> '<json args>'`
htmd_mcp/                implementation package
  prep_*.py              system builders (waterbox, ligand, multiligand, complex, nucleic, membrane)
  namd3_writer.py        writes minimize/equilibrate/produce NAMD configs from templates/
  namd3_runner.py        launches and monitors NAMD3
  postprocess*.py        RMSD, RMSF, SASA, H-bonds, contacts, secondary structure, Rg
  pca_fel.py             PCA, free energy landscape, KDE, clustering
  mm_pbsa.py             MM/PBSA binding free energy
  compare.py             multi-run comparison
  swissparam.py          ligand parametrisation via the SwissParam web service
  visualization.py       PyMOL/ffmpeg movie + dashboard rendering
  qa.py                  QA report, bond-length sanity checks
  templates/             CHARMM NAMD config templates
  tools/                 lipid PDB generation helper
requirements.txt         pinned pip layer + notes on conda-only packages
install_instructions.txt original conda setup notes
```

Not included: MD trajectories and other work products from the author's runs.
This is the server only.

## Prerequisites

These are **not** in the archive and must exist on the target machine:

| Dependency | Notes |
|---|---|
| conda env with the HTMD stack | Python 3.10 + `htmd`, `moleculekit`, `rdkit`, `openbabel`, optionally `pymol-open-source`, `ffmpeg` |
| **NAMD3** | GPU build recommended; the server passes `+devices 0` |
| network access | SwissParam (`https://www.swissparam.ch:8443`) for ligand parametrisation; RCSB for PDB fetch |

## Install

```bash
# 1. conda stack (Acellera + conda-forge channels)
conda create -n htmd python=3.10 -c acellera -c conda-forge \
    htmd moleculekit rdkit openbabel pymol-open-source
conda activate htmd

# 2. MCP layer + pinned libraries
pip install -r requirements.txt

# 3. sanity check
python -c "import htmd, mcp; print('ok')"
```

Alternatively, restore a prebuilt env with `conda-pack` (extract, then run
`conda-unpack`) instead of steps 1–2.

## Register with an MCP client

Claude Code / Claude Desktop config:

```json
{
  "mcpServers": {
    "htmd-mcp": {
      "type": "stdio",
      "command": "/path/to/envs/htmd/bin/python",
      "args": ["/path/to/htmd-mcp-server/main.py"],
      "env": {
        "HTMD_PYTHON": "/path/to/envs/htmd/bin/python",
        "NAMD3_BIN": "/path/to/namd3"
      }
    }
  }
}
```

## Environment variables — set these

The source carries hardcoded defaults pointing at the original author's
machine. Every one is overridable; set the ones relevant to your setup.

| Variable | Default in source | What it is |
|---|---|---|
| `HTMD_PYTHON` | `/home/akshay/anaconda3/envs/htmd/bin/python` | interpreter `main.py` uses to run `functions.py` |
| `NAMD3_BIN` | `/usr/local/bin/namd3` | NAMD3 executable |
| `PSFGEN_BIN` | `/usr/local/bin/psfgen` | psfgen, for lipid PDB generation |
| `OBABEL_BIN` | auto-resolved (PATH, then next to `sys.executable`) | Open Babel |
| `PYMOL_BIN` | `/home/achuth-chandrasekhar/miniconda3/envs/htmd/bin/pymol` | PyMOL, for rendering |
| `FFMPEG_BIN` | `/home/achuth-chandrasekhar/miniconda3/envs/htmd/bin/ffmpeg` | ffmpeg, for movies |
| `SWISSPARAM_BASE` | `https://www.swissparam.ch:8443` | SwissParam endpoint |
| `HTMD_MCP_SWISSPARAM_CACHE` | `~/.cache/htmd_mcp/swissparam` | parametrisation cache |
| `HTMD_MCP_LOG` | `INFO` | log level |

Setting `HTMD_PYTHON` and `NAMD3_BIN` is enough for most systems; add
`PYMOL_BIN` / `FFMPEG_BIN` only if you use the visualization tools.

## Direct CLI use (without an MCP client)

Every tool is reachable through the dispatcher:

```bash
python functions.py fetch_pdb '{"pdb_id": "1UBQ", "out_dir": "./work"}'
```

## Known quirks

- Several `build_*` tools print an HTMD chain report to stdout before the JSON
  payload, so a strict MCP client may report "non-JSON stdout" even on success —
  the real result is in the stdout tail.
- Analysis tools load `structure.psf` from `run_dir` and need its atom count to
  match the trajectory. `wrap_and_align` writes a protein(+ligand) stripped
  trajectory, so build a matching subset PSF before running analyses on it.
