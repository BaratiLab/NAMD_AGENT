"""htmd-md MCP server.

Each tool is a thin async wrapper that dispatches to ``functions.py`` running
under the ``htmd`` conda env, mirroring the pattern in the OPTIMADE-AdsorbML
MCP server. All tools return a JSON string.
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("htmd-md")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("htmd_md_mcp")

PROJECT_ROOT = Path(__file__).resolve().parent
HTMD_PYTHON = os.environ.get(
    "HTMD_PYTHON",
    "/home/akshay/anaconda3/envs/htmd/bin/python",
)
NAMD3_BIN = os.environ.get("NAMD3_BIN", "/usr/local/bin/namd3")


def safe_json_dumps(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, indent=2, default=str)


def _run_function(fn_name: str, args: Dict[str, Any], *,
                  timeout: Optional[int] = 3600) -> str:
    """Run ``functions.py <fn>`` with a JSON args blob and return stdout JSON.

    timeout=None disables the timeout (used for long NAMD3 runs).
    """
    script = str(PROJECT_ROOT / "functions.py")
    cmd = [HTMD_PYTHON, script, fn_name, json.dumps(args)]

    env = os.environ.copy()
    env.setdefault("NAMD3_BIN", NAMD3_BIN)
    env.setdefault("PYTHONPATH", str(PROJECT_ROOT))

    logger.info("dispatch %s args=%s", fn_name, args)

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=str(PROJECT_ROOT),
            env=env,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        return safe_json_dumps({"status": "error", "error": "timeout",
                                "fn": fn_name})

    if result.returncode != 0 and not result.stdout.strip():
        return safe_json_dumps({
            "status": "error",
            "error": f"subprocess returncode={result.returncode}",
            "stderr_tail": result.stderr[-2000:],
            "fn": fn_name,
        })

    out = result.stdout.strip()
    # Validate JSON; if functions.py crashed, surface stderr
    try:
        json.loads(out)
        return out
    except Exception:
        return safe_json_dumps({
            "status": "error",
            "error": "non-JSON stdout from functions.py",
            "stdout_tail": out[-2000:],
            "stderr_tail": result.stderr[-2000:],
            "fn": fn_name,
        })


# --- Common prep tools ------------------------------------------------------

@mcp.tool()
async def fetch_pdb(pdb_id_or_path: str, outdir: str = "fetched") -> str:
    """Resolve a PDB to a local file. Accepts a 4-letter RCSB ID or an existing
    path. Returns the absolute local path plus chain summary."""
    return _run_function("fetch_pdb", {
        "pdb_id_or_path": pdb_id_or_path, "outdir": outdir
    })


@mcp.tool()
async def inspect_structure(path: str) -> str:
    """Audit a PDB: chains, segids, ligand resnames, water/ion counts, gaps.
    Use this before deciding cleanup/preparation steps."""
    return _run_function("inspect_structure", {"path": path})


@mcp.tool()
async def prepare_protein(
    path: str,
    pH: float = 7.4,
    hydrophobic_thickness: Optional[float] = None,
    outdir: str = "prepared",
    out_name: str = "prepared.pdb",
) -> str:
    """Run moleculekit.systemPrepare: protonation states (propKa), H-bond
    optimization, missing-atom filling. For membrane proteins set
    hydrophobic_thickness to ~2*OPM thickness."""
    return _run_function("prepare_protein", {
        "path": path, "pH": pH,
        "hydrophobic_thickness": hydrophobic_thickness,
        "outdir": outdir, "out_name": out_name,
    })


@mcp.tool()
async def auto_segment(
    path: str,
    sel: str = "protein",
    outdir: str = "segmented",
    out_name: str = "segmented.pdb",
) -> str:
    """Assign segids automatically using HTMD's autoSegment."""
    return _run_function("auto_segment", {
        "path": path, "sel": sel, "outdir": outdir, "out_name": out_name,
    })


@mcp.tool()
async def clean_structure(
    path: str,
    keep_selection: Optional[str] = None,
    remove_selection: Optional[str] = None,
    outdir: str = "cleaned",
    out_name: str = "cleaned.pdb",
) -> str:
    """Filter / remove atoms from a structure with VMD-style atomselects."""
    return _run_function("clean_structure", {
        "path": path,
        "keep_selection": keep_selection,
        "remove_selection": remove_selection,
        "outdir": outdir,
        "out_name": out_name,
    })


# --- System builders --------------------------------------------------------

@mcp.tool()
async def build_protein_waterbox(
    input_pdb: str,
    forcefield: str = "charmm",
    water_model: str = "tip3p",
    pad: float = 12.0,
    saltconc: float = 0.15,
    cation: str = "SOD",
    anion: str = "CLA",
    pH: float = 7.4,
    disulfide: Optional[List[List[str]]] = None,
    keep_selection: Optional[str] = None,
    remove_selection: Optional[str] = None,
    outdir: str = "build_waterbox",
) -> str:
    """Prepare → autoSegment → solvate → CHARMM/AMBER build a soluble protein.
    Returns build dir with structure.psf/.pdb (CHARMM) or .prmtop/.pdb (AMBER)."""
    return _run_function("build_protein_waterbox", {
        "input_pdb": input_pdb,
        "forcefield": forcefield,
        "water_model": water_model,
        "pad": pad,
        "saltconc": saltconc,
        "cation": cation,
        "anion": anion,
        "pH": pH,
        "disulfide": disulfide,
        "keep_selection": keep_selection,
        "remove_selection": remove_selection,
        "outdir": outdir,
    }, timeout=None)


@mcp.tool()
async def list_lipids() -> str:
    """List the lipids HTMD's MembraneBuilder can place natively (POPC, POPE,
    CHL1 by default). Returns the lipid_dir path so users can extend it."""
    return _run_function("list_lipids", {})


@mcp.tool()
async def build_protein_membrane(
    input_pdb: str,
    use_opm: bool = True,
    chain_keep: Optional[str] = None,
    keep_selection: Optional[str] = None,
    remove_selection: Optional[str] = None,
    membrane_xy: List[float] = [80.0, 80.0],
    upper_lipids: Optional[Dict[str, float]] = None,
    lower_lipids: Optional[Dict[str, float]] = None,
    waterbuff: float = 20.0,
    saltconc: float = 0.15,
    cation: str = "SOD",
    anion: str = "CLA",
    pH: float = 7.4,
    forcefield: str = "charmm",
    outdir: str = "build_membrane",
) -> str:
    """Embed a protein in a lipid bilayer + water + ions.

    By default fetches the OPM-aligned structure for ``input_pdb`` (4-char ID),
    then prepares, embeds in a buildMembrane bilayer of size membrane_xy with
    POPC default, solvates above/below with ``waterbuff`` Å of water, and
    builds with CHARMM36m + lipid + water/ions force fields.

    For monomers from multimeric crystals pass ``chain_keep="B"`` etc."""
    return _run_function("build_protein_membrane", {
        "input_pdb": input_pdb,
        "use_opm": use_opm,
        "chain_keep": chain_keep,
        "keep_selection": keep_selection,
        "remove_selection": remove_selection,
        "membrane_xy": membrane_xy,
        "upper_lipids": upper_lipids,
        "lower_lipids": lower_lipids,
        "waterbuff": waterbuff,
        "saltconc": saltconc,
        "cation": cation,
        "anion": anion,
        "pH": pH,
        "forcefield": forcefield,
        "outdir": outdir,
    }, timeout=None)


@mcp.tool()
async def build_protein_protein_complex(
    receptor_pdb: str,
    partner_pdb: Optional[str] = None,
    receptor_selection: Optional[str] = None,
    partner_selection: Optional[str] = None,
    keep_selection_receptor: Optional[str] = None,
    remove_selection_receptor: Optional[str] = None,
    keep_selection_partner: Optional[str] = None,
    remove_selection_partner: Optional[str] = None,
    receptor_segid_basename: str = "R",
    partner_segid_basename: str = "L",
    separation: Optional[float] = None,
    forcefield: str = "charmm",
    water_model: str = "tip3p",
    pad: float = 12.0,
    saltconc: float = 0.15,
    cation: str = "SOD",
    anion: str = "CLA",
    pH: float = 7.4,
    disulfide: Optional[List[List[str]]] = None,
    outdir: str = "build_complex",
) -> str:
    """Build a protein-protein complex in a water box for MD.

    Two input modes. Single-PDB mode: pass receptor_pdb only and split it via
    receptor_selection / partner_selection (defaults to chain A / chain B
    when neither selection is given). Two-PDB mode: pass both receptor_pdb
    and partner_pdb (each can be a path or a 4-letter PDB ID).

    Each partner is run through systemPrepare separately and through
    autoSegment with a distinct basename (R0/R1/... vs L0/L1/...) so segids
    don't collide. Inter-chain disulfides are auto-detected by charmm.build.

    Set separation=<float> in Å to translate the partner along +X past the
    receptor's extent for an unbound starting pose (binding-pathway studies).
    Leave separation=None to keep the input pose (co-crystal/docked).

    Returns the build dir plus receptor_selection / partner_selection
    strings (segid-based) you should pass to interface_contacts,
    interface_rmsd, and buried_sasa during analysis."""
    return _run_function("build_protein_protein_complex", {
        "receptor_pdb": receptor_pdb,
        "partner_pdb": partner_pdb,
        "receptor_selection": receptor_selection,
        "partner_selection": partner_selection,
        "keep_selection_receptor": keep_selection_receptor,
        "remove_selection_receptor": remove_selection_receptor,
        "keep_selection_partner": keep_selection_partner,
        "remove_selection_partner": remove_selection_partner,
        "receptor_segid_basename": receptor_segid_basename,
        "partner_segid_basename": partner_segid_basename,
        "separation": separation,
        "forcefield": forcefield,
        "water_model": water_model,
        "pad": pad,
        "saltconc": saltconc,
        "cation": cation,
        "anion": anion,
        "pH": pH,
        "disulfide": disulfide,
        "outdir": outdir,
    }, timeout=None)


@mcp.tool()
async def build_protein_nucleic(
    protein_pdb: str,
    nucleic_pdb: Optional[str] = None,
    protein_selection: Optional[str] = None,
    nucleic_selection: Optional[str] = None,
    keep_selection_protein: Optional[str] = None,
    remove_selection_protein: Optional[str] = None,
    keep_selection_nucleic: Optional[str] = None,
    remove_selection_nucleic: Optional[str] = None,
    protein_segid_basename: str = "P",
    nucleic_segid_basename: str = "N",
    forcefield: str = "charmm",
    pad: float = 12.0,
    saltconc: float = 0.15,
    cation: str = "SOD",
    anion: str = "CLA",
    pH: float = 7.4,
    disulfide: Optional[List[List[str]]] = None,
    nucleic_caps: Optional[Dict[str, List[str]]] = None,
    extra_patches: Optional[List[str]] = None,
    outdir: str = "build_nucleic",
) -> str:
    """Build a protein + DNA/RNA complex in a water box.

    Single-PDB mode: omit nucleic_pdb; the function partitions via the
    'protein' / 'nucleic' atomselects (overridable). Two-PDB mode: pass
    both inputs (each a path or 4-letter PDB ID).

    Protein gets systemPrepare + autoSegment with basename 'P' (P0/P1/...).
    Nucleic gets autoSegment with basename 'N' (N0/N1/...; a duplex DNA
    typically becomes two strands). systemPrepare is intentionally not run
    on the nucleic copy — propKa would mis-protonate sugars/phosphates.

    The CHARMM build adds top_all36_na.rtf to defaultTopo (HTMD doesn't
    register it by default). par_all36_na.prm is already staged for NAMD3
    by stage_charmm_parameters. Returns protein_selection /
    nucleic_selection segid strings for downstream analysis."""
    return _run_function("build_protein_nucleic", {
        "protein_pdb": protein_pdb,
        "nucleic_pdb": nucleic_pdb,
        "protein_selection": protein_selection,
        "nucleic_selection": nucleic_selection,
        "keep_selection_protein": keep_selection_protein,
        "remove_selection_protein": remove_selection_protein,
        "keep_selection_nucleic": keep_selection_nucleic,
        "remove_selection_nucleic": remove_selection_nucleic,
        "protein_segid_basename": protein_segid_basename,
        "nucleic_segid_basename": nucleic_segid_basename,
        "forcefield": forcefield,
        "pad": pad,
        "saltconc": saltconc,
        "cation": cation,
        "anion": anion,
        "pH": pH,
        "disulfide": disulfide,
        "nucleic_caps": nucleic_caps,
        "extra_patches": extra_patches,
        "outdir": outdir,
    }, timeout=None)


@mcp.tool()
async def swissparam_health() -> str:
    """Ping the Swiss-Param server to confirm it is reachable. Returns
    {"ok": true} if reachable."""
    return _run_function("swissparam_health", {})


@mcp.tool()
async def fetch_ligand_from_rcsb(
    ligand_id: str,
    outdir: str = "ligands",
    output_format: str = "mol2",
    add_hs: bool = True,
    overwrite: bool = False,
) -> str:
    """Pull a ligand from the RCSB chemical-component dictionary by 3-letter
    PDB code (BEN, NAG, ATP, ...). Tries <ID>_ideal.sdf first, falls back to
    <ID>.sdf, then converts to mol2 with explicit Hs and Gasteiger charges
    via OpenBabel. Returns paths to the SDF and mol2."""
    return _run_function("fetch_ligand_from_rcsb", {
        "ligand_id": ligand_id,
        "outdir": outdir,
        "output_format": output_format,
        "add_hs": add_hs,
        "overwrite": overwrite,
    })


@mcp.tool()
async def prepare_ligand_mol2(
    ligand_input: str,
    output: Optional[str] = None,
    input_format: Optional[str] = None,
    add_hs: bool = True,
    embed_3d_if_missing: bool = True,
    compute_charges: bool = True,
    name: str = "LIG",
) -> str:
    """Convert any ligand input (SMILES string, SDF, mol2, PDB, CIF) into a
    Swiss-Param-ready mol2: explicit hydrogens, 3D coordinates, Gasteiger
    charges. SMILES → 3D via RDKit ETKDGv3 + MMFF94 optimization."""
    return _run_function("prepare_ligand_mol2", {
        "ligand_input": ligand_input,
        "output": output,
        "input_format": input_format,
        "add_hs": add_hs,
        "embed_3d_if_missing": embed_3d_if_missing,
        "compute_charges": compute_charges,
        "name": name,
    })


@mcp.tool()
async def parametrize_ligand(
    ligand_input: str,
    ligand_resname: str = "LIG",
    method: str = "swissparam",
    outdir: str = "lig_params",
    refresh: bool = False,
) -> str:
    """Generate CHARMM topology + parameters for a small molecule.

    Currently uses Swiss-Param (CGenFF-style atom types). Input must be a
    mol2 file with all hydrogens and 3D coordinates. Results are cached by
    file content + resname so re-runs are instant. Returns absolute paths
    to the .rtf, .prm, and .pdb files (resname rewritten to ``ligand_resname``)."""
    return _run_function("parametrize_ligand", {
        "ligand_input": ligand_input,
        "ligand_resname": ligand_resname,
        "method": method,
        "outdir": outdir,
        "refresh": refresh,
    }, timeout=None)


@mcp.tool()
async def build_protein_ligand(
    protein_pdb: str,
    ligand_input: Optional[str] = None,
    ligand_rcsb_id: Optional[str] = None,
    ligand_smiles: Optional[str] = None,
    ligand_resname: str = "LIG",
    parametrize: bool = True,
    parametrize_method: str = "swissparam",
    ligand_rtf: Optional[str] = None,
    ligand_prm: Optional[str] = None,
    ligand_pdb: Optional[str] = None,
    place_at: Optional[List[float]] = None,
    random_far: bool = True,
    pad: float = 12.0,
    saltconc: float = 0.15,
    cation: str = "SOD",
    anion: str = "CLA",
    pH: float = 7.4,
    forcefield: str = "charmm",
    outdir: str = "build_proteinlig",
    seed: Optional[int] = None,
    keep_selection_protein: Optional[str] = None,
    remove_selection_protein: Optional[str] = "resname BEN",
) -> str:
    """Prepare → segment → place ligand → solvate → CHARMM build.

    With parametrize=True, ligand_input must be a mol2 file; we hand it to
    Swiss-Param to generate CGenFF-style CHARMM .rtf/.prm. Otherwise pass
    ligand_rtf + ligand_prm + ligand_pdb directly.

    Default ligand placement is "random_far": rotated randomly and translated
    +X by maxDistance(protein) + 10 Å (unbinding setup). Pass place_at=[x,y,z]
    to position explicitly."""
    return _run_function("build_protein_ligand", {
        "protein_pdb": protein_pdb,
        "ligand_input": ligand_input,
        "ligand_rcsb_id": ligand_rcsb_id,
        "ligand_smiles": ligand_smiles,
        "ligand_resname": ligand_resname,
        "parametrize": parametrize,
        "parametrize_method": parametrize_method,
        "ligand_rtf": ligand_rtf,
        "ligand_prm": ligand_prm,
        "ligand_pdb": ligand_pdb,
        "place_at": place_at,
        "random_far": random_far,
        "pad": pad,
        "saltconc": saltconc,
        "cation": cation,
        "anion": anion,
        "pH": pH,
        "forcefield": forcefield,
        "outdir": outdir,
        "seed": seed,
        "keep_selection_protein": keep_selection_protein,
        "remove_selection_protein": remove_selection_protein,
    }, timeout=None)


@mcp.tool()
async def build_protein_multiligand(
    protein_pdb: str,
    ligands: List[Dict[str, Any]],
    parametrize: bool = True,
    parametrize_method: str = "swissparam",
    pad: float = 12.0,
    saltconc: float = 0.15,
    cation: str = "SOD",
    anion: str = "CLA",
    pH: float = 7.4,
    forcefield: str = "charmm",
    outdir: str = "build_multiligand",
    seed: Optional[int] = None,
    keep_selection_protein: Optional[str] = None,
    remove_selection_protein: Optional[str] = "resname BEN",
) -> str:
    """Prepare protein → place N small molecules → solvate → CHARMM build.

    `ligands` is a list of per-ligand dicts. Each dict needs:
      - one source: ligand_input (mol2 path) | ligand_rcsb_id (3-letter PDB
        chemical-component ID) | ligand_smiles | a pre-built
        (ligand_rtf, ligand_prm, ligand_pdb) triple
      - resname: max 4 chars, MUST be unique across the list
      - copies: int, default 1 (multiple copies share parametrization but
        get distinct segids L0, L1, ...)
      - place_at: optional [x, y, z]; or random_far=True (default if
        place_at not given) which scatters copies past the protein extent
        with a small perpendicular jitter so they don't pile up.

    Each unique ligand input is parametrized once via Swiss-Param (content-
    addressed cache → instant re-runs). All ligand RTFs are passed to
    psfgen via topo; all .prm paths are persisted in extra_params.json so
    NAMD3 staging picks them up automatically.

    Use this for cofactor + drug systems, multi-copy drug screens, or any
    protein + N small-molecule system. For a single ligand prefer
    build_protein_ligand."""
    return _run_function("build_protein_multiligand", {
        "protein_pdb": protein_pdb,
        "ligands": ligands,
        "parametrize": parametrize,
        "parametrize_method": parametrize_method,
        "pad": pad,
        "saltconc": saltconc,
        "cation": cation,
        "anion": anion,
        "pH": pH,
        "forcefield": forcefield,
        "outdir": outdir,
        "seed": seed,
        "keep_selection_protein": keep_selection_protein,
        "remove_selection_protein": remove_selection_protein,
    }, timeout=None)


# --- NAMD3 protocols --------------------------------------------------------

@mcp.tool()
async def setup_minimization(
    build_dir: str,
    run_dir: str,
    steps: int = 5000,
    temperature: float = 300.0,
    timestep_fs: float = 1.0,
    output_freq: int = 100,
    restraint_selection: Optional[str] = "protein and noh and not name CA",
    restraint_k: float = 1.0,
    cuda_soa: bool = True,
    seed: Optional[int] = None,
    forcefield: str = "charmm",
) -> str:
    """Generate a NAMD3 minimization input (min.namd) plus restraint PDB
    inside ``run_dir``. Stages structure files + parameter files automatically.
    Pass ``seed=<int>`` to make the run reproducible (sets NAMD's ``seed``)."""
    return _run_function("setup_minimization", {
        "build_dir": build_dir,
        "run_dir": run_dir,
        "steps": steps,
        "temperature": temperature,
        "timestep_fs": timestep_fs,
        "output_freq": output_freq,
        "restraint_selection": restraint_selection,
        "restraint_k": restraint_k,
        "cuda_soa": cuda_soa,
        "seed": seed,
        "forcefield": forcefield,
    })


@mcp.tool()
async def setup_equilibration(
    prev_dir: str,
    run_dir: str,
    run_ns: float = 1.0,
    temperature: float = 300.0,
    pressure: float = 1.01325,
    timestep_fs: float = 2.0,
    minimize_first: bool = True,
    minimize_steps: int = 1000,
    restraint_selection: str = "protein and name CA",
    restraint_k: float = 1.0,
    restraint_schedule: Optional[List[List[float]]] = None,
    membrane: bool = False,
    margin: float = 2.0,
    output_freq: int = 5000,
    dcd_freq: int = 5000,
    restart_freq: int = 50000,
    cuda_soa: bool = True,
    ensemble: str = "NPT",
    thermostat: str = "langevin",
    barostat: str = "langevin",
    thermostat_period_ps: float = 1.0,
    seed: Optional[int] = None,
    forcefield: str = "charmm",
    resume: bool = False,
    resume_outname: str = "equil",
) -> str:
    """Generate equil.namd in run_dir. Stages structure.psf, parameters/, and
    prev_dir's min.coor/.vel/.xsc as input.coor/.vel/.xsc.

    thermostat: 'langevin' (default) or 'bussi' (NAMD stochastic velocity
    rescaling = Bussi-Donadio-Parrinello; thermostat_period_ps sets the
    coupling time, default 1 ps). barostat (NPT only): 'langevin' (default;
    Langevin piston, Nose-Hoover-Langevin/MTK) or 'berendsen'. NAMD has no
    Parrinello-Rahman barostat — 'langevin' is the closest equivalent.

    The equilibration is a single NAMD3 run that (a) optionally minimizes,
    (b) integrates for run_ns total ns split across restraint_schedule stages
    [(scale, fraction), ...] which scale restraint_k of restraint_selection.
    Default schedule ramps backbone restraints 1.0 → 0.5 → 0.1 → 0.0 in
    equal time blocks.

    ensemble: 'NPT' (default; Langevin piston barostat) or 'NVT' (no
    barostat, fixed box). Use NVT after a long NPT prod when you want
    box-stable dynamics, or as a brief heating step before NPT.

    Set membrane=True for bilayer systems (useFlexibleCell +
    useConstantRatio in NPT). Pass seed for reproducible Langevin streams.

    margin: NAMD ``margin`` (Å). Bump above the default 2.0 (try 4–5) for
    membrane systems if the bilayer packs and you hit ``Periodic cell has
    become too small for original patch grid``. Pairs with the warning
    NAMD itself emits at startup recommending margin >= 4.

    resume: when True, treat ``prev_dir`` as a previous equilibration run
    dir (rather than min) and stage from ``equil.restart.{coor,vel,xsc}``
    so a crashed equilibration can pick up where it left off. Forces
    ``minimize_first=False`` and writes ``equil_resume.namd`` instead of
    overwriting the original ``equil.namd``. Pair with ``run_ns`` and
    ``restraint_schedule`` describing only the *remaining* work."""
    return _run_function("setup_equilibration", {
        "prev_dir": prev_dir,
        "run_dir": run_dir,
        "run_ns": run_ns,
        "temperature": temperature,
        "pressure": pressure,
        "timestep_fs": timestep_fs,
        "minimize_first": minimize_first,
        "minimize_steps": minimize_steps,
        "restraint_selection": restraint_selection,
        "restraint_k": restraint_k,
        "restraint_schedule": restraint_schedule,
        "membrane": membrane,
        "margin": margin,
        "output_freq": output_freq,
        "dcd_freq": dcd_freq,
        "restart_freq": restart_freq,
        "cuda_soa": cuda_soa,
        "ensemble": ensemble,
        "thermostat": thermostat,
        "barostat": barostat,
        "thermostat_period_ps": thermostat_period_ps,
        "seed": seed,
        "forcefield": forcefield,
        "resume": resume,
        "resume_outname": resume_outname,
    })


@mcp.tool()
async def setup_production(
    prev_dir: str,
    run_dir: str,
    run_ns: float = 100.0,
    temperature: float = 300.0,
    pressure: float = 1.01325,
    timestep_fs: float = 4.0,
    hydrogen_mass_repartition: bool = True,
    membrane: bool = False,
    margin: float = 2.0,
    dcd_freq_ps: float = 10.0,
    restart_freq_ps: float = 100.0,
    output_freq: int = 5000,
    cuda_soa: bool = True,
    ensemble: str = "NPT",
    thermostat: str = "langevin",
    barostat: str = "langevin",
    thermostat_period_ps: float = 1.0,
    barostat_period_ps: float = 0.2,
    seed: Optional[int] = None,
    forcefield: str = "charmm",
) -> str:
    """Generate prod.namd in run_dir. Stages prev_dir/equil.coor/.vel/.xsc as
    input.coor/.vel/.xsc. By default applies HMassRepartition (parmed) to the
    PSF so a 4 fs timestep is safe with rigidBonds all.

    thermostat: 'langevin' (default) or 'bussi' (NAMD stochastic velocity
    rescaling = Bussi-Donadio-Parrinello; thermostat_period_ps = coupling time,
    default 1 ps). barostat (NPT only): 'langevin' (default; Langevin piston,
    NHL/MTK) or 'berendsen'. NAMD has no Parrinello-Rahman barostat;
    barostat_period_ps sets the Langevin piston oscillation period (default
    0.2 ps = 200 fs; decay = half the period). Set 1.0 to mirror a paper's
    Parrinello-Rahman tau_P = 1 ps as closely as NAMD allows.

    The template uses ``run N`` (delta from firsttimestep), so the actual
    duration is ``run_ns`` regardless of where equilibration's TS counter
    ended. (Earlier versions emitted ``numsteps`` which NAMD reads as an
    absolute target, leading to truncated runs when chained after equil.)

    dcd_freq_ps and restart_freq_ps are converted into NAMD step counts based
    on timestep_fs.

    ensemble: 'NPT' (default; Langevin piston) or 'NVT' (fixed-box; no
    barostat). Use NVT when you want trajectories without box noise, e.g.
    for normal-mode-style analysis or NMR observable matching, after a
    longer NPT equilibration has set the box. Pass seed for reproducible
    Langevin streams.

    margin: NAMD ``margin`` (Å). Bump above the default 2.0 (try 4–5) for
    membrane systems where the equilibrated bilayer is tightly packed."""
    return _run_function("setup_production", {
        "prev_dir": prev_dir,
        "run_dir": run_dir,
        "run_ns": run_ns,
        "temperature": temperature,
        "pressure": pressure,
        "timestep_fs": timestep_fs,
        "hydrogen_mass_repartition": hydrogen_mass_repartition,
        "membrane": membrane,
        "margin": margin,
        "dcd_freq_ps": dcd_freq_ps,
        "restart_freq_ps": restart_freq_ps,
        "output_freq": output_freq,
        "cuda_soa": cuda_soa,
        "ensemble": ensemble,
        "thermostat": thermostat,
        "barostat": barostat,
        "thermostat_period_ps": thermostat_period_ps,
        "barostat_period_ps": barostat_period_ps,
        "seed": seed,
        "forcefield": forcefield,
    })


@mcp.tool()
async def run_namd3(
    run_dir: str,
    namd_input: str = "min.namd",
    num_threads: int = 1,
    gpu_devices: str = "0",
    log_name: str = "log.txt",
    wait: bool = False,
    timeout_s: Optional[int] = None,
) -> str:
    """Launch NAMD3 in run_dir. By default returns IMMEDIATELY (wait=False)
    with the process PID, log path, and a copy-pasteable ``loop_suggestion``
    of a /loop command the user can use to monitor progress. Set wait=True
    only for short jobs (minimization, brief equilibration); it will block
    until completion."""
    return _run_function("run_namd3", {
        "run_dir": run_dir,
        "namd_input": namd_input,
        "num_threads": num_threads,
        "gpu_devices": gpu_devices,
        "log_name": log_name,
        "wait": wait,
        "timeout_s": timeout_s,
    }, timeout=None)


# --- Post-processing tools --------------------------------------------------

@mcp.tool()
async def wrap_and_align(
    run_dir: str,
    align_sel: str = "protein and name CA",
    wrap_sel: Optional[str] = "protein",
    output_basename: str = "aligned",
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> str:
    """Wrap waters/ions back into the box around wrap_sel and align the
    trajectory on align_sel. Writes <output_basename>.dcd plus a stripped
    PDB into run_dir/analysis/."""
    return _run_function("wrap_and_align", {
        "run_dir": run_dir, "align_sel": align_sel, "wrap_sel": wrap_sel,
        "output_basename": output_basename, "psf": psf, "pdb": pdb, "dcd": dcd,
    }, timeout=None)


@mcp.tool()
async def compute_rmsd(
    run_dir: str,
    sel: str = "protein and name CA",
    ref_frame: int = 0,
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> str:
    """Per-frame RMSD vs ref_frame. Writes a CSV and a PNG line plot of RMSD
    vs frame (returned in ``plot_png``). Returns timeseries summary."""
    return _run_function("compute_rmsd", {
        "run_dir": run_dir, "sel": sel, "ref_frame": ref_frame,
        "psf": psf, "pdb": pdb, "dcd": dcd,
    })


@mcp.tool()
async def compute_rmsf(
    run_dir: str,
    sel: str = "protein and name CA",
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> str:
    """Per-residue RMSF over the trajectory. Writes CSV with
    chain/resid/resname/rmsf and a PNG line plot of RMSF vs residue id
    (one trace per chain) returned in ``plot_png``."""
    return _run_function("compute_rmsf", {
        "run_dir": run_dir, "sel": sel,
        "psf": psf, "pdb": pdb, "dcd": dcd,
    })


@mcp.tool()
async def compute_sasa(
    run_dir: str,
    sel: str = "protein",
    mode: str = "total",
    probe_radius: float = 1.4,
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> str:
    """SASA of sel via freesasa. mode='total' returns one value/frame;
    'residue' returns per-residue values per frame. Writes a CSV plus a PNG
    (timeseries for ``total``, residue × frame heatmap for ``residue``)
    returned in ``plot_png``."""
    return _run_function("compute_sasa", {
        "run_dir": run_dir, "sel": sel, "mode": mode,
        "probe_radius": probe_radius,
        "psf": psf, "pdb": pdb, "dcd": dcd,
    })


@mcp.tool()
async def compute_distances(
    run_dir: str,
    sel1: str,
    sel2: str,
    metric: str = "min",
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> str:
    """Per-frame distance between two selections. metric='min' (closest
    atom-atom), 'centroid' (COM-COM), or 'all_pairs' (full N1*N2 matrix).
    Writes a CSV plus a PNG (timeseries for min/centroid, mean pair-distance
    heatmap for all_pairs) returned in ``plot_png``."""
    return _run_function("compute_distances", {
        "run_dir": run_dir, "sel1": sel1, "sel2": sel2, "metric": metric,
        "psf": psf, "pdb": pdb, "dcd": dcd,
    })


@mcp.tool()
async def radius_of_gyration(
    run_dir: str,
    sel: str = "protein and noh",
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> str:
    """Per-frame mass-weighted radius of gyration of sel. Writes a CSV and
    a PNG line plot of Rg vs frame returned in ``plot_png``."""
    return _run_function("radius_of_gyration", {
        "run_dir": run_dir, "sel": sel,
        "psf": psf, "pdb": pdb, "dcd": dcd,
    })


@mcp.tool()
async def ligand_rmsd(
    run_dir: str,
    ligand_resname: str,
    ref_frame: int = 0,
    align_protein_first: bool = True,
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> str:
    """RMSD of ligand heavy atoms vs ref_frame. By default aligns on the
    protein backbone first so the metric reports ligand drift relative to
    the protein. Writes a CSV and a PNG line plot returned in ``plot_png``."""
    return _run_function("ligand_rmsd", {
        "run_dir": run_dir, "ligand_resname": ligand_resname,
        "ref_frame": ref_frame, "align_protein_first": align_protein_first,
        "psf": psf, "pdb": pdb, "dcd": dcd,
    })


@mcp.tool()
async def ligand_protein_contacts(
    run_dir: str,
    ligand_resname: str,
    cutoff_A: float = 4.0,
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> str:
    """Per-residue contact frequency: fraction of frames any ligand atom is
    within cutoff_A of any atom of that residue. Returns top 20 contacts and
    a PNG bar chart of the top contacts (in ``plot_png``)."""
    return _run_function("ligand_protein_contacts", {
        "run_dir": run_dir, "ligand_resname": ligand_resname,
        "cutoff_A": cutoff_A,
        "psf": psf, "pdb": pdb, "dcd": dcd,
    })


@mcp.tool()
async def interface_contacts(
    run_dir: str,
    receptor_sel: str,
    partner_sel: str,
    cutoff_A: float = 4.5,
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> str:
    """Per-residue contact frequency at a protein-protein interface.

    For each residue on each side, reports the fraction of frames in which
    any of its atoms is within cutoff_A of any atom on the other partner.
    Writes one CSV per side (chain/resid/resname/segid/n/freq) and a PNG
    bar chart of the top hot residues per side (``plot_png_receptor`` /
    ``plot_png_partner``). Returns the top 20 hot residues per side. Use the
    receptor_selection and partner_selection strings returned by
    build_protein_protein_complex, or any custom VMD-style selections."""
    return _run_function("interface_contacts", {
        "run_dir": run_dir,
        "receptor_sel": receptor_sel,
        "partner_sel": partner_sel,
        "cutoff_A": cutoff_A,
        "psf": psf, "pdb": pdb, "dcd": dcd,
    }, timeout=None)


@mcp.tool()
async def interface_rmsd(
    run_dir: str,
    receptor_sel: str,
    partner_sel: str,
    cutoff_A: float = 5.0,
    align_receptor_first: bool = True,
    ref_frame: int = 0,
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> str:
    """CAPRI-style interface backbone RMSD.

    Identifies interface residues at ref_frame (any atom of one partner
    within cutoff_A of the other), then computes per-frame RMSD of those
    residues' backbone atoms vs ref_frame. With align_receptor_first=True
    the trajectory is first aligned on the receptor backbone, so the metric
    reports binding-pose drift of the partner against a fixed receptor.
    Writes a CSV and a PNG line plot returned in ``plot_png``."""
    return _run_function("interface_rmsd", {
        "run_dir": run_dir,
        "receptor_sel": receptor_sel,
        "partner_sel": partner_sel,
        "cutoff_A": cutoff_A,
        "align_receptor_first": align_receptor_first,
        "ref_frame": ref_frame,
        "psf": psf, "pdb": pdb, "dcd": dcd,
    }, timeout=None)


@mcp.tool()
async def buried_sasa(
    run_dir: str,
    receptor_sel: str,
    partner_sel: str,
    probe_radius: float = 1.4,
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> str:
    """Per-frame interfacial buried SASA = SASA(receptor) + SASA(partner)
    − SASA(complex). The standard threshold for a real interface is
    ~600 Å² (Jones & Thornton 1996). Writes CSV with all four columns and
    a two-panel PNG (buried SASA timeseries with the ~600 Å² reference line
    plus per-component SASAs) returned in ``plot_png``."""
    return _run_function("buried_sasa", {
        "run_dir": run_dir,
        "receptor_sel": receptor_sel,
        "partner_sel": partner_sel,
        "probe_radius": probe_radius,
        "psf": psf, "pdb": pdb, "dcd": dcd,
    }, timeout=None)


@mcp.tool()
async def monitor_namd_run(
    log: str,
    pid: Optional[int] = None,
    namd_input: Optional[str] = None,
) -> str:
    """Snapshot a running NAMD3 job. Reports completion, latest energies,
    ns/day, fatal/warning lines, and (when ``pid`` and ``namd_input`` are
    given) percent_complete, eta_hours, is_running, and a one-line
    status_message. Use this with a ``/loop`` to poll long-running jobs."""
    return _run_function("monitor_namd_run", {
        "log": log, "pid": pid, "namd_input": namd_input,
    })


@mcp.tool()
async def prepare_run(
    build_dir: str,
    workspace: str,
    min_steps: int = 5000,
    min_restraint_selection: Optional[str] = "protein and noh and not name CA",
    min_restraint_k: float = 1.0,
    skip_min: bool = False,
    equil_run_ns: float = 2.0,
    equil_timestep_fs: float = 2.0,
    equil_restraint_selection: str = "protein and name CA",
    equil_restraint_k: float = 1.0,
    equil_restraint_schedule: Optional[List[List[float]]] = None,
    equil_minimize_first: bool = True,
    equil_minimize_steps: int = 1000,
    equil_ensemble: str = "NPT",
    skip_equil: bool = False,
    prod_run_ns: float = 100.0,
    prod_timestep_fs: float = 4.0,
    hydrogen_mass_repartition: bool = True,
    prod_dcd_freq_ps: float = 10.0,
    prod_restart_freq_ps: float = 100.0,
    prod_ensemble: str = "NPT",
    background_production: bool = True,
    membrane: bool = False,
    margin: float = 2.0,
    temperature: float = 300.0,
    pressure: float = 1.01325,
    seed: Optional[int] = None,
    num_threads: int = 4,
    gpu_devices: str = "0",
    forcefield: str = "charmm",
) -> str:
    """One-shot: minimize → equilibrate → produce, all under workspace/.

    Minimization and equilibration run synchronously; production starts in
    the background by default (returns PID + log path so you can poll with
    monitor_namd_run). Pass membrane=True for bilayer systems (anisotropic
    NPT). skip_min/skip_equil reuse existing min/ or equil/ outputs.

    equil_ensemble / prod_ensemble: 'NPT' (default) or 'NVT'. NVT skips the
    Langevin piston barostat — use it when the box is already correct from
    a prior NPT run, or for short heating before NPT.
    seed: optional int. When given, threads through min/equil/prod so all
    three Langevin streams are reproducible."""
    return _run_function("prepare_run", {
        "build_dir": build_dir,
        "workspace": workspace,
        "min_steps": min_steps,
        "min_restraint_selection": min_restraint_selection,
        "min_restraint_k": min_restraint_k,
        "skip_min": skip_min,
        "equil_run_ns": equil_run_ns,
        "equil_timestep_fs": equil_timestep_fs,
        "equil_restraint_selection": equil_restraint_selection,
        "equil_restraint_k": equil_restraint_k,
        "equil_restraint_schedule": equil_restraint_schedule,
        "equil_minimize_first": equil_minimize_first,
        "equil_minimize_steps": equil_minimize_steps,
        "equil_ensemble": equil_ensemble,
        "skip_equil": skip_equil,
        "prod_run_ns": prod_run_ns,
        "prod_timestep_fs": prod_timestep_fs,
        "hydrogen_mass_repartition": hydrogen_mass_repartition,
        "prod_dcd_freq_ps": prod_dcd_freq_ps,
        "prod_restart_freq_ps": prod_restart_freq_ps,
        "prod_ensemble": prod_ensemble,
        "background_production": background_production,
        "membrane": membrane,
        "margin": margin,
        "temperature": temperature,
        "pressure": pressure,
        "seed": seed,
        "num_threads": num_threads,
        "gpu_devices": gpu_devices,
        "forcefield": forcefield,
    }, timeout=None)


# --- Advanced post-processing ----------------------------------------------

@mcp.tool()
async def analyze_hbonds(
    run_dir: str,
    method: str = "baker_hubbard",
    freq_threshold: float = 0.1,
    sel: str = "protein",
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> str:
    """Per-frame H-bond detection (mdtraj baker_hubbard or wernet_nilsson).
    Outputs persistent donor-acceptor pairs (CSV), per-frame H-bond count
    timeseries (CSV + ``timeseries_png`` line plot), a top-persistence bar
    chart (``persistence_png``), and an interactive plotly HTML donor ×
    acceptor heatmap (``matrix_html``). freq_threshold filters the
    persistent table to pairs present in >=freq_threshold of frames."""
    return _run_function("analyze_hbonds", {
        "run_dir": run_dir, "method": method,
        "freq_threshold": freq_threshold, "sel": sel,
        "psf": psf, "pdb": pdb, "dcd": dcd,
    }, timeout=None)


@mcp.tool()
async def compute_secondary_structure(
    run_dir: str,
    simplified: bool = True,
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> str:
    """DSSP secondary-structure assignment per residue per frame
    (mdtraj.compute_dssp). Outputs ss_timeseries.csv, ss_fractions.csv, and
    a residue × time heatmap PNG. simplified=True returns 3 codes (H/E/C)."""
    return _run_function("compute_secondary_structure", {
        "run_dir": run_dir, "simplified": simplified,
        "psf": psf, "pdb": pdb, "dcd": dcd,
    }, timeout=None)


@mcp.tool()
async def compute_pca(
    run_dir: str,
    sel: str = "protein and name CA",
    n_components: int = 10,
    align_first: bool = True,
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> str:
    """Cartesian PCA on aligned coordinates of sel. Outputs projections per
    frame for n_components, explained variance CSV, eigenvectors as .npy,
    and a scree + PC1-PC2 scatter PNG. Required as input for the FEL/KDE
    and most clustering tools."""
    return _run_function("compute_pca", {
        "run_dir": run_dir, "sel": sel, "n_components": n_components,
        "align_first": align_first,
        "psf": psf, "pdb": pdb, "dcd": dcd,
    }, timeout=None)


@mcp.tool()
async def cluster_trajectory(
    run_dir: str,
    method: str = "kmeans",
    n_clusters: int = 5,
    on: str = "pca",
    n_components: int = 3,
    sel: str = "protein and name CA",
    eps: float = 1.0,
    min_samples: int = 5,
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> str:
    """Cluster trajectory frames in PC space (default) or RMSD space.
    method='kmeans' | 'agglomerative' | 'dbscan'. Returns silhouette score,
    populations, and per-cluster representative frames.
    Run compute_pca first when on='pca'."""
    return _run_function("cluster_trajectory", {
        "run_dir": run_dir, "method": method, "n_clusters": n_clusters,
        "on": on, "n_components": n_components, "sel": sel,
        "eps": eps, "min_samples": min_samples,
        "psf": psf, "pdb": pdb, "dcd": dcd,
    }, timeout=None)


@mcp.tool()
async def free_energy_landscape(
    run_dir: str,
    cv_csv: Optional[str] = None,
    cv_columns: Optional[List[str]] = None,
    method: str = "histogram",
    bins: int = 60,
    temperature: float = 300.0,
    output_basename: str = "fel",
) -> str:
    """Compute -kT*ln(P) on 2 or 3 collective variables. By default reads
    pca_projections.csv and uses PC1/PC2 (2D) or PC1/PC2/PC3 (3D).
    method='histogram' | 'kde'. Outputs a 2D contour PNG; for 3D also
    writes an interactive plotly isosurface HTML."""
    return _run_function("free_energy_landscape", {
        "run_dir": run_dir, "cv_csv": cv_csv, "cv_columns": cv_columns,
        "method": method, "bins": bins, "temperature": temperature,
        "output_basename": output_basename,
    }, timeout=None)


@mcp.tool()
async def kernel_density_estimation(
    run_dir: str,
    cv_csv: Optional[str] = None,
    cv_columns: Optional[List[str]] = None,
    bins: int = 100,
    output_basename: str = "kde",
) -> str:
    """Kernel-density estimate (1D or 2D) over collective variables.
    Defaults to PC1/PC2 from pca_projections.csv. Outputs the PDF (not
    free energy) so populations can be read directly."""
    return _run_function("kernel_density_estimation", {
        "run_dir": run_dir, "cv_csv": cv_csv, "cv_columns": cv_columns,
        "bins": bins, "output_basename": output_basename,
    }, timeout=None)


@mcp.tool()
async def render_molecular_movie(
    run_dir: str,
    output_basename: str = "movie",
    fps: int = 20,
    width: int = 800,
    height: int = 600,
    n_frames: Optional[int] = None,
    representation: str = "cartoon_ligand",
    ligand_resname: Optional[str] = None,
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
    ray_trace: bool = False,
) -> str:
    """Render an MP4 of the trajectory using PyMOL (headless) + ffmpeg.
    Cartoon for protein, licorice for ligand. ray_trace=True for
    publication-quality (~minutes) rendering."""
    return _run_function("render_molecular_movie", {
        "run_dir": run_dir, "output_basename": output_basename,
        "fps": fps, "width": width, "height": height,
        "n_frames": n_frames, "representation": representation,
        "ligand_resname": ligand_resname,
        "psf": psf, "pdb": pdb, "dcd": dcd, "ray_trace": ray_trace,
    }, timeout=None)


@mcp.tool()
async def render_dashboard_movie(
    run_dir: str,
    output_basename: str = "dashboard",
    fps: int = 10,
    width_in: float = 12.0,
    height_in: float = 6.0,
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> str:
    """Multi-panel matplotlib movie of timeseries (RMSD/Rg/SASA/PC1-PC2),
    animated frame-by-frame. Loads any pre-computed CSVs from
    run_dir/analysis/; computes missing ones on the fly."""
    return _run_function("render_dashboard_movie", {
        "run_dir": run_dir, "output_basename": output_basename,
        "fps": fps, "width_in": width_in, "height_in": height_in,
        "psf": psf, "pdb": pdb, "dcd": dcd,
    }, timeout=None)


@mcp.tool()
async def mm_pbsa(
    run_dir: str,
    ligand_resname: str,
    n_frames: int = 25,
    salt_concentration: float = 0.15,
    solvent_dielectric: float = 78.5,
    surface_tension: float = 0.00542,
    surface_offset: float = 0.92,
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
    output_basename: str = "mmpbsa",
) -> str:
    """Single-trajectory MM-GBSA estimate of ligand binding free energy.
    For each of n_frames evenly-spaced frames: strip waters, split the PSF
    into complex/receptor/ligand via parmed, run NAMD3 GBIS single-point on
    each, and average ΔG_bind = E_complex - E_receptor - E_ligand. Returns
    per-term breakdown (vdW, elec, bonded) with mean ± std, and writes a
    two-panel PNG (per-frame ΔG_TOTAL timeseries + per-term mean bar with
    SEM errorbars) returned in ``plot_png``. PB→GB approximation; APBS is
    not invoked."""
    return _run_function("mm_pbsa", {
        "run_dir": run_dir, "ligand_resname": ligand_resname,
        "n_frames": n_frames,
        "salt_concentration": salt_concentration,
        "solvent_dielectric": solvent_dielectric,
        "surface_tension": surface_tension,
        "surface_offset": surface_offset,
        "psf": psf, "pdb": pdb, "dcd": dcd,
        "output_basename": output_basename,
    }, timeout=None)


@mcp.tool()
async def quality_assurance_report(
    run_dirs: List[str],
    target_temperature: float = 300.0,
    target_pressure: float = 1.01325,
    output_basename: str = "qa_report",
) -> str:
    """QA dashboard for a stage or pipeline. Pass run_dirs=[min, equil, prod]
    for the full picture. Reports energy / temperature / pressure / volume
    stability with linear-regression drift, equilibration detection (block
    averaging), and a side-by-side multi-stage timeseries PNG."""
    return _run_function("quality_assurance_report", {
        "run_dirs": run_dirs,
        "target_temperature": target_temperature,
        "target_pressure": target_pressure,
        "output_basename": output_basename,
    }, timeout=None)


@mcp.tool()
async def bond_length_sanity(
    run_dir: str,
    sel: str = "protein",
    z_threshold: float = 5.0,
    psf: Optional[str] = None,
    pdb: Optional[str] = None,
    dcd: Optional[str] = None,
) -> str:
    """Flag bonds whose lengths deviate from their per-bond mean by more
    than z_threshold standard deviations. Surfaces broken or stretched
    bonds (mis-built systems, ring-puckering issues, etc.). Returns the
    top 10 offenders by max-z."""
    return _run_function("bond_length_sanity", {
        "run_dir": run_dir, "sel": sel, "z_threshold": z_threshold,
        "psf": psf, "pdb": pdb, "dcd": dcd,
    }, timeout=None)


@mcp.tool()
async def compare_protein_nucleic(
    runs: Dict[str, str],
    out_dir: str,
    dcd_name: str = "prod.dcd",
    psf_name: str = "structure.psf",
    config_name: Optional[str] = None,
    time_per_frame_ns: Optional[float] = None,
    protein_sel: str = "protein",
    backbone_sel: str = "name CA",
    na_resnames: Optional[str] = None,
    na_name: str = "DNA",
    highlight: Optional[str] = None,
    ref_frame: int = 0,
    stride: int = 1,
    reimage: bool = True,
    individual: bool = True,
    compute_rg: bool = True,
    hbond_method: str = "wernet_nilsson",
    hbond_distance: float = 3.5,
    hbond_angle: float = 30.0,
    exclude_termini: int = 0,
    rmsd_ref: Optional[str] = None,
    system_name: str = "",
) -> str:
    """Compare several protein-DNA/RNA trajectories on shared axes.

    ``runs`` maps a label to a run directory (containing ``dcd_name`` +
    ``psf_name``), a ``.dcd`` file, or a ``DCD:PSF`` pair, e.g.
    {"WT": "05_prod_WT", "R248W": "05_prod_R248W"}. Computes protein-backbone
    RMSD vs time, per-residue RMSF, inter-molecular protein-nucleic H-bonds vs
    time (minimum-image), and optional radius of gyration.

    Nucleic atoms are auto-detected by sugar atoms (DNA *and* RNA, any naming).
    ns/frame is read from the NAMD config (timestep*dcdfreq) unless
    ``time_per_frame_ns`` is given. The complex is re-imaged with the protein as
    anchor before H-bond detection. Writes into ``out_dir``: overlaid comparison
    PNGs (rmsd/rmsf/hbonds[/rg]), one ``individual_<label>.png`` 4-panel per
    system, per-system CSVs, ``summary.csv`` and ``analysis_summary.md``.
    ``highlight`` is a comma-separated list of residue numbers to mark on RMSF.
    ``hbond_method`` is 'wernet_nilsson' (per-frame), 'baker_hubbard', or
    'gromacs' (gmx hbond criterion: D-A <= ``hbond_distance`` Å, H-D-A angle <=
    ``hbond_angle``°). ``exclude_termini`` drops the first/last N protein
    residues (per chain) from RMSD/RMSF. ``rmsd_ref`` references RMSD/RMSF to an
    external structure (e.g. the crystal): an absolute path, or a filename
    resolved inside each run dir (e.g. 'structure.pdb')."""
    return _run_function("compare_protein_nucleic", {
        "runs": runs, "out_dir": out_dir,
        "dcd_name": dcd_name, "psf_name": psf_name, "config_name": config_name,
        "time_per_frame_ns": time_per_frame_ns,
        "protein_sel": protein_sel, "backbone_sel": backbone_sel,
        "na_resnames": na_resnames, "na_name": na_name, "highlight": highlight,
        "ref_frame": ref_frame, "stride": stride, "reimage": reimage,
        "individual": individual, "compute_rg": compute_rg,
        "hbond_method": hbond_method, "hbond_distance": hbond_distance,
        "hbond_angle": hbond_angle, "exclude_termini": exclude_termini,
        "rmsd_ref": rmsd_ref, "system_name": system_name,
    }, timeout=None)


# --- Entry point ------------------------------------------------------------

if __name__ == "__main__":
    print("Starting htmd-md MCP server...", file=sys.stderr)
    logger.info("Starting htmd-md MCP server")
    mcp.run(transport="stdio")
