"""CLI dispatcher: ``python functions.py <fn_name> <json_args>``.

Each top-level function takes JSON args (a single positional argument that is
a JSON string), executes the underlying HTMD workflow, and prints exactly one
JSON object to stdout. Logs go to stderr so they don't pollute the JSON.
"""

from __future__ import annotations

import json
import logging
import os
import sys
import traceback
from typing import Any, Callable, Dict

# HTMD's home.py prints "HTMD: Logging setup failed" + a license blurb to
# stdout on import, which corrupts our JSON output. Redirect stdout to
# stderr for the duration of the htmd import so any stray prints land
# safely on stderr and don't pollute the dispatcher's JSON contract.
_real_stdout = sys.stdout
sys.stdout = sys.stderr
try:
    import htmd  # noqa: F401  (forces import + prints noise on stderr)
except Exception:
    pass
sys.stdout = _real_stdout


def _safe_dumps(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, indent=2, default=str)


def _emit(obj: Any) -> None:
    sys.stdout.write(_safe_dumps(obj))
    sys.stdout.write("\n")
    sys.stdout.flush()


# ------ tool implementations (thin wrappers around htmd_mcp.* modules) ------

def _fetch_pdb(args: Dict[str, Any]) -> Dict[str, Any]:
    from htmd_mcp.common import fetch_pdb
    return fetch_pdb(**args)


def _inspect_structure(args: Dict[str, Any]) -> Dict[str, Any]:
    from htmd_mcp.common import inspect_structure
    return inspect_structure(**args)


def _prepare_protein(args: Dict[str, Any]) -> Dict[str, Any]:
    from htmd_mcp.common import prepare_protein
    return prepare_protein(**args)


def _auto_segment(args: Dict[str, Any]) -> Dict[str, Any]:
    from htmd_mcp.common import auto_segment
    return auto_segment(**args)


def _clean_structure(args: Dict[str, Any]) -> Dict[str, Any]:
    from htmd_mcp.common import clean_structure
    return clean_structure(**args)


def _build_protein_waterbox(args: Dict[str, Any]) -> Dict[str, Any]:
    from htmd_mcp.prep_waterbox import build_protein_waterbox
    return build_protein_waterbox(**args)


def _build_protein_membrane(args: Dict[str, Any]) -> Dict[str, Any]:
    from htmd_mcp.prep_membrane import build_protein_membrane
    return build_protein_membrane(**args)


def _build_protein_protein_complex(args: Dict[str, Any]) -> Dict[str, Any]:
    from htmd_mcp.prep_complex import build_protein_protein_complex
    return build_protein_protein_complex(**args)


def _build_protein_multiligand(args: Dict[str, Any]) -> Dict[str, Any]:
    from htmd_mcp.prep_multiligand import build_protein_multiligand
    return build_protein_multiligand(**args)


def _build_protein_nucleic(args: Dict[str, Any]) -> Dict[str, Any]:
    from htmd_mcp.prep_nucleic import build_protein_nucleic
    return build_protein_nucleic(**args)


def _list_lipids(args: Dict[str, Any]) -> Dict[str, Any]:
    from htmd_mcp.prep_membrane import list_lipids
    return list_lipids()


def _parametrize_ligand(args: Dict[str, Any]) -> Dict[str, Any]:
    from htmd_mcp.prep_ligand import parametrize_ligand
    return parametrize_ligand(**args)


def _build_protein_ligand(args: Dict[str, Any]) -> Dict[str, Any]:
    from htmd_mcp.prep_ligand import build_protein_ligand
    return build_protein_ligand(**args)


def _swissparam_health(args: Dict[str, Any]) -> Dict[str, Any]:
    from htmd_mcp.swissparam import health_check
    return health_check()


def _fetch_ligand_from_rcsb(args: Dict[str, Any]) -> Dict[str, Any]:
    from htmd_mcp.ligand_io import fetch_ligand_from_rcsb
    return fetch_ligand_from_rcsb(**args)


def _prepare_ligand_mol2(args: Dict[str, Any]) -> Dict[str, Any]:
    from htmd_mcp.ligand_io import prepare_ligand_mol2
    return prepare_ligand_mol2(**args)


def _setup_minimization(args: Dict[str, Any]) -> Dict[str, Any]:
    from htmd_mcp.namd3_writer import write_minimization
    return write_minimization(**args)


def _setup_equilibration(args: Dict[str, Any]) -> Dict[str, Any]:
    from htmd_mcp.namd3_writer import write_equilibration
    return write_equilibration(**args)


def _setup_production(args: Dict[str, Any]) -> Dict[str, Any]:
    from htmd_mcp.namd3_writer import write_production
    return write_production(**args)


def _run_namd3(args: Dict[str, Any]) -> Dict[str, Any]:
    from htmd_mcp.namd3_runner import run_namd3
    return run_namd3(**args)


def _monitor_namd_run(args: Dict[str, Any]) -> Dict[str, Any]:
    from htmd_mcp.namd3_runner import parse_namd_log
    log_path = args["log"]
    pid = args.get("pid")
    namd_input = args.get("namd_input")
    summary = parse_namd_log(log_path, pid=pid, namd_input=namd_input)
    return {"log": log_path, "summary": summary}


# --- Post-processing wrappers ---------------------------------------------

def _wrap_and_align(args):
    from htmd_mcp.postprocess import wrap_and_align
    return wrap_and_align(**args)


def _compute_rmsd(args):
    from htmd_mcp.postprocess import compute_rmsd
    return compute_rmsd(**args)


def _compute_rmsf(args):
    from htmd_mcp.postprocess import compute_rmsf
    return compute_rmsf(**args)


def _compute_sasa(args):
    from htmd_mcp.postprocess import compute_sasa
    return compute_sasa(**args)


def _compute_distances(args):
    from htmd_mcp.postprocess import compute_distances
    return compute_distances(**args)


def _radius_of_gyration(args):
    from htmd_mcp.postprocess import radius_of_gyration
    return radius_of_gyration(**args)


def _ligand_rmsd(args):
    from htmd_mcp.postprocess import ligand_rmsd
    return ligand_rmsd(**args)


def _ligand_protein_contacts(args):
    from htmd_mcp.postprocess import ligand_protein_contacts
    return ligand_protein_contacts(**args)


def _interface_contacts(args):
    from htmd_mcp.postprocess import interface_contacts
    return interface_contacts(**args)


def _interface_rmsd(args):
    from htmd_mcp.postprocess import interface_rmsd
    return interface_rmsd(**args)


def _buried_sasa(args):
    from htmd_mcp.postprocess import buried_sasa
    return buried_sasa(**args)


def _prepare_run(args):
    from htmd_mcp.run_pipeline import prepare_run
    return prepare_run(**args)


# --- Advanced post-processing -------------------------------------------

def _analyze_hbonds(args):
    from htmd_mcp.postprocess_advanced import analyze_hbonds
    return analyze_hbonds(**args)


def _compute_secondary_structure(args):
    from htmd_mcp.postprocess_advanced import compute_secondary_structure
    return compute_secondary_structure(**args)


def _compute_pca(args):
    from htmd_mcp.pca_fel import compute_pca
    return compute_pca(**args)


def _cluster_trajectory(args):
    from htmd_mcp.pca_fel import cluster_trajectory
    return cluster_trajectory(**args)


def _free_energy_landscape(args):
    from htmd_mcp.pca_fel import free_energy_landscape
    return free_energy_landscape(**args)


def _kernel_density_estimation(args):
    from htmd_mcp.pca_fel import kernel_density_estimation
    return kernel_density_estimation(**args)


def _render_molecular_movie(args):
    from htmd_mcp.visualization import render_molecular_movie
    return render_molecular_movie(**args)


def _render_dashboard_movie(args):
    from htmd_mcp.visualization import render_dashboard_movie
    return render_dashboard_movie(**args)


def _mm_pbsa(args):
    from htmd_mcp.mm_pbsa import mm_pbsa
    return mm_pbsa(**args)


def _quality_assurance_report(args):
    from htmd_mcp.qa import quality_assurance_report
    return quality_assurance_report(**args)


def _bond_length_sanity(args):
    from htmd_mcp.qa import bond_length_sanity
    return bond_length_sanity(**args)


def _compare_protein_nucleic(args):
    from htmd_mcp.compare import compare_protein_nucleic
    return compare_protein_nucleic(**args)


DISPATCH: Dict[str, Callable[[Dict[str, Any]], Dict[str, Any]]] = {
    "fetch_pdb": _fetch_pdb,
    "inspect_structure": _inspect_structure,
    "prepare_protein": _prepare_protein,
    "auto_segment": _auto_segment,
    "clean_structure": _clean_structure,
    "build_protein_waterbox": _build_protein_waterbox,
    "build_protein_membrane": _build_protein_membrane,
    "build_protein_protein_complex": _build_protein_protein_complex,
    "build_protein_multiligand": _build_protein_multiligand,
    "build_protein_nucleic": _build_protein_nucleic,
    "list_lipids": _list_lipids,
    "parametrize_ligand": _parametrize_ligand,
    "build_protein_ligand": _build_protein_ligand,
    "swissparam_health": _swissparam_health,
    "fetch_ligand_from_rcsb": _fetch_ligand_from_rcsb,
    "prepare_ligand_mol2": _prepare_ligand_mol2,
    "setup_minimization": _setup_minimization,
    "setup_equilibration": _setup_equilibration,
    "setup_production": _setup_production,
    "run_namd3": _run_namd3,
    "monitor_namd_run": _monitor_namd_run,
    # Post-processing
    "wrap_and_align": _wrap_and_align,
    "compute_rmsd": _compute_rmsd,
    "compute_rmsf": _compute_rmsf,
    "compute_sasa": _compute_sasa,
    "compute_distances": _compute_distances,
    "radius_of_gyration": _radius_of_gyration,
    "ligand_rmsd": _ligand_rmsd,
    "ligand_protein_contacts": _ligand_protein_contacts,
    "interface_contacts": _interface_contacts,
    "interface_rmsd": _interface_rmsd,
    "buried_sasa": _buried_sasa,
    "prepare_run": _prepare_run,
    # Advanced post-processing
    "analyze_hbonds": _analyze_hbonds,
    "compute_secondary_structure": _compute_secondary_structure,
    "compute_pca": _compute_pca,
    "cluster_trajectory": _cluster_trajectory,
    "free_energy_landscape": _free_energy_landscape,
    "kernel_density_estimation": _kernel_density_estimation,
    "render_molecular_movie": _render_molecular_movie,
    "render_dashboard_movie": _render_dashboard_movie,
    "mm_pbsa": _mm_pbsa,
    "quality_assurance_report": _quality_assurance_report,
    "bond_length_sanity": _bond_length_sanity,
    "compare_protein_nucleic": _compare_protein_nucleic,
}


def main(argv: list[str]) -> int:
    logging.basicConfig(
        level=os.environ.get("HTMD_MCP_LOG", "INFO"),
        format="%(asctime)s %(name)s %(levelname)s: %(message)s",
        stream=sys.stderr,
    )

    if len(argv) < 2:
        _emit({"status": "error", "error": "usage: functions.py <fn> <json>"})
        return 2

    fn_name = argv[1]
    raw = argv[2] if len(argv) >= 3 else "{}"
    try:
        args = json.loads(raw)
    except json.JSONDecodeError as e:
        _emit({"status": "error", "error": f"invalid JSON: {e}"})
        return 2

    fn = DISPATCH.get(fn_name)
    if fn is None:
        _emit({"status": "error", "error": f"unknown function {fn_name!r}",
               "available": sorted(DISPATCH)})
        return 2

    try:
        result = fn(args or {})
        _emit(result)
        return 0
    except Exception as e:
        _emit({
            "status": "error",
            "error": str(e),
            "traceback": traceback.format_exc(),
            "fn": fn_name,
        })
        return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
